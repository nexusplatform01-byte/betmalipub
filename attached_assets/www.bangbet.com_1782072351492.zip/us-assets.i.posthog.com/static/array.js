! function() {
    "use strict";
    var t = "undefined" != typeof window ? window : void 0,
        e = "undefined" != typeof globalThis ? globalThis : t;
    "undefined" == typeof self && (e.self = e), "undefined" == typeof File && (e.File = function() {});
    var i = null == e ? void 0 : e.navigator,
        r = null == e ? void 0 : e.document,
        s = null == e ? void 0 : e.location,
        n = null == e ? void 0 : e.fetch,
        o = null != e && e.XMLHttpRequest && "withCredentials" in new e.XMLHttpRequest ? e.XMLHttpRequest : void 0,
        a = null == e ? void 0 : e.AbortController,
        l = null == e ? void 0 : e.CompressionStream,
        u = null == i ? void 0 : i.userAgent,
        h = null != t ? t : {},
        d = "1.391.2",
        v = {
            DEBUG: !1,
            LIB_VERSION: d,
            LIB_NAME: "web",
            JS_SDK_VERSION: d
        };

    function c(t, e, i, r, s, n, o) {
        try {
            var a = t[n](o),
                l = a.value
        } catch (t) {
            return void i(t)
        }
        a.done ? e(l) : Promise.resolve(l).then(r, s)
    }

    function f(t) {
        return function() {
            var e = this,
                i = arguments;
            return new Promise((function(r, s) {
                var n = t.apply(e, i);

                function o(t) {
                    c(n, r, s, o, a, "next", t)
                }

                function a(t) {
                    c(n, r, s, o, a, "throw", t)
                }
                o(void 0)
            }))
        }
    }

    function p() {
        return p = Object.assign ? Object.assign.bind() : function(t) {
            for (var e = 1; arguments.length > e; e++) {
                var i = arguments[e];
                for (var r in i)({}).hasOwnProperty.call(i, r) && (t[r] = i[r])
            }
            return t
        }, p.apply(null, arguments)
    }

    function g(t, e) {
        if (null == t) return {};
        var i = {};
        for (var r in t)
            if ({}.hasOwnProperty.call(t, r)) {
                if (-1 !== e.indexOf(r)) continue;
                i[r] = t[r]
            }
        return i
    }
    var _ = t => {
        if ("string" != typeof t) return t;
        try {
            return JSON.parse(t)
        } catch (e) {
            return t
        }
    };

    function m(t) {
        return "string" == typeof t || t
    }

    function y(t) {
        return "string" == typeof t ? t : void 0
    }
    var b, w = function(t) {
            return t.AnonymousId = "anonymous_id", t.DistinctId = "distinct_id", t.Props = "props", t.EnablePersonProcessing = "enable_person_processing", t.PersonMode = "person_mode", t.FeatureFlagDetails = "feature_flag_details", t.FeatureFlags = "feature_flags", t.FeatureFlagPayloads = "feature_flag_payloads", t.BootstrapFeatureFlagDetails = "bootstrap_feature_flag_details", t.BootstrapFeatureFlags = "bootstrap_feature_flags", t.BootstrapFeatureFlagPayloads = "bootstrap_feature_flag_payloads", t.OverrideFeatureFlags = "override_feature_flags", t.Queue = "queue", t.LogsQueue = "logs_queue", t.OptedOut = "opted_out", t.SessionId = "session_id", t.SessionStartTimestamp = "session_start_timestamp", t.SessionLastTimestamp = "session_timestamp", t.PersonProperties = "person_properties", t.GroupProperties = "group_properties", t.InstalledAppBuild = "installed_app_build", t.InstalledAppVersion = "installed_app_version", t.SessionReplay = "session_replay", t.SurveyLastSeenDate = "survey_last_seen_date", t.SurveysSeen = "surveys_seen", t.Surveys = "surveys", t.RemoteConfig = "remote_config", t.FlagsEndpointWasHit = "flags_endpoint_was_hit", t.DeviceId = "device_id", t
        }({}),
        x = function(t) {
            return t.GZipJS = "gzip-js", t.Base64 = "base64", t
        }({}),
        E = ["$snapshot", "$pageview", "$pageleave", "$set", "survey dismissed", "survey sent", "survey shown", "$identify", "$groupidentify", "$create_alias", "$$client_ingestion_warning", "$web_experiment_applied", "$feature_enrollment_update", "$feature_flag_called"],
        S = ["token"],
        k = "NativeGzipValidationError",
        P = t => t.length >= 2 && 31 === t[0] && 139 === t[1],
        T = t => !(!t || "object" != typeof t) && "NotReadableError" === ("name" in t ? String(t.name) : ""),
        I = t => {
            var e = new Error("Native gzip produced invalid output: " + t);
            throw e.name = k, e
        },
        R = function() {
            var t = f((function*(t, e) {
                18 > t.size && I("too-short");
                var i = new Uint8Array(yield t.slice(0, 10).arrayBuffer());
                P(i) && 8 === i[2] || I("invalid-header");
                var r = new DataView(yield t.slice(t.size - 8).arrayBuffer());
                r.getUint32(0, !0) !== (t => {
                    for (var e = (() => {
                            if (b) return b;
                            b = [];
                            for (var t = 0; 256 > t; t++) {
                                for (var e = t, i = 0; 8 > i; i++) e = 1 & e ? 3988292384 ^ e >>> 1 : e >>> 1;
                                b[t] = e >>> 0
                            }
                            return b
                        })(), i = 4294967295, r = 0; t.length > r; r++) i = e[255 & (i ^ t[r])] ^ i >>> 8;
                    return (4294967295 ^ i) >>> 0
                })(e) && I("invalid-crc");
                var s = e.length >>> 0;
                r.getUint32(4, !0) !== s && I("invalid-size")
            }));
            return function(e, i) {
                return t.apply(this, arguments)
            }
        }();

    function C() {
        return C = f((function*(t, e, i) {
            void 0 === e && (e = !0);
            try {
                var r = (new TextEncoder).encode(t),
                    s = new CompressionStream("gzip"),
                    n = s.writable.getWriter(),
                    o = n.write(r).then((() => n.close())).catch(function() {
                        var t = f((function*(t) {
                            try {
                                yield n.abort(t)
                            } catch (t) {}
                            throw t
                        }));
                        return function(e) {
                            return t.apply(this, arguments)
                        }
                    }()),
                    a = new Response(s.readable).blob(),
                    [l] = yield Promise.all([a, o]);
                return yield R(l, r), l
            } catch (t) {
                if (null != i && i.rethrow) throw t;
                return e && console.error("Failed to gzip compress data", t), null
            }
        })), C.apply(this, arguments)
    }
    var F = ["amazonbot", "amazonproductbot", "app.hypefactors.com", "applebot", "archive.org_bot", "awariobot", "backlinksextendedbot", "baiduspider", "bingbot", "bingpreview", "chrome-lighthouse", "dataforseobot", "deepscan", "duckduckbot", "facebookexternal", "facebookcatalog", "http://yandex.com/bots", "hubspot", "ia_archiver", "leikibot", "linkedinbot", "meta-externalagent", "mj12bot", "msnbot", "nessus", "petalbot", "pinterest", "prerender", "rogerbot", "screaming frog", "sebot-wa", "sitebulb", "slackbot", "slurp", "trendictionbot", "turnitin", "twitterbot", "vercel-screenshot", "vercelbot", "yahoo! slurp", "yandexbot", "zoombot", "bot.htm", "bot.php", "(bot;", "bot/", "crawler", "ahrefsbot", "ahrefssiteaudit", "semrushbot", "siteauditbot", "splitsignalbot", "gptbot", "oai-searchbot", "chatgpt-user", "perplexitybot", "better uptime bot", "sentryuptimebot", "uptimerobot", "headlesschrome", "cypress", "google-hoteladsverifier", "adsbot-google", "apis-google", "duplexweb-google", "feedfetcher-google", "google favicon", "google web preview", "google-read-aloud", "googlebot", "googleother", "google-cloudvertexbot", "googleweblight", "mediapartners-google", "storebot-google", "google-inspectiontool", "bytespider"],
        M = function(t, e) {
            if (void 0 === e && (e = []), !t) return !1;
            var i = t.toLowerCase();
            return F.concat(e).some((t => {
                var e = t.toLowerCase();
                return -1 !== i.indexOf(e)
            }))
        };

    function O(t, e) {
        return -1 !== t.indexOf(e)
    }
    var A = function(t) {
            return t.trim()
        },
        D = function(t) {
            return t.replace(/^\$/, "")
        },
        L = Object.prototype,
        j = L.hasOwnProperty,
        z = L.toString,
        N = Array.isArray || function(t) {
            return "[object Array]" === z.call(t)
        },
        U = t => "function" == typeof t,
        B = t => t === Object(t) && !N(t),
        H = t => {
            if (B(t)) {
                for (var e in t)
                    if (j.call(t, e)) return !1;
                return !0
            }
            return !1
        },
        q = t => void 0 === t,
        G = t => "[object String]" == z.call(t),
        V = t => G(t) && 0 === t.trim().length,
        W = t => null === t,
        J = t => q(t) || W(t),
        K = t => "[object Number]" == z.call(t) && t == t,
        Y = t => K(t) && t > 0,
        X = t => "[object Boolean]" === z.call(t),
        Q = t => t instanceof FormData,
        Z = t => O(E, t),
        tt = t => O(S, t);

    function et(t) {
        return null === t || "object" != typeof t
    }

    function it(t, e) {
        return {}.toString.call(t) === "[object " + e + "]"
    }

    function rt(t) {
        return "undefined" != typeof Event && function(t, e) {
            try {
                return t instanceof e
            } catch (t) {
                return !1
            }
        }(t, Event)
    }
    var st = [!0, "true", 1, "1", "yes"],
        nt = t => O(st, t),
        ot = [!1, "false", 0, "0", "no"];

    function at(t, e, i, r, s) {
        return e > i && (r.warn("min cannot be greater than max."), e = i), K(t) ? t > i ? (r.warn(" cannot be  greater than max: " + i + ". Using max value instead."), i) : e > t ? (r.warn(" cannot be less than min: " + e + ". Using min value instead."), e) : t : (r.warn(" must be a number. using max or fallback. max: " + i + ", fallback: " + s), at(s || i, e, i, r))
    }
    class lt {
        constructor(t) {
            this.$t = {}, this.Gt = t.Gt, this.Zt = at(t.bucketSize, 0, 100, t.Qt), this.Jt = at(t.refillRate, 0, this.Zt, t.Qt), this.Kt = at(t.refillInterval, 0, 864e5, t.Qt)
        }
        Yt(t, e) {
            var i = Math.floor((e - t.lastAccess) / this.Kt);
            i > 0 && (t.tokens = Math.min(t.tokens + i * this.Jt, this.Zt), t.lastAccess = t.lastAccess + i * this.Kt)
        }
        consumeRateLimit(t) {
            var e, i = Date.now(),
                r = String(t),
                s = this.$t[r];
            return s ? this.Yt(s, i) : this.$t[r] = s = {
                tokens: this.Zt,
                lastAccess: i
            }, 0 === s.tokens || (s.tokens--, 0 === s.tokens && (null == (e = this.Gt) || e.call(this, t)), 0 === s.tokens)
        }
        stop() {
            this.$t = {}
        }
    }
    var ut = "Mobile",
        ht = "iOS",
        dt = "Android",
        vt = "Tablet",
        ct = dt + " " + vt,
        ft = "iPad",
        pt = "Apple",
        gt = pt + " Watch",
        _t = "Safari",
        mt = "BlackBerry",
        yt = "Samsung",
        bt = yt + "Browser",
        wt = yt + " Internet",
        xt = "Chrome",
        Et = xt + " OS",
        St = xt + " " + ht,
        kt = "Internet Explorer",
        $t = kt + " " + ut,
        Pt = "Opera",
        Tt = Pt + " Mini",
        It = "Edge",
        Rt = "Microsoft " + It,
        Ct = "Firefox",
        Ft = Ct + " " + ht,
        Mt = "Nintendo",
        Ot = "PlayStation",
        At = "Xbox",
        Dt = dt + " " + ut,
        Lt = ut + " " + _t,
        jt = "Windows",
        zt = jt + " Phone",
        Nt = "Nokia",
        Ut = "Ouya",
        Bt = "Generic",
        Ht = Bt + " " + ut.toLowerCase(),
        qt = Bt + " " + vt.toLowerCase(),
        Gt = "Konqueror",
        Vt = "Oculus Browser",
        Wt = "Vivaldi",
        Jt = "Yandex",
        Kt = "Whale",
        Yt = "DuckDuckGo",
        Xt = "Pale Moon",
        Qt = "Waterfox",
        Zt = "Brave",
        te = "Google Search App",
        ee = "(\\d+(\\.\\d+)?)",
        ie = new RegExp("Version/" + ee),
        re = new RegExp(At, "i"),
        se = new RegExp(Ot + " \\w+", "i"),
        ne = new RegExp(Mt + " \\w+", "i"),
        oe = new RegExp(mt + "|PlayBook|BB10", "i"),
        ae = {
            "NT3.51": "NT 3.11",
            "NT4.0": "NT 4.0",
            "5.0": "2000",
            5.1: "XP",
            5.2: "XP",
            "6.0": "Vista",
            6.1: "7",
            6.2: "8",
            6.3: "8.1",
            6.4: "10",
            "10.0": "10"
        },
        le = function(t, e, i, r) {
            e = e || "";
            var s = function(t) {
                return null != t && t.brave ? Zt : null
            }(i);
            return s || (null != r && r.detectGoogleSearchApp && O(t, "GSA/") ? te : O(t, " OPR/") && O(t, "Mini") ? Tt : O(t, " OPR/") ? Pt : oe.test(t) ? mt : O(t, "IE" + ut) || O(t, "WPDesktop") ? $t : O(t, "OculusBrowser") ? Vt : O(t, bt) ? wt : O(t, It) || O(t, "Edg/") ? Rt : O(t, Wt + "/") ? Wt : O(t, "YaBrowser/") ? Jt : O(t, Kt + "/") ? Kt : O(t, Yt + "/") || O(t, "Ddg/") ? Yt : O(t, "FBIOS") ? "Facebook " + ut : O(t, "UCWEB") || O(t, "UCBrowser") ? "UC Browser" : O(t, "CriOS") ? St : O(t, "CrMo") || O(t, xt) ? xt : O(t, dt) && O(t, _t) ? Dt : O(t, "FxiOS") ? Ft : O(t.toLowerCase(), Gt.toLowerCase()) ? Gt : O(t, Zt + "/") ? Zt : ((t, e) => e && O(e, pt) || function(t) {
                return O(t, _t) && !O(t, xt) && !O(t, dt)
            }(t))(t, e) ? O(t, ut) ? Lt : _t : O(t, "PaleMoon/") ? Xt : O(t, Qt + "/") ? Qt : O(t, Ct) ? Ct : O(t, "MSIE") || O(t, "Trident/") ? kt : O(t, "Gecko") ? Ct : "")
        },
        ue = {
            [$t]: [new RegExp("rv:" + ee)],
            [Rt]: [new RegExp(It + "?\\/" + ee)],
            [xt]: [new RegExp("(" + xt + "|CrMo)\\/" + ee)],
            [St]: [new RegExp("CriOS\\/" + ee)],
            "UC Browser": [new RegExp("(UCBrowser|UCWEB)\\/" + ee)],
            [_t]: [ie],
            [Lt]: [ie],
            [Pt]: [new RegExp("(Opera|OPR)\\/" + ee)],
            [Ct]: [new RegExp(Ct + "\\/" + ee)],
            [Ft]: [new RegExp("FxiOS\\/" + ee)],
            [Gt]: [new RegExp("Konqueror[:/]?" + ee, "i")],
            [mt]: [new RegExp(mt + " " + ee), ie],
            [Dt]: [new RegExp("android\\s" + ee, "i")],
            [wt]: [new RegExp(bt + "\\/" + ee)],
            [Vt]: [new RegExp("OculusBrowser\\/" + ee)],
            [Wt]: [new RegExp(Wt + "\\/" + ee)],
            [Jt]: [new RegExp("YaBrowser\\/" + ee)],
            [Kt]: [new RegExp(Kt + "\\/" + ee)],
            [Zt]: [new RegExp(Zt + "\\/" + ee)],
            [Yt]: [new RegExp("(DuckDuckGo|Ddg)\\/" + ee)],
            [Xt]: [new RegExp("PaleMoon\\/" + ee)],
            [Qt]: [new RegExp(Qt + "\\/" + ee)],
            [te]: [new RegExp("GSA\\/" + ee)],
            [kt]: [new RegExp("(rv:|MSIE )" + ee)],
            Mozilla: [new RegExp("rv:" + ee)]
        },
        he = function(t, e, i, r) {
            var s = le(t, e, i, r),
                n = ue[s];
            if (q(n)) return null;
            for (var o = 0; n.length > o; o++) {
                var a = t.match(n[o]);
                if (a) return parseFloat(a[a.length - 2])
            }
            return null
        },
        de = [
            [new RegExp(At + "; " + At + " (.*?)[);]", "i"), t => [At, t && t[1] || ""]],
            [new RegExp(Mt, "i"), [Mt, ""]],
            [new RegExp(Ot, "i"), [Ot, ""]],
            [oe, [mt, ""]],
            [new RegExp(jt, "i"), (t, e) => {
                if (/Phone/.test(e) || /WPDesktop/.test(e)) return [zt, ""];
                if (new RegExp(ut).test(e) && !/IEMobile\b/.test(e)) return [jt + " " + ut, ""];
                var i = /Windows NT ([0-9.]+)/i.exec(e);
                if (i && i[1]) {
                    var r = ae[i[1]] || "";
                    return /arm/i.test(e) && (r = "RT"), [jt, r]
                }
                return [jt, ""]
            }],
            [/((iPhone|iPad|iPod).*?OS (\d+)_(\d+)_?(\d+)?|iPhone)/, t => t && t[3] ? [ht, [t[3], t[4], t[5] || "0"].join(".")] : [ht, ""]],
            [/(watch.*\/(\d+\.\d+\.\d+)|watch os,(\d+\.\d+),)/i, t => {
                var e = "";
                return t && t.length >= 3 && (e = q(t[2]) ? t[3] : t[2]), ["watchOS", e]
            }],
            [new RegExp("(" + dt + " (\\d+)\\.(\\d+)\\.?(\\d+)?|" + dt + ")", "i"), t => t && t[2] ? [dt, [t[2], t[3], t[4] || "0"].join(".")] : [dt, ""]],
            [/Mac OS X (\d+)[_.](\d+)[_.]?(\d+)?/i, t => {
                var e = ["Mac OS X", ""];
                return t && t[1] && (e[1] = [t[1], t[2], t[3] || "0"].join(".")), e
            }],
            [/Mac/i, ["Mac OS X", ""]],
            [/CrOS/, [Et, ""]],
            [/Linux|debian/i, ["Linux", ""]]
        ],
        ve = function(t) {
            return ne.test(t) ? Mt : se.test(t) ? Ot : re.test(t) ? At : new RegExp(Ut, "i").test(t) ? Ut : new RegExp("(" + zt + "|WPDesktop)", "i").test(t) ? zt : /iPad/.test(t) ? ft : /iPod/.test(t) ? "iPod Touch" : /iPhone/.test(t) ? "iPhone" : /(watch)(?: ?os[,/]|\d,\d\/)[\d.]+/i.test(t) ? gt : oe.test(t) ? mt : /(kobo)\s(ereader|touch)/i.test(t) ? "Kobo" : new RegExp(Nt, "i").test(t) ? Nt : /(kf[a-z]{2}wi|aeo[c-r]{2})( bui|\))/i.test(t) || /(kf[a-z]+)( bui|\)).+silk\//i.test(t) ? "Kindle Fire" : /(Android|ZTE)/i.test(t) ? new RegExp(ut).test(t) && !/(9138B|TB782B|Nexus [97]|pixel c|HUAWEISHT|BTV|noble nook|smart ultra 6)/i.test(t) || /pixel[\daxl ]{1,6}/i.test(t) && !/pixel c/i.test(t) || /(huaweimed-al00|tah-|APA|SM-G92|i980|zte|U304AA)/i.test(t) || /lmy47v/i.test(t) && !/QTAQZ3/i.test(t) ? dt : ct : new RegExp("(pda|" + ut + ")", "i").test(t) ? Ht : new RegExp(vt, "i").test(t) && !new RegExp(vt + " pc", "i").test(t) ? qt : ""
        },
        ce = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

    function fe(t, e) {
        return "string" == typeof(i = t) && ce.test(i) ? t : e();
        var i
    }

    function pe(t, e) {
        var i = setTimeout(t, e);
        return (null == i ? void 0 : i.unref) && (null == i || i.unref()), i
    }
    var ge = t => t instanceof Error,
        _e = {
            trace: {
                text: "TRACE",
                number: 1
            },
            debug: {
                text: "DEBUG",
                number: 5
            },
            info: {
                text: "INFO",
                number: 9
            },
            warn: {
                text: "WARN",
                number: 13
            },
            error: {
                text: "ERROR",
                number: 17
            },
            fatal: {
                text: "FATAL",
                number: 21
            }
        },
        me = _e.info;

    function ye(t) {
        if (X(t)) return {
            boolValue: t
        };
        if ("number" == typeof t) return Number.isFinite(t) ? Number.isInteger(t) ? {
            intValue: t
        } : {
            doubleValue: t
        } : {
            stringValue: String(t)
        };
        if ("string" == typeof t) return {
            stringValue: t
        };
        if (N(t)) return {
            arrayValue: {
                values: t.map((t => ye(t)))
            }
        };
        try {
            return {
                stringValue: JSON.stringify(t)
            }
        } catch (e) {
            return {
                stringValue: String(t)
            }
        }
    }

    function be(t) {
        var e = [];
        for (var i in t) {
            var r = t[i];
            W(r) || q(r) || e.push({
                key: i,
                value: ye(r)
            })
        }
        return e
    }

    function we(t, e) {
        var i = t.level || "info",
            {
                text: r,
                number: s
            } = _e[i] || me,
            n = String(Date.now()) + "000000",
            o = {};
        e.distinctId && (o.posthogDistinctId = e.distinctId), e.sessionId && (o.sessionId = e.sessionId), e.currentUrl && (o["url.full"] = e.currentUrl), e.screenName && (o["screen.name"] = e.screenName), e.appState && (o["app.state"] = e.appState), e.activeFeatureFlags && e.activeFeatureFlags.length > 0 && (o.feature_flags = e.activeFeatureFlags);
        var a = p({}, o, t.attributes || {}),
            l = {
                timeUnixNano: n,
                observedTimeUnixNano: n,
                severityNumber: s,
                severityText: r,
                body: {
                    stringValue: t.body
                },
                attributes: be(a)
            };
        return t.trace_id && (l.traceId = t.trace_id), t.span_id && (l.spanId = t.span_id), q(t.trace_flags) || (l.flags = t.trace_flags), l
    }

    function xe(t, e, i) {
        return p({}, t.resourceAttributes, {
            "service.name": t.serviceName || "unknown_service"
        }, t.environment && {
            "deployment.environment": t.environment
        }, t.serviceVersion && {
            "service.version": t.serviceVersion
        }, {
            "telemetry.sdk.name": e,
            "telemetry.sdk.version": i
        })
    }

    function Ee(t, e, i, r) {
        return {
            resourceLogs: [{
                resource: {
                    attributes: be(e)
                },
                scopeLogs: [{
                    scope: {
                        name: i,
                        version: r
                    },
                    logRecords: t
                }]
            }]
        }
    }
    let Se = class {
        constructor(t, e, i, r, s, n) {
            var o;
            void 0 === n && (n = () => Promise.resolve()), this._instance = t, this.Dt = e, this.Qt = i, this.Xt = r, this.er = s, this.tr = n, this.rr = null, this.ir = 0, this.nr = 0, this.sr = 0, this.ar = 0, this.lr = !1, this.ur = e.maxBufferSize, this.ot = Math.max(null !== (o = e.maxQueueSize) && void 0 !== o ? o : e.maxBufferSize, e.maxBufferSize), this.hr = e.flushIntervalMs, this.cr = e.maxBatchRecordsPerPost, this.dr = e.rateCapWindowMs, this.vr = e.maxLogsPerInterval
        }
        reset() {
            this.pr(), this.rr = null, this.sr = 0, this.ar = 0, this.lr = !1, this.ir = 0, this.nr = 0, this.cr = this.Dt.maxBatchRecordsPerPost
        }
        onReconnect() {
            this.nr = 0, this.gr()
        }
        captureLog(t) {
            if (!this._instance.isDisabled && !this._instance.optedOut && null != t && t.body) {
                var e = this.mr(t);
                if (null !== e)
                    if (e.body) {
                        if (this.yr()) {
                            var i = {
                                record: we(e, this.Xt())
                            };
                            this.er((() => this.br(i)))
                        }
                    } else this.Qt.info("Log was rejected in beforeSend function")
            }
        }
        mr(t) {
            var e = this.Dt.beforeSend;
            if (!e) return t;
            var i = N(e) ? e : [e],
                r = t;
            for (var s of i) try {
                var n = s(r);
                if (!n) return this.Qt.info("Log was rejected in beforeSend function"), null;
                r = n
            } catch (t) {
                return this.Qt.error("Error in beforeSend function for log:", t), null
            }
            return r
        }
        yr() {
            if (void 0 === this.vr) return !0;
            var t = Date.now(),
                e = t - this.sr;
            return this.dr > e && e >= 0 || (this.sr = t, this.ar = 0, this.lr = !1), this.vr > this.ar ? (this.ar++, !0) : (this.lr || (this.Qt.warn("captureLog dropping logs: exceeded " + this.vr + " logs per " + this.dr + "ms"), this.lr = !0), !1)
        }
        flush() {
            var t = this;
            return f((function*() {
                if (!t._instance.isDisabled) return t.rr || (t.rr = t._r().finally((() => {
                    t.rr = null
                }))), t.rr
            }))()
        }
        _r() {
            var t = this;
            return f((function*() {
                var e;
                t.pr();
                var i = null !== (e = t._instance.getPersistedProperty(w.LogsQueue)) && void 0 !== e ? e : [];
                if (0 !== i.length)
                    for (var r = i.length, s = 0; i.length > 0 && r > s;) {
                        var n;
                        t.ir = 0;
                        var o = Math.min(i.length, t.cr),
                            a = i.slice(0, o),
                            l = Ee(a.map((t => t.record)), t.wr(), t._instance.getLibraryId(), t._instance.getLibraryVersion()),
                            u = yield t._instance.kr(l);
                        if ("too-large" === u.kind && a.length > 1) t.cr = Math.max(1, Math.floor(a.length / 2)), t.Qt.warn("Received 413 when sending logs batch of size " + a.length + ", reducing batch size to " + t.cr);
                        else {
                            if ("retry-later" === u.kind) throw u.error;
                            if ("too-large" === u.kind ? t.Qt.warn("Dropping a single log record after 413 with batch size 1 — the record is larger than the server cap and cannot be split further.") : "ok" === u.kind && t.Dt.maxBatchRecordsPerPost > t.cr && (t.cr = Math.min(t.Dt.maxBatchRecordsPerPost, t.cr + 1)), yield t.Sr(a.length), i = null !== (n = t._instance.getPersistedProperty(w.LogsQueue)) && void 0 !== n ? n : [], s += a.length, "fatal" === u.kind) throw u.error
                        }
                    }
            }))()
        }
        Sr(t) {
            var e = this;
            return f((function*() {
                var i, r = Math.max(0, t - e.ir),
                    s = null !== (i = e._instance.getPersistedProperty(w.LogsQueue)) && void 0 !== i ? i : [];
                e._instance.setPersistedProperty(w.LogsQueue, s.slice(r)), yield e.tr()
            }))()
        }
        wr() {
            return xe(this.Dt, this._instance.getLibraryId(), this._instance.getLibraryVersion())
        }
        br(t) {
            var e;
            if (!this._instance.optedOut) {
                var i = null !== (e = this._instance.getPersistedProperty(w.LogsQueue)) && void 0 !== e ? e : [];
                this.ot > i.length || (i.shift(), this.ir++, this.Qt.info("Logs queue is full, dropping oldest record.")), i.push(t), this._instance.setPersistedProperty(w.LogsQueue, i), this.ur > i.length ? this.Cr() : this.gr()
            }
        }
        Cr(t) {
            void 0 === t && (t = this.hr), this.Ir || (this.Ir = pe((() => {
                this.Ir = void 0, this.gr()
            }), t))
        }
        Tr() {
            var t = Math.min(Math.max(0, this.nr - 1), 6);
            return this.hr * Math.pow(2, t)
        }
        Er() {
            var t = this._instance.getPersistedProperty(w.LogsQueue);
            return !!t && t.length > 0
        }
        shutdown(t) {
            var e = this;
            return f((function*() {
                e.pr();
                var i = e.flush().catch((() => {}));
                void 0 !== t ? yield Promise.race([i, new Promise((e => pe(e, t)))]): yield i
            }))()
        }
        flushWithTimeout(t) {
            var e = this;
            return f((function*() {
                var i = !1,
                    r = e.flush(),
                    s = new Promise((e => pe((() => {
                        i = !0, e()
                    }), t)));
                try {
                    yield Promise.race([r, s])
                } finally {
                    i && r.catch((() => {}))
                }
            }))()
        }
        gr() {
            this.flush().then((() => {
                this.nr = 0
            }), (t => {
                this.nr++, this.Qt.error("PostHog logs flush failed:", t)
            })).finally((() => {
                !this._instance.isDisabled && this.Er() && this.Cr(this.Tr())
            }))
        }
        pr() {
            this.Ir && (clearTimeout(this.Ir), this.Ir = void 0)
        }
    };
    var ke, $e, Pe;

    function Te(t) {
        var e = globalThis._posthogChunkIds;
        if (e) {
            var i = Object.keys(e);
            return Pe && i.length === $e || ($e = i.length, Pe = i.reduce(((i, r) => {
                ke || (ke = {});
                var s = ke[r];
                if (s) i[s[0]] = s[1];
                else
                    for (var n = t(r), o = n.length - 1; o >= 0; o--) {
                        var a = n[o],
                            l = null == a ? void 0 : a.filename,
                            u = e[r];
                        if (l && u) {
                            i[l] = u, ke[r] = [l, u];
                            break
                        }
                    }
                return i
            }), {})), Pe
        }
    }
    class Ie {
        constructor(t, e, i) {
            void 0 === i && (i = []), this.coercers = t, this.stackParser = e, this.modifiers = i
        }
        buildFromUnknown(t, e) {
            void 0 === e && (e = {});
            var i = e && e.mechanism || {
                    handled: !0,
                    type: "generic"
                },
                r = this.buildCoercingContext(i, e, 0).apply(t),
                s = this.buildParsingContext(e),
                n = this.parseStacktrace(r, s);
            return {
                $exception_list: this.convertToExceptionList(n, i),
                $exception_level: "error"
            }
        }
        modifyFrames(t) {
            var e = this;
            return f((function*() {
                for (var i of t) i.stacktrace && i.stacktrace.frames && N(i.stacktrace.frames) && (i.stacktrace.frames = yield e.applyModifiers(i.stacktrace.frames));
                return t
            }))()
        }
        coerceFallback(t) {
            var e;
            return {
                type: "Error",
                value: "Unknown error",
                stack: null == (e = t.syntheticException) ? void 0 : e.stack,
                synthetic: !0
            }
        }
        parseStacktrace(t, e) {
            var i, r;
            return null != t.cause && (i = this.parseStacktrace(t.cause, e)), "" != t.stack && null != t.stack && (r = this.applyChunkIds(this.stackParser(t.stack, t.synthetic ? e.skipFirstLines : 0), e.chunkIdMap)), p({}, t, {
                cause: i,
                stack: r
            })
        }
        applyChunkIds(t, e) {
            return t.map((t => (t.filename && e && (t.chunk_id = e[t.filename]), t)))
        }
        applyCoercers(t, e) {
            for (var i of this.coercers)
                if (i.match(t)) return i.coerce(t, e);
            return this.coerceFallback(e)
        }
        applyModifiers(t) {
            var e = this;
            return f((function*() {
                var i = t;
                for (var r of e.modifiers) i = yield r(i);
                return i
            }))()
        }
        convertToExceptionList(t, e) {
            var i, r, s, n = {
                type: t.type,
                value: t.value,
                mechanism: {
                    type: null !== (i = e.type) && void 0 !== i ? i : "generic",
                    handled: null === (r = e.handled) || void 0 === r || r,
                    synthetic: null !== (s = t.synthetic) && void 0 !== s && s
                }
            };
            t.stack && (n.stacktrace = {
                type: "raw",
                frames: t.stack
            });
            var o = [n];
            return null != t.cause && o.push(...this.convertToExceptionList(t.cause, p({}, e, {
                handled: !0
            }))), o
        }
        buildParsingContext(t) {
            var e;
            return {
                chunkIdMap: Te(this.stackParser),
                skipFirstLines: null !== (e = t.skipFirstLines) && void 0 !== e ? e : 1
            }
        }
        buildCoercingContext(t, e, i) {
            void 0 === i && (i = 0);
            var r = (i, r) => {
                if (4 >= r) {
                    var s = this.buildCoercingContext(t, e, r);
                    return this.applyCoercers(i, s)
                }
            };
            return p({}, e, {
                syntheticException: 0 == i ? e.syntheticException : void 0,
                mechanism: t,
                apply: t => r(t, i),
                next: t => r(t, i + 1)
            })
        }
    }
    var Re = "?";

    function Ce(t, e, i, r, s) {
        var n = {
            platform: t,
            filename: e,
            function: "<anonymous>" === i ? Re : i,
            in_app: !0
        };
        return q(r) || (n.lineno = r), q(s) || (n.colno = s), n
    }
    var Fe = (t, e) => {
            var i = -1 !== t.indexOf("safari-extension"),
                r = -1 !== t.indexOf("safari-web-extension");
            return i || r ? [-1 !== t.indexOf("@") ? t.split("@")[0] : Re, i ? "safari-extension:" + e : "safari-web-extension:" + e] : [t, e]
        },
        Me = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i,
        Oe = /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,
        Ae = /\((\S*)(?::(\d+))(?::(\d+))\)/,
        De = (t, e) => {
            var i = Me.exec(t);
            if (i) {
                var [, r, s, n] = i;
                return Ce(e, r, Re, +s, +n)
            }
            var o = Oe.exec(t);
            if (o) {
                if (o[2] && 0 === o[2].indexOf("eval")) {
                    var a = Ae.exec(o[2]);
                    a && (o[2] = a[1], o[3] = a[2], o[4] = a[3])
                }
                var [l, u] = Fe(o[1] || Re, o[2]);
                return Ce(e, u, l, o[3] ? +o[3] : void 0, o[4] ? +o[4] : void 0)
            }
        },
        Le = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i,
        je = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i,
        ze = (t, e) => {
            var i = Le.exec(t);
            if (i) {
                if (i[3] && i[3].indexOf(" > eval") > -1) {
                    var r = je.exec(i[3]);
                    r && (i[1] = i[1] || "eval", i[3] = r[1], i[4] = r[2], i[5] = "")
                }
                var s = i[3],
                    n = i[1] || Re;
                return [n, s] = Fe(n, s), Ce(e, s, n, i[4] ? +i[4] : void 0, i[5] ? +i[5] : void 0)
            }
        },
        Ne = /\(error: (.*)\)/;
    class Ue {
        match(t) {
            return this.isDOMException(t) || this.isDOMError(t)
        }
        coerce(t, e) {
            var i = G(t.stack);
            return {
                type: this.getType(t),
                value: this.getValue(t),
                stack: i ? t.stack : void 0,
                cause: t.cause ? e.next(t.cause) : void 0,
                synthetic: !1
            }
        }
        getType(t) {
            return this.isDOMError(t) ? "DOMError" : "DOMException"
        }
        getValue(t) {
            var e = t.name || (this.isDOMError(t) ? "DOMError" : "DOMException");
            return t.message ? e + ": " + t.message : e
        }
        isDOMException(t) {
            return it(t, "DOMException")
        }
        isDOMError(t) {
            return it(t, "DOMError")
        }
    }
    class Be {
        match(t) {
            return (t => t instanceof Error)(t)
        }
        coerce(t, e) {
            return {
                type: this.getType(t),
                value: this.getMessage(t, e),
                stack: this.getStack(t),
                cause: t.cause ? e.next(t.cause) : void 0,
                synthetic: !1
            }
        }
        getType(t) {
            return t.name || t.constructor.name
        }
        getMessage(t, e) {
            var i = t.message;
            return String(i.error && "string" == typeof i.error.message ? i.error.message : i)
        }
        getStack(t) {
            return t.stacktrace || t.stack || void 0
        }
    }
    class He {
        constructor() {}
        match(t) {
            return it(t, "ErrorEvent") && null != t.error
        }
        coerce(t, e) {
            var i;
            return e.apply(t.error) || {
                type: "ErrorEvent",
                value: t.message,
                stack: null == (i = e.syntheticException) ? void 0 : i.stack,
                synthetic: !0
            }
        }
    }
    var qe = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?(.*)$/i;
    class Ge {
        match(t) {
            return "string" == typeof t
        }
        coerce(t, e) {
            var i, [r, s] = this.getInfos(t);
            return {
                type: null != r ? r : "Error",
                value: null != s ? s : t,
                stack: null == (i = e.syntheticException) ? void 0 : i.stack,
                synthetic: !0
            }
        }
        getInfos(t) {
            var e = "Error",
                i = t,
                r = t.match(qe);
            return r && (e = r[1], i = r[2]), [e, i]
        }
    }
    var Ve = ["fatal", "error", "warning", "log", "info", "debug"];

    function We(t, e) {
        void 0 === e && (e = 40);
        var i = Object.keys(t);
        if (i.sort(), !i.length) return "[object has no keys]";
        for (var r = i.length; r > 0; r--) {
            var s = i.slice(0, r).join(", ");
            if (e >= s.length) return r === i.length ? s : s.length > e ? s.slice(0, e) + "..." : s
        }
        return ""
    }
    class Je {
        match(t) {
            return "object" == typeof t && null !== t
        }
        coerce(t, e) {
            var i, r = this.getErrorPropertyFromObject(t);
            return r ? e.apply(r) : {
                type: this.getType(t),
                value: this.getValue(t),
                stack: null == (i = e.syntheticException) ? void 0 : i.stack,
                level: this.isSeverityLevel(t.level) ? t.level : "error",
                synthetic: !0
            }
        }
        getType(t) {
            return rt(t) ? t.constructor.name : "Error"
        }
        getValue(t) {
            if ("name" in t && "string" == typeof t.name) {
                var e = "'" + t.name + "' captured as exception";
                return "message" in t && "string" == typeof t.message && (e += " with message: '" + t.message + "'"), e
            }
            if ("message" in t && "string" == typeof t.message) return t.message;
            var i = this.getObjectClassName(t);
            return (i && "Object" !== i ? "'" + i + "'" : "Object") + " captured as exception with keys: " + We(t)
        }
        isSeverityLevel(t) {
            return G(t) && !V(t) && Ve.indexOf(t) >= 0
        }
        getErrorPropertyFromObject(t) {
            for (var e in t)
                if ({}.hasOwnProperty.call(t, e)) {
                    var i = t[e];
                    if (ge(i)) return i
                }
        }
        getObjectClassName(t) {
            try {
                var e = Object.getPrototypeOf(t);
                return e ? e.constructor.name : void 0
            } catch (t) {
                return
            }
        }
    }
    class Ke {
        match(t) {
            return rt(t)
        }
        coerce(t, e) {
            var i, r = t.constructor.name;
            return {
                type: r,
                value: r + " captured as exception with keys: " + We(t),
                stack: null == (i = e.syntheticException) ? void 0 : i.stack,
                synthetic: !0
            }
        }
    }
    class Ye {
        match(t) {
            return et(t)
        }
        coerce(t, e) {
            var i;
            return {
                type: "Error",
                value: "Primitive value captured as exception: " + String(t),
                stack: null == (i = e.syntheticException) ? void 0 : i.stack,
                synthetic: !0
            }
        }
    }
    class Xe {
        match(t) {
            return it(t, "PromiseRejectionEvent") || this.isCustomEventWrappingRejection(t)
        }
        isCustomEventWrappingRejection(t) {
            if (!rt(t)) return !1;
            try {
                var e = t.detail;
                return null != e && "object" == typeof e && "reason" in e
            } catch (t) {
                return !1
            }
        }
        coerce(t, e) {
            var i, r = this.getUnhandledRejectionReason(t);
            return et(r) ? {
                type: "UnhandledRejection",
                value: "Non-Error promise rejection captured with value: " + String(r),
                stack: null == (i = e.syntheticException) ? void 0 : i.stack,
                synthetic: !0
            } : e.apply(r)
        }
        getUnhandledRejectionReason(t) {
            try {
                if ("reason" in t) return t.reason;
                if ("detail" in t && null != t.detail && "object" == typeof t.detail && "reason" in t.detail) return t.detail.reason
            } catch (t) {}
            return t
        }
    }
    var Qe = "$message",
        Ze = "$timestamp",
        ti = new Set([Qe, Ze]),
        ei = {
            enabled: !0,
            max_bytes: 32768
        };

    function ii(t) {
        var e;
        return t ? {
            enabled: null !== (e = t.enabled) && void 0 !== e ? e : ei.enabled,
            max_bytes: si(t.max_bytes, ei.max_bytes)
        } : p({}, ei)
    }
    class ri {
        constructor(t) {
            this.Mr = [], this.Pr = 0, this.Dt = ii(t)
        }
        setConfig(t) {
            this.Dt = ii(t), this.Rr()
        }
        add(t) {
            var e = function(t) {
                var e = function(t) {
                    var e = new WeakSet;
                    try {
                        return JSON.stringify(t, ((t, i) => {
                            if ("bigint" == typeof i) return i.toString();
                            if ("function" != typeof i && "symbol" != typeof i) {
                                if (i instanceof Date) return i.toISOString();
                                if (i instanceof Error) return {
                                    name: i.name,
                                    message: i.message,
                                    stack: i.stack
                                };
                                if (i && "object" == typeof i) {
                                    if (e.has(i)) return "[Circular]";
                                    e.add(i)
                                }
                                return i
                            }
                        }))
                    } catch (t) {
                        return
                    }
                }(t);
                if (e) try {
                    var i = JSON.parse(e);
                    if (!B(i)) return;
                    var r = i,
                        s = r[Qe],
                        n = r[Ze];
                    if (!G(s) || 0 === s.trim().length) return;
                    if (!G(n) && !K(n)) return;
                    return {
                        step: r,
                        json: e
                    }
                } catch (t) {
                    return
                }
            }(t);
            if (e) {
                var i = function(t) {
                    if ("undefined" != typeof TextEncoder) return (new TextEncoder).encode(t).length;
                    for (var e = encodeURIComponent(t), i = 0, r = 0; e.length > r; r++) "%" === e[r] ? (i += 1, r += 2) : i += 1;
                    return i
                }(e.json);
                i > this.Dt.max_bytes || (this.Mr.push({
                    step: e.step,
                    bytes: i
                }), this.Pr += i, this.Rr())
            }
        }
        getAttachable() {
            return this.Mr.map((t => t.step))
        }
        clear() {
            this.Mr = [], this.Pr = 0
        }
        size() {
            return this.Mr.length
        }
        Rr() {
            for (; this.Pr > this.Dt.max_bytes && this.Mr.length > 0;) {
                var t = this.Mr.shift();
                t && (this.Pr -= t.bytes)
            }
        }
    }

    function si(t, e) {
        if (!K(t) || t === 1 / 0 || t === -1 / 0) return e;
        var i = Math.floor(t);
        return 0 > i ? e : i
    }
    var ni = function(e, i) {
            var {
                debugEnabled: r
            } = void 0 === i ? {} : i, s = {
                k(i) {
                    if (t && (v.DEBUG || h.POSTHOG_DEBUG || r) && !q(t.console) && t.console) {
                        for (var s = ("__rrweb_original__" in t.console[i] ? t.console[i].__rrweb_original__ : t.console[i]), n = arguments.length, o = new Array(n > 1 ? n - 1 : 0), a = 1; n > a; a++) o[a - 1] = arguments[a];
                        s(e, ...o)
                    }
                },
                debug() {
                    for (var t = arguments.length, e = new Array(t), i = 0; t > i; i++) e[i] = arguments[i];
                    s.k("debug", ...e)
                },
                info() {
                    for (var t = arguments.length, e = new Array(t), i = 0; t > i; i++) e[i] = arguments[i];
                    s.k("log", ...e)
                },
                warn() {
                    for (var t = arguments.length, e = new Array(t), i = 0; t > i; i++) e[i] = arguments[i];
                    s.k("warn", ...e)
                },
                error() {
                    for (var t = arguments.length, e = new Array(t), i = 0; t > i; i++) e[i] = arguments[i];
                    s.k("error", ...e)
                },
                critical() {
                    for (var t = arguments.length, i = new Array(t), r = 0; t > r; r++) i[r] = arguments[r];
                    console.error(e, ...i)
                },
                uninitializedWarning(t) {
                    s.error("You must initialize PostHog before calling " + t)
                },
                createLogger: (t, i) => ni(e + " " + t, i)
            };
            return s
        },
        oi = ni("[PostHog.js]"),
        ai = oi.createLogger,
        li = ai("[ExternalScriptsLoader]"),
        ui = (t, e, i) => {
            if (t.config.disable_external_dependency_loading) return li.warn(e + " was requested but loading of external scripts is disabled."), i("Loading of external scripts is disabled");
            var s = null == r ? void 0 : r.querySelectorAll("script");
            if (s)
                for (var n, o = function() {
                        if (s[a].src === e) {
                            var t = s[a];
                            return t.__posthog_loading_callback_fired ? {
                                v: i()
                            } : (t.addEventListener("load", (e => {
                                t.__posthog_loading_callback_fired = !0, i(void 0, e)
                            })), t.onerror = t => i(t), {
                                v: void 0
                            })
                        }
                    }, a = 0; s.length > a; a++)
                    if (n = o()) return n.v;
            var l = () => {
                if (!r) return i("document not found");
                var s = r.createElement("script");
                if (s.type = "text/javascript", s.crossOrigin = "anonymous", s.src = e, s.onload = t => {
                        s.__posthog_loading_callback_fired = !0, i(void 0, t)
                    }, s.onerror = t => i(t), t.config.prepare_external_dependency_script && (s = t.config.prepare_external_dependency_script(s)), !s) return i("prepare_external_dependency_script returned null");
                if ("head" === t.config.external_scripts_inject_target) r.head.appendChild(s);
                else {
                    var n, o = r.querySelectorAll("body > script");
                    o.length > 0 ? null == (n = o[0].parentNode) || n.insertBefore(s, o[0]) : r.body.appendChild(s)
                }
            };
            null != r && r.body ? l() : null == r || r.addEventListener("DOMContentLoaded", l)
        };
    h.__PosthogExtensions__ = h.__PosthogExtensions__ || {}, h.__PosthogExtensions__.loadExternalDependency = (t, e, i) => {
        if ("remote-config" !== e) {
            var r;
            if (t.config.strict_script_versioning) r = t.requestRouter.endpointFor("assets", "/static/" + t.version + "/" + e + ".js");
            else {
                var s = "/static/" + e + ".js?v=" + t.version;
                if ("toolbar" === e) {
                    var n = 3e5;
                    s = s + "&t=" + Math.floor(Date.now() / n) * n
                }
                r = t.requestRouter.endpointFor("assets", s)
            }
            ui(t, r, i)
        } else {
            var o = t.requestRouter.endpointFor("assets", "/array/" + t.config.token + "/config.js");
            ui(t, o, i)
        }
    }, h.__PosthogExtensions__.loadSiteApp = (t, e, i) => {
        var r = t.requestRouter.endpointFor("api", e);
        ui(t, r, i)
    };
    var hi = "$people_distinct_id",
        di = "$device_id",
        vi = "__alias",
        ci = "__timers",
        fi = "$autocapture_disabled_server_side",
        pi = "$heatmaps_enabled_server_side",
        gi = "$exception_capture_enabled_server_side",
        _i = "$error_tracking_suppression_rules",
        mi = "$error_tracking_capture_extension_exceptions",
        yi = "$web_vitals_enabled_server_side",
        bi = "$dead_clicks_enabled_server_side",
        wi = "$product_tours_enabled_server_side",
        xi = "$web_vitals_allowed_metrics",
        Ei = "$session_recording_remote_config",
        Si = "$replay_sample_rate",
        ki = "$replay_override_sampling",
        $i = "$replay_override_linked_flag",
        Pi = "$replay_override_url_trigger",
        Ti = "$replay_override_event_trigger",
        Ii = "$sesid",
        Ri = "$session_is_sampled",
        Ci = "$enabled_feature_flags",
        Fi = "$active_feature_flags",
        Mi = "$early_access_features",
        Oi = "$feature_flag_details",
        Ai = "$feature_flag_payloads",
        Di = "$feature_flag_request_id",
        Li = "$override_feature_flags",
        ji = "$override_feature_flag_payloads",
        zi = "$stored_person_properties",
        Ni = "$stored_group_properties",
        Ui = "$surveys",
        Bi = "$surveys_loaded_at",
        Hi = "$surveys_activated",
        qi = "ph_product_tours",
        Gi = "$flag_call_reported",
        Vi = "$flag_call_reported_session_id",
        Wi = "$feature_flag_errors",
        Ji = "$feature_flag_evaluated_at",
        Ki = "$user_state",
        Yi = "$client_session_props",
        Xi = "$capture_rate_limit",
        Qi = "$initial_campaign_params",
        Zi = "$initial_referrer_info",
        tr = "$initial_person_info",
        er = "$epp",
        ir = "__POSTHOG_TOOLBAR__",
        rr = "$posthog_cookieless",
        sr = "$sdk_debug_extensions_init_method",
        nr = "$sdk_debug_extensions_init_time_ms",
        or = "$sdk_debug_recording_script_not_loaded",
        ar = "PostHog loadExternalDependency extension not found.",
        lr = "on_reject",
        ur = "always",
        hr = "anonymous",
        dr = "identified",
        vr = "identified_only",
        cr = "visibilitychange",
        fr = "beforeunload",
        pr = "$pageview",
        gr = "$pageleave",
        _r = "$identify",
        mr = "$groupidentify";

    function yr(t, e) {
        N(t) && t.forEach(e)
    }

    function br(t, e) {
        if (!J(t))
            if (N(t)) t.forEach(e);
            else if (Q(t)) t.forEach(((t, i) => e(t, i)));
        else
            for (var i in t) j.call(t, i) && e(t[i], i)
    }
    var wr = function(t) {
        for (var e = arguments.length, i = new Array(e > 1 ? e - 1 : 0), r = 1; e > r; r++) i[r - 1] = arguments[r];
        for (var s of i)
            for (var n in s) void 0 !== s[n] && (t[n] = s[n]);
        return t
    };

    function xr(t) {
        for (var e = Object.keys(t), i = e.length, r = new Array(i); i--;) r[i] = [e[i], t[e[i]]];
        return r
    }
    var Er = function(t) {
            try {
                return t()
            } catch (t) {
                return
            }
        },
        Sr = function(t) {
            return function() {
                try {
                    for (var e = arguments.length, i = new Array(e), r = 0; e > r; r++) i[r] = arguments[r];
                    return t.apply(this, i)
                } catch (t) {
                    oi.critical("Implementation error. Please turn on debug mode and open a ticket on https://app.posthog.com/home#panel=support%3Asupport%3A."), oi.critical(t)
                }
            }
        },
        kr = function(t) {
            var e = {};
            return br(t, (function(t, i) {
                (G(t) && t.length > 0 || K(t)) && (e[i] = t)
            })), e
        };
    var $r = ["herokuapp.com", "vercel.app", "netlify.app"];

    function Pr(t) {
        var e = null == t ? void 0 : t.hostname;
        if (!G(e)) return !1;
        var i = e.split(".").slice(-2).join(".");
        for (var r of $r)
            if (i === r) return !1;
        return !0
    }

    function Tr(t, e, i, r) {
        var {
            capture: s = !1,
            passive: n = !0
        } = null != r ? r : {};
        null == t || t.addEventListener(e, i, {
            capture: s,
            passive: n
        })
    }

    function Ir(t) {
        return "ph_toolbar_internal" === t.name
    }
    Math.trunc || (Math.trunc = function(t) {
        return 0 > t ? Math.ceil(t) : Math.floor(t)
    }), Number.isInteger || (Number.isInteger = function(t) {
        return K(t) && isFinite(t) && Math.floor(t) === t
    });
    class Rr {
        constructor(t) {
            if (this.bytes = t, 16 !== t.length) throw new TypeError("not 128-bit length")
        }
        static fromFieldsV7(t, e, i, r) {
            if (!Number.isInteger(t) || !Number.isInteger(e) || !Number.isInteger(i) || !Number.isInteger(r) || 0 > t || 0 > e || 0 > i || 0 > r || t > 0xffffffffffff || e > 4095 || i > 1073741823 || r > 4294967295) throw new RangeError("invalid field value");
            var s = new Uint8Array(16);
            return s[0] = t / Math.pow(2, 40), s[1] = t / Math.pow(2, 32), s[2] = t / Math.pow(2, 24), s[3] = t / Math.pow(2, 16), s[4] = t / Math.pow(2, 8), s[5] = t, s[6] = 112 | e >>> 8, s[7] = e, s[8] = 128 | i >>> 24, s[9] = i >>> 16, s[10] = i >>> 8, s[11] = i, s[12] = r >>> 24, s[13] = r >>> 16, s[14] = r >>> 8, s[15] = r, new Rr(s)
        }
        toString() {
            for (var t = "", e = 0; this.bytes.length > e; e++) t = t + (this.bytes[e] >>> 4).toString(16) + (15 & this.bytes[e]).toString(16), 3 !== e && 5 !== e && 7 !== e && 9 !== e || (t += "-");
            if (36 !== t.length) throw new Error("Invalid UUIDv7 was generated");
            return t
        }
        clone() {
            return new Rr(this.bytes.slice(0))
        }
        equals(t) {
            return 0 === this.compareTo(t)
        }
        compareTo(t) {
            for (var e = 0; 16 > e; e++) {
                var i = this.bytes[e] - t.bytes[e];
                if (0 !== i) return Math.sign(i)
            }
            return 0
        }
    }
    class Cr {
        constructor() {
            this.S = 0, this.C = 0, this.I = new Or
        }
        generate() {
            var t = this.generateOrAbort();
            if (q(t)) {
                this.S = 0;
                var e = this.generateOrAbort();
                if (q(e)) throw new Error("Could not generate UUID after timestamp reset");
                return e
            }
            return t
        }
        generateOrAbort() {
            var t = Date.now();
            if (t > this.S) this.S = t, this.M();
            else {
                if (this.S >= t + 1e4) return;
                this.C++, this.C > 4398046511103 && (this.S++, this.M())
            }
            return Rr.fromFieldsV7(this.S, Math.trunc(this.C / Math.pow(2, 30)), this.C & Math.pow(2, 30) - 1, this.I.nextUint32())
        }
        M() {
            this.C = 1024 * this.I.nextUint32() + (1023 & this.I.nextUint32())
        }
    }
    var Fr, Mr = t => {
        if ("undefined" != typeof UUIDV7_DENY_WEAK_RNG && UUIDV7_DENY_WEAK_RNG) throw new Error("no cryptographically strong RNG available");
        for (var e = 0; t.length > e; e++) t[e] = 65536 * Math.trunc(65536 * Math.random()) + Math.trunc(65536 * Math.random());
        return t
    };
    t && !q(t.crypto) && crypto.getRandomValues && (Mr = t => crypto.getRandomValues(t));
    class Or {
        constructor() {
            this.R = new Uint32Array(8), this.O = 1 / 0
        }
        nextUint32() {
            return this.R.length > this.O || (Mr(this.R), this.O = 0), this.R[this.O++]
        }
    }
    var Ar = () => Dr().toString(),
        Dr = () => (Fr || (Fr = new Cr)).generate(),
        Lr = "",
        jr = /[a-z0-9][a-z0-9-]+\.[a-z]{2,}$/i;
    var zr = {
            N: () => !!r,
            D(t) {
                oi.error("cookieStore error: " + t)
            },
            P(t) {
                if (r) {
                    try {
                        for (var e = t + "=", i = r.cookie.split(";").filter((t => t.length)), s = 0; i.length > s; s++) {
                            for (var n = i[s];
                                " " == n.charAt(0);) n = n.substring(1, n.length);
                            if (0 === n.indexOf(e)) return decodeURIComponent(n.substring(e.length, n.length))
                        }
                    } catch (t) {}
                    return null
                }
            },
            F(t) {
                var e;
                try {
                    e = JSON.parse(zr.P(t)) || {}
                } catch (t) {}
                return e
            },
            A(t, e, i, s, n) {
                if (!r) return !1;
                try {
                    var o = "",
                        a = "",
                        l = function(t, e) {
                            if (e) {
                                var i = function(t, e) {
                                    if (void 0 === e && (e = r), Lr) return Lr;
                                    if (!e) return "";
                                    if (["localhost", "127.0.0.1"].includes(t)) return "";
                                    for (var i = t.split("."), s = Math.min(i.length, 8), n = "dmn_chk_" + Ar(); !Lr && s--;) {
                                        var o = i.slice(s).join("."),
                                            a = n + "=1;domain=." + o + ";path=/";
                                        e.cookie = a + ";max-age=3", e.cookie.includes(n) && (e.cookie = a + ";max-age=0", Lr = o)
                                    }
                                    return Lr
                                }(t);
                                if (!i) {
                                    var s = (t => {
                                        var e = t.match(jr);
                                        return e ? e[0] : ""
                                    })(t);
                                    s !== i && oi.info("Warning: cookie subdomain discovery mismatch", s, i), i = s
                                }
                                return i ? "; domain=." + i : ""
                            }
                            return ""
                        }(r.location.hostname, s);
                    if (i) {
                        var u = new Date;
                        u.setTime(u.getTime() + 864e5 * i), o = "; expires=" + u.toUTCString()
                    }
                    n && (a = "; secure");
                    var h = t + "=" + encodeURIComponent(JSON.stringify(e)) + o + "; SameSite=Lax; path=/" + l + a;
                    return h.length > 3686.4 && oi.warn("cookieStore warning: large cookie, len=" + h.length), r.cookie = h, !0
                } catch (t) {
                    return !1
                }
            },
            q(t, e) {
                if (null != r && r.cookie) try {
                    zr.A(t, "", -1, e)
                } catch (t) {
                    return
                }
            }
        },
        Nr = null,
        Ur = {
            N() {
                if (!W(Nr)) return Nr;
                var e = !0;
                if (q(t)) e = !1;
                else try {
                    var i = "__mplssupport__";
                    Ur.A(i, "xyz"), '"xyz"' !== Ur.P(i) && (e = !1), Ur.q(i)
                } catch (t) {
                    e = !1
                }
                return e || oi.error("localStorage unsupported; falling back to cookie store"), Nr = e, e
            },
            D(t) {
                oi.error("localStorage error: " + t)
            },
            P(e) {
                try {
                    return null == t ? void 0 : t.localStorage.getItem(e)
                } catch (t) {
                    Ur.D(t)
                }
                return null
            },
            F(t) {
                try {
                    return JSON.parse(Ur.P(t)) || {}
                } catch (t) {}
                return null
            },
            A(e, i) {
                try {
                    return null == t || t.localStorage.setItem(e, JSON.stringify(i)), !0
                } catch (t) {
                    Ur.D(t)
                }
                return !1
            },
            q(e) {
                try {
                    null == t || t.localStorage.removeItem(e)
                } catch (t) {
                    Ur.D(t)
                }
            }
        },
        Br = [di, "distinct_id", Ii, Ri, er, tr, Ki],
        Hr = {},
        qr = {
            N: () => !0,
            D(t) {
                oi.error("memoryStorage error: " + t)
            },
            P: t => Hr[t] || null,
            F: t => Hr[t] || null,
            A: (t, e) => (Hr[t] = e, !0),
            q(t) {
                delete Hr[t]
            }
        },
        Gr = null,
        Vr = {
            N() {
                if (!W(Gr)) return Gr;
                if (Gr = !0, q(t)) Gr = !1;
                else try {
                    var e = "__support__";
                    Vr.A(e, "xyz"), '"xyz"' !== Vr.P(e) && (Gr = !1), Vr.q(e)
                } catch (t) {
                    Gr = !1
                }
                return Gr
            },
            D(t) {
                oi.error("sessionStorage error: ", t)
            },
            P(e) {
                try {
                    return null == t ? void 0 : t.sessionStorage.getItem(e)
                } catch (t) {
                    Vr.D(t)
                }
                return null
            },
            F(t) {
                try {
                    return JSON.parse(Vr.P(t)) || null
                } catch (t) {}
                return null
            },
            A(e, i) {
                try {
                    return null == t || t.sessionStorage.setItem(e, JSON.stringify(i)), !0
                } catch (t) {
                    Vr.D(t)
                }
                return !1
            },
            q(e) {
                try {
                    null == t || t.sessionStorage.removeItem(e)
                } catch (t) {
                    Vr.D(t)
                }
            }
        };
    class Wr {
        constructor(t) {
            this._instance = t
        }
        get Dt() {
            return this._instance.config
        }
        get consent() {
            return this.Lr() ? 0 : this.Ar
        }
        isOptedOut() {
            return this.Dt.cookieless_mode === ur || this.isRejected() || -1 === this.consent && this.Dt.cookieless_mode === lr
        }
        isOptedIn() {
            return !this.isOptedOut()
        }
        isExplicitlyOptedOut() {
            return 0 === this.consent
        }
        isRejected() {
            return 0 === this.consent || -1 === this.consent && this.Dt.opt_out_capturing_by_default
        }
        optInOut(t) {
            this.Fr.A(this.Nr, t ? 1 : 0, this.Dt.cookie_expiration, this.Dt.cross_subdomain_cookie, this.Dt.secure_cookie)
        }
        reset() {
            this.Fr.q(this.Nr, this.Dt.cross_subdomain_cookie)
        }
        get Nr() {
            var {
                token: t,
                opt_out_capturing_cookie_prefix: e,
                consent_persistence_name: i
            } = this._instance.config;
            return i || (e ? e + t : "__ph_opt_in_out_" + t)
        }
        get Ar() {
            var t = this.Fr.P(this.Nr);
            return nt(t) ? 1 : O(ot, t) ? 0 : -1
        }
        get Fr() {
            var t = this.Dt.opt_out_capturing_persistence_type,
                e = "localStorage" === t ? Ur : zr;
            if (!this.Dr || this.Dr !== e) {
                this.Dr = e;
                var i = "localStorage" === t ? zr : Ur;
                i.P(this.Nr) && (this.Dr.P(this.Nr) || this.optInOut(nt(i.P(this.Nr))), i.q(this.Nr, this.Dt.cross_subdomain_cookie))
            }
            return this.Dr
        }
        Lr() {
            return !!this.Dt.respect_dnt && [null == i ? void 0 : i.doNotTrack, null == i ? void 0 : i.msDoNotTrack, h.doNotTrack].some((t => nt(t)))
        }
    }
    var Jr = 1,
        Kr = 3,
        Yr = 11;

    function Xr(t) {
        return t instanceof Element && (t.id === ir || !(null == t.closest || !t.closest(".toolbar-global-fade-container")))
    }

    function Qr(t) {
        return !!t && t.nodeType === Jr
    }

    function Zr(t, e) {
        return !!t && !!t.tagName && t.tagName.toLowerCase() === e.toLowerCase()
    }

    function ts(t) {
        return !!t && t.nodeType === Kr
    }

    function es(t) {
        return !!t && t.nodeType === Yr && Qr(t.host)
    }

    function is(t) {
        return t ? A(t).split(/\s+/) : []
    }

    function rs(e) {
        var i = null == t ? void 0 : t.location.href;
        return !!(i && e && e.some((t => i.match(t))))
    }

    function ss(t) {
        var e = "";
        switch (typeof t.className) {
            case "string":
                e = t.className;
                break;
            case "object":
                e = (t.className && "baseVal" in t.className ? t.className.baseVal : null) || t.getAttribute("class") || "";
                break;
            default:
                e = ""
        }
        return is(e)
    }

    function ns(t) {
        return J(t) ? null : A(t).split(/(\s+)/).filter((t => Ts(t))).join("").replace(/[\r\n]/g, " ").replace(/[ ]+/g, " ").substring(0, 255)
    }

    function os(t) {
        var e = "";
        return bs(t) && !ws(t) && t.childNodes && t.childNodes.length && br(t.childNodes, (function(t) {
            var i;
            ts(t) && t.textContent && (e += null !== (i = ns(t.textContent)) && void 0 !== i ? i : "")
        })), A(e)
    }

    function as(t) {
        return q(t.target) ? t.srcElement || null : null != (e = t.target) && e.shadowRoot ? t.composedPath()[0] || null : t.target || null;
        var e
    }
    var ls = ["a", "button", "form", "input", "select", "textarea", "label"];

    function us(t, e) {
        if (q(e)) return !0;
        var i, r = function(t) {
            if (e.some((e => function(t, e) {
                    var i = t.matches || t.matchesSelector || t.msMatchesSelector || t.mozMatchesSelector || t.webkitMatchesSelector || t.oMatchesSelector;
                    try {
                        return !!i && i.call(t, e)
                    } catch (t) {
                        return !1
                    }
                }(t, e)))) return {
                v: !0
            }
        };
        for (var s of t)
            if (i = r(s)) return i.v;
        return !1
    }

    function hs(t) {
        var e = t.parentNode;
        return !(!e || !Qr(e)) && e
    }
    var ds = [".ph-no-autocapture", "[data-ph-no-autocapture]"],
        vs = ["next", "previous", "prev", ">", "<"],
        cs = [...vs, "+", "-", "−", "–"],
        fs = (t, e) => /[a-z0-9]/i.test(e) ? t.includes(e) : t === e,
        ps = [".ph-no-rageclick", ".ph-no-capture"],
        gs = ["", "text", "search", "email", "password", "url", "tel", "number"];

    function _s(e, i) {
        if (!t || ms(e)) return !1;
        var r, s, n, o, a;
        if (X(i) ? (r = !!i && ps, s = void 0, n = !1) : (r = null !== (o = null == i ? void 0 : i.css_selector_ignorelist) && void 0 !== o ? o : ps, s = null == i ? void 0 : i.content_ignorelist, n = null !== (a = null == i ? void 0 : i.ignore_text_selection) && void 0 !== a && a), !1 === r) return !1;
        if (n && function(t) {
                return !(!t || !Qr(t)) && (!!Zr(t, "textarea") || (Zr(t, "input") ? O(gs, (t.getAttribute("type") || "").toLowerCase()) : function(t) {
                    if (t.isContentEditable) return !0;
                    var e = null == t.getAttribute ? void 0 : t.getAttribute("contenteditable");
                    return "true" === e || "" === e
                }(t)))
            }(e)) return !1;
        var {
            targetElementList: l
        } = ys(e, !1);
        return ! function(t, e) {
            if (!1 === t || q(t)) return !1;
            var i;
            if (!0 === t) i = vs;
            else {
                if (!N(t)) return !1;
                if (t.length > 10) return oi.error("[PostHog] content_ignorelist array cannot exceed 10 items. Use css_selector_ignorelist for more complex matching."), !1;
                i = t.map((t => t.toLowerCase()))
            }
            return e.some((t => {
                var {
                    safeText: e,
                    ariaLabel: r
                } = t;
                return i.some((t => fs(e, t) || fs(r, t)))
            }))
        }(s, l.map((t => {
            var e;
            return {
                safeText: os(t).toLowerCase(),
                ariaLabel: (null == (e = t.getAttribute("aria-label")) ? void 0 : e.toLowerCase().trim()) || ""
            }
        }))) && !us(l, r)
    }
    var ms = t => !t || Zr(t, "html") || !Qr(t),
        ys = (e, i) => {
            if (!t || ms(e)) return {
                parentIsUsefulElement: !1,
                targetElementList: []
            };
            for (var r = !1, s = [e], n = e; n.parentNode && !Zr(n, "body");)
                if (es(n.parentNode)) s.push(n.parentNode.host), n = n.parentNode.host;
                else {
                    var o = hs(n);
                    if (!o) break;
                    if (i || ls.indexOf(o.tagName.toLowerCase()) > -1) r = !0;
                    else {
                        var a = t.getComputedStyle(o);
                        a && "pointer" === a.getPropertyValue("cursor") && (r = !0)
                    }
                    s.push(o), n = o
                }
            return {
                parentIsUsefulElement: r,
                targetElementList: s
            }
        };

    function bs(t) {
        for (var e = t; e.parentNode && !Zr(e, "body"); e = e.parentNode) {
            var i = ss(e);
            if (O(i, "ph-sensitive") || O(i, "ph-no-capture")) return !1
        }
        if (O(ss(t), "ph-include")) return !0;
        var r = t.type || "";
        if (G(r)) switch (r.toLowerCase()) {
            case "hidden":
            case "password":
                return !1
        }
        var s = t.name || t.id || "";
        return !G(s) || !/^cc|cardnum|ccnum|creditcard|csc|cvc|cvv|exp|pass|pwd|routing|seccode|securitycode|securitynum|socialsec|socsec|ssn/i.test(s.replace(/[^a-zA-Z0-9]/g, ""))
    }

    function ws(t) {
        return !!(Zr(t, "input") && !["button", "checkbox", "submit", "reset"].includes(t.type) || Zr(t, "select") || Zr(t, "textarea") || "true" === t.getAttribute("contenteditable"))
    }
    var xs = "(4[0-9]{12}(?:[0-9]{3})?)|(5[1-5][0-9]{14})|(6(?:011|5[0-9]{2})[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|((?:2131|1800|35[0-9]{3})[0-9]{11})",
        Es = new RegExp("^(?:" + xs + ")$"),
        Ss = new RegExp(xs),
        ks = "\\d{3}-?\\d{2}-?\\d{4}",
        $s = new RegExp("^(" + ks + ")$"),
        Ps = new RegExp("(" + ks + ")");

    function Ts(t, e) {
        if (void 0 === e && (e = !0), J(t)) return !1;
        if (G(t)) {
            if (t = A(t), (e ? Es : Ss).test((t || "").replace(/[- ]/g, ""))) return !1;
            if ((e ? $s : Ps).test(t)) return !1
        }
        return !0
    }

    function Is(t) {
        var e = os(t);
        return Ts(e = (e + " " + Rs(t)).trim()) ? e : ""
    }

    function Rs(t) {
        var e = "";
        return t && t.childNodes && t.childNodes.length && br(t.childNodes, (function(t) {
            var i;
            if (t && "span" === (null == (i = t.tagName) ? void 0 : i.toLowerCase())) try {
                var r = os(t);
                e = (e + " " + r).trim(), t.childNodes && t.childNodes.length && (e = (e + " " + Rs(t)).trim())
            } catch (t) {
                oi.error("[AutoCapture]", t)
            }
        })), e
    }

    function Cs(t) {
        return t.replace(/"|\\"/g, '\\"')
    }

    function Fs(t) {
        var e = t.attr__class;
        return e ? N(e) ? e : is(e) : void 0
    }
    var Ms = ai("[Dead Clicks]"),
        Os = () => !0,
        As = t => {
            var e, i = !(null == (e = t.instance.persistence) || !e.get_property(bi)),
                r = t.instance.config.capture_dead_clicks;
            return X(r) ? r : !!B(r) || i
        };
    class Ds {
        get lazyLoadedDeadClicksAutocapture() {
            return this.$r
        }
        constructor(t, e, i) {
            this.instance = t, this.isEnabled = e, this.onCapture = i, this.startIfEnabledOrStop()
        }
        onRemoteConfig(t) {
            "captureDeadClicks" in t && (this.instance.persistence && this.instance.persistence.register({
                [bi]: t.captureDeadClicks
            }), this.startIfEnabledOrStop())
        }
        startIfEnabledOrStop() {
            this.isEnabled(this) ? this.qr((() => {
                this.jr()
            })) : this.stop()
        }
        qr(t) {
            var e, i;
            null != (e = h.__PosthogExtensions__) && e.initDeadClicksAutocapture ? t() : null == (i = h.__PosthogExtensions__) || null == i.loadExternalDependency || i.loadExternalDependency(this.instance, "dead-clicks-autocapture", (e => {
                e ? Ms.error("failed to load script", e) : t()
            }))
        }
        jr() {
            var t;
            if (r) {
                if (!this.$r && null != (t = h.__PosthogExtensions__) && t.initDeadClicksAutocapture) {
                    var e = B(this.instance.config.capture_dead_clicks) ? this.instance.config.capture_dead_clicks : {};
                    e.__onCapture = this.onCapture, this.$r = h.__PosthogExtensions__.initDeadClicksAutocapture(this.instance, e), this.$r.start(r), Ms.info("starting...")
                }
            } else Ms.error("`document` not found. Cannot start.")
        }
        stop() {
            this.$r && (this.$r.stop(), this.$r = void 0, Ms.info("stopping..."))
        }
    }
    var Ls = ai("[SegmentIntegration]");
    var js = "posthog-js";

    function zs(t, e) {
        var {
            organization: i,
            projectId: r,
            prefix: s,
            severityAllowList: n = ["error"],
            sendExceptionsToPostHog: o = !0
        } = void 0 === e ? {} : e;
        return e => {
            var a, l, u, h, d;
            if ("*" !== n && !n.includes(e.level) || !t.__loaded) return e;
            e.tags || (e.tags = {});
            var v = t.requestRouter.endpointFor("ui", "/project/" + t.config.token + "/person/" + t.get_distinct_id());
            e.tags["PostHog Person URL"] = v, t.sessionRecordingStarted() && (e.tags["PostHog Recording URL"] = t.get_session_replay_url({
                withTimestamp: !0
            }));
            var c, f = (null == (a = e.exception) ? void 0 : a.values) || [],
                g = f.map((t => p({}, t, {
                    stacktrace: t.stacktrace ? p({}, t.stacktrace, {
                        type: "raw",
                        frames: (t.stacktrace.frames || []).map((t => p({}, t, {
                            platform: "web:javascript"
                        })))
                    }) : void 0
                }))),
                _ = {
                    $exception_message: (null == (l = f[0]) ? void 0 : l.value) || e.message,
                    $exception_type: null == (u = f[0]) ? void 0 : u.type,
                    $exception_level: e.level,
                    $exception_list: g,
                    $sentry_event_id: e.event_id,
                    $sentry_exception: e.exception,
                    $sentry_exception_message: (null == (h = f[0]) ? void 0 : h.value) || e.message,
                    $sentry_exception_type: null == (d = f[0]) ? void 0 : d.type,
                    $sentry_tags: e.tags
                };
            return i && r && (_.$sentry_url = (s || "https://sentry.io/organizations/") + i + "/issues/?project=" + r + "&query=" + e.event_id), o && (null == (c = t.exceptions) || c.sendExceptionEvent(_)), e
        }
    }
    class Ns {
        constructor(t, e, i, r, s, n) {
            this.name = js, this.setupOnce = function(o) {
                o(zs(t, {
                    organization: e,
                    projectId: i,
                    prefix: r,
                    severityAllowList: s,
                    sendExceptionsToPostHog: null == n || n
                }))
            }
        }
    }
    class Us {
        constructor(t) {
            this.Br = (t, e, i) => {
                i && (i.noSessionId || i.activityTimeout || i.sessionPastMaximumLength || i.crossTabAdoption) && (oi.info("[PageViewManager] Session rotated, clearing pageview state", {
                    sessionId: t,
                    changeReason: i
                }), this.Hr = void 0, this._instance.scrollManager.resetContext())
            }, this._instance = t, this.Ur()
        }
        Ur() {
            var t;
            this.zr = null == (t = this._instance.sessionManager) ? void 0 : t.onSessionId(this.Br)
        }
        destroy() {
            var t;
            null == (t = this.zr) || t.call(this), this.zr = void 0
        }
        doPageView(e, i) {
            var r, s = this.Vr(e, i);
            return this.Hr = {
                pathname: null !== (r = null == t ? void 0 : t.location.pathname) && void 0 !== r ? r : "",
                pageViewId: i,
                timestamp: e
            }, this._instance.scrollManager.resetContext(), s
        }
        doPageLeave(t) {
            var e;
            return this.Vr(t, null == (e = this.Hr) ? void 0 : e.pageViewId)
        }
        doEvent() {
            var t;
            return {
                $pageview_id: null == (t = this.Hr) ? void 0 : t.pageViewId
            }
        }
        Vr(t, e) {
            var i = this.Hr;
            if (!i) return {
                $pageview_id: e
            };
            var r = {
                    $pageview_id: e,
                    $prev_pageview_id: i.pageViewId
                },
                s = this._instance.scrollManager.getContext();
            if (s && !this._instance.config.disable_scroll_properties) {
                var {
                    maxScrollHeight: n,
                    lastScrollY: o,
                    maxScrollY: a,
                    maxContentHeight: l,
                    lastContentY: u,
                    maxContentY: h
                } = s;
                if (!(q(n) || q(o) || q(a) || q(l) || q(u) || q(h))) {
                    n = Math.ceil(n), o = Math.ceil(o), a = Math.ceil(a), l = Math.ceil(l), u = Math.ceil(u), h = Math.ceil(h);
                    var d = n > 1 ? at(o / n, 0, 1, oi) : 1,
                        v = n > 1 ? at(a / n, 0, 1, oi) : 1,
                        c = l > 1 ? at(u / l, 0, 1, oi) : 1,
                        f = l > 1 ? at(h / l, 0, 1, oi) : 1;
                    r = wr(r, {
                        $prev_pageview_last_scroll: o,
                        $prev_pageview_last_scroll_percentage: d,
                        $prev_pageview_max_scroll: a,
                        $prev_pageview_max_scroll_percentage: v,
                        $prev_pageview_last_content: u,
                        $prev_pageview_last_content_percentage: c,
                        $prev_pageview_max_content: h,
                        $prev_pageview_max_content_percentage: f
                    })
                }
            }
            return i.pathname && (r.$prev_pageview_pathname = i.pathname), i.timestamp && (r.$prev_pageview_duration = (t.getTime() - i.timestamp.getTime()) / 1e3), r
        }
    }
    var Bs = ["flags", "surveys"],
        Hs = {
            [hi]: {
                exposure: "hidden"
            },
            [vi]: {
                exposure: "hidden"
            },
            __cmpns: {
                exposure: "hidden"
            },
            [ci]: {
                exposure: "hidden"
            },
            [fi]: {
                exposure: "event"
            },
            [pi]: {
                exposure: "hidden"
            },
            [gi]: {
                exposure: "event"
            },
            [_i]: {
                exposure: "hidden"
            },
            [mi]: {
                exposure: "event"
            },
            [yi]: {
                exposure: "event"
            },
            [bi]: {
                exposure: "event"
            },
            [wi]: {
                exposure: "hidden"
            },
            [xi]: {
                exposure: "event"
            },
            [Ei]: {
                exposure: "hidden"
            },
            $session_recording_enabled_server_side: {
                exposure: "hidden"
            },
            [Ii]: {
                exposure: "hidden"
            },
            [Ri]: {
                exposure: "event"
            },
            [Si]: {
                exposure: "event",
                shouldSkipFromEventProperties: t => W(t)
            },
            $session_past_minimum_duration: {
                exposure: "event"
            },
            $session_recording_url_trigger_activated_session: {
                exposure: "event"
            },
            $session_recording_event_trigger_activated_session: {
                exposure: "event"
            },
            $debug_first_full_snapshot_timestamp: {
                exposure: "event"
            },
            $sess_rec_flush_size: {
                exposure: "hidden"
            },
            [Ci]: {
                exposure: "derived",
                storageGroup: "flags",
                shouldSkipFromEventProperties: (t, e) => e(),
                transformToEventProperties(t) {
                    if (!B(t)) return {};
                    for (var e = {}, i = Object.keys(t), r = 0; i.length > r; r++) e["$feature/" + i[r]] = t[i[r]];
                    return e
                }
            },
            [Fi]: {
                exposure: "event",
                storageGroup: "flags"
            },
            [Mi]: {
                exposure: "hidden"
            },
            [Oi]: {
                exposure: "hidden",
                storageGroup: "flags"
            },
            [Ai]: {
                exposure: "event",
                storageGroup: "flags"
            },
            [Di]: {
                exposure: "event",
                storageGroup: "flags",
                volatile: !0
            },
            [Li]: {
                exposure: "event"
            },
            [ji]: {
                exposure: "hidden"
            },
            [zi]: {
                exposure: "hidden"
            },
            [Ni]: {
                exposure: "hidden"
            },
            [Ui]: {
                exposure: "hidden",
                storageGroup: "surveys"
            },
            [Bi]: {
                exposure: "hidden",
                storageGroup: "surveys",
                volatile: !0
            },
            [Hi]: {
                exposure: "event"
            },
            [qi]: {
                exposure: "hidden"
            },
            $product_tours_activated: {
                exposure: "hidden"
            },
            $conversations_widget_session_id: {
                exposure: "event"
            },
            $conversations_ticket_id: {
                exposure: "event"
            },
            $conversations_widget_state: {
                exposure: "event"
            },
            $conversations_user_traits: {
                exposure: "event"
            },
            [Gi]: {
                exposure: "hidden"
            },
            [Vi]: {
                exposure: "hidden"
            },
            [Wi]: {
                exposure: "hidden"
            },
            [Ji]: {
                exposure: "hidden",
                storageGroup: "flags",
                volatile: !0
            },
            [Ki]: {
                exposure: "hidden"
            },
            [Yi]: {
                exposure: "hidden"
            },
            [Xi]: {
                exposure: "hidden"
            },
            [Qi]: {
                exposure: "hidden"
            },
            [Zi]: {
                exposure: "hidden"
            },
            [tr]: {
                exposure: "hidden"
            },
            [er]: {
                exposure: "hidden"
            },
            [ki]: {
                exposure: "event"
            },
            [$i]: {
                exposure: "event"
            },
            [Pi]: {
                exposure: "event"
            },
            [Ti]: {
                exposure: "event"
            },
            [sr]: {
                exposure: "event"
            },
            [nr]: {
                exposure: "event"
            },
            [or]: {
                exposure: "event"
            },
            $sdk_debug_replay_event_trigger_status: {
                exposure: "event"
            },
            $sdk_debug_replay_linked_flag_trigger_status: {
                exposure: "event"
            },
            $sdk_debug_replay_matched_recording_trigger_groups: {
                exposure: "event"
            },
            $sdk_debug_replay_remote_trigger_matching_config: {
                exposure: "event"
            },
            $sdk_debug_replay_trigger_groups_count: {
                exposure: "event"
            },
            $sdk_debug_replay_url_trigger_status: {
                exposure: "event"
            },
            $session_recording_start_reason: {
                exposure: "event"
            }
        },
        qs = [
            ["$posthog_sr_group_event_trigger_", {
                exposure: "hidden"
            }],
            ["$posthog_sr_group_url_trigger_", {
                exposure: "hidden"
            }],
            ["$posthog_sr_group_sampling_", {
                exposure: "hidden"
            }]
        ],
        Gs = t => {
            var e = Hs[t];
            if (e) return e;
            for (var [i, r] of qs)
                if (0 === t.indexOf(i)) return r
        },
        Vs = t => {
            var e = null == r ? void 0 : r.createElement("a");
            return q(e) ? null : (e.href = t, e)
        },
        Ws = function(t, e) {
            for (var i, r = ((t.split("#")[0] || "").split(/\?(.*)/)[1] || "").replace(/^\?+/g, "").split("&"), s = 0; r.length > s; s++) {
                var n = r[s].split("=");
                if (n[0] === e) {
                    i = n;
                    break
                }
            }
            if (!N(i) || 2 > i.length) return "";
            var o = i[1];
            try {
                o = decodeURIComponent(o)
            } catch (t) {
                oi.error("Skipping decoding for malformed query param: " + o)
            }
            return o.replace(/\+/g, " ")
        },
        Js = function(t, e, i) {
            if (!t || !e || !e.length) return t;
            for (var r = t.split("#"), s = r[1], n = (r[0] || "").split("?"), o = n[1], a = n[0], l = (o || "").split("&"), u = [], h = 0; l.length > h; h++) {
                var d = l[h].split("=");
                N(d) && (e.includes(d[0]) ? u.push(d[0] + "=" + i) : u.push(l[h]))
            }
            var v = a;
            return null != o && (v += "?" + u.join("&")), null != s && (v += "#" + s), v
        },
        Ks = function(t, e) {
            var i = t.match(new RegExp(e + "=([^&]*)"));
            return i ? i[1] : null
        },
        Ys = "https?://(.*)",
        Xs = ["gclid", "gclsrc", "dclid", "gbraid", "wbraid", "fbclid", "msclkid", "twclid", "li_fat_id", "igshid", "ttclid", "rdt_cid", "epik", "qclid", "sccid", "irclid", "_kx"],
        Qs = ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term", "gad_source", "mc_cid", ...Xs],
        Zs = "<masked>",
        tn = ["li_fat_id"];

    function en(t, e, i) {
        if (!r) return {};
        var s, n = e ? [...Xs, ...i || []] : [],
            o = rn(Js(r.URL, n, Zs), t),
            a = (s = {}, br(tn, (function(t) {
                var e = zr.P(t);
                s[t] = e || null
            })), s);
        return wr(a, o)
    }

    function rn(t, e) {
        var i = Qs.concat(e || []),
            r = {};
        return br(i, (function(e) {
            var i = Ws(t, e);
            r[e] = i || null
        })), r
    }

    function sn(t) {
        var e = function(t) {
                return t ? 0 === t.search(Ys + "google.([^/?]*)") ? "google" : 0 === t.search(Ys + "bing.com") ? "bing" : 0 === t.search(Ys + "yahoo.com") ? "yahoo" : 0 === t.search(Ys + "duckduckgo.com") ? "duckduckgo" : null : null
            }(t),
            i = "yahoo" != e ? "q" : "p",
            s = {};
        if (!W(e)) {
            s.$search_engine = e;
            var n = r ? Ws(r.referrer, i) : "";
            n.length && (s.ph_keyword = n)
        }
        return s
    }

    function nn() {
        return navigator.language || navigator.userLanguage
    }
    var on = "$direct";

    function an() {
        return (null == r ? void 0 : r.referrer) || on
    }

    function ln(t, e) {
        var i = t ? [...Xs, ...e || []] : [],
            r = null == s ? void 0 : s.href.substring(0, 1e3);
        return {
            r: an().substring(0, 1e3),
            u: r ? Js(r, i, Zs) : void 0
        }
    }

    function un(t) {
        var e, {
                r: i,
                u: r
            } = t,
            s = {
                $referrer: i,
                $referring_domain: null == i ? void 0 : i == on ? on : null == (e = Vs(i)) ? void 0 : e.host
            };
        if (r) {
            s.$current_url = r;
            var n = Vs(r);
            s.$host = null == n ? void 0 : n.host, s.$pathname = null == n ? void 0 : n.pathname;
            var o = rn(r);
            wr(s, o)
        }
        if (i) {
            var a = sn(i);
            wr(s, a)
        }
        return s
    }

    function hn() {
        try {
            return Intl.DateTimeFormat().resolvedOptions().timeZone
        } catch (t) {
            return
        }
    }

    function dn() {
        try {
            return (new Date).getTimezoneOffset()
        } catch (t) {
            return
        }
    }
    var vn = {
            flags: Ji,
            surveys: Bi
        },
        cn = ["cookie", "localstorage", "localstorage+cookie", "sessionstorage", "memory"],
        fn = "main";
    class pn {
        constructor(e, i, r) {
            if (void 0 === r && (r = !0), this.Wr = {}, this.Gr = !1, this.Zr = !1, this.Dt = e, this.Qr = r, this.props = {}, this.Jr = !1, this.Kr = (t => {
                    var e = "";
                    return t.token && (e = t.token.replace(/\+/g, "PL").replace(/\//g, "SL").replace(/=/g, "EQ")), t.persistence_name ? "ph_" + t.persistence_name : "ph_" + e + "_posthog"
                })(e), this.Fr = this.Yr(e), this.Zr = this.Xr(e), this.load(), e.debug && oi.info("Persistence loaded", e.persistence, p({}, this.props)), this.update_config(e, e, i), this.save(), t) {
                var s = () => this.flush();
                Tr(t, "beforeunload", s, {
                    capture: !1
                }), Tr(t, "pagehide", s, {
                    capture: !1
                })
            }
        }
        ei() {
            var t, e = null == (t = this.Dt) ? void 0 : t.persistence_save_debounce_ms;
            return K(e) && e > 0 ? e : 0
        }
        isDisabled() {
            return !!this.ti
        }
        Yr(e) {
            -1 === cn.indexOf(e.persistence.toLowerCase()) && (oi.critical("Unknown persistence type " + e.persistence + "; falling back to localStorage+cookie"), e.persistence = "localStorage+cookie");
            var i, r = function(e, i) {
                    void 0 === e && (e = []), void 0 === i && (i = !1);
                    var r = [...Br, ...e];
                    return p({}, Ur, {
                        F(t) {
                            try {
                                var e = {};
                                try {
                                    e = zr.F(t) || {}
                                } catch (t) {}
                                var r, s = JSON.parse(Ur.P(t) || "{}");
                                if (i) {
                                    var n = {};
                                    for (var o in e) {
                                        var a = e[o];
                                        W(a) || "" === a || (n[o] = a)
                                    }
                                    r = wr(s, n)
                                } else r = wr(e, s);
                                return Ur.A(t, r), r
                            } catch (t) {}
                            return null
                        },
                        A(t, e, i, s, n, o) {
                            var a = Ur.A(t, e, void 0, void 0, o);
                            try {
                                var l = {};
                                r.forEach((t => {
                                    e[t] && (l[t] = e[t])
                                })), Object.keys(l).length && zr.A(t, l, i, s, n, o)
                            } catch (t) {
                                Ur.D(t)
                            }
                            return a
                        },
                        q(e, i) {
                            try {
                                null == t || t.localStorage.removeItem(e), zr.q(e, i)
                            } catch (t) {
                                Ur.D(t)
                            }
                        }
                    })
                }(e.cookie_persisted_properties || [], e.__preview_cookie_wins_on_conflict || !1),
                s = !1,
                n = e.persistence.toLowerCase();
            return "localstorage" === n && Ur.N() ? (i = Ur, s = !0) : "localstorage+cookie" === n && r.N() ? (i = r, s = !0) : "sessionstorage" === n && Vr.N() ? i = Vr : "memory" === n ? i = qr : "cookie" === n ? i = zr : r.N() ? (i = r, s = !0) : i = zr, this.Gr = s, i
        }
        ri(t) {
            return this.Kr + "__" + t
        }
        Xr(t) {
            return this.Gr && !!t.split_storage
        }
        ii(t) {
            var e = null != t ? t : this.Dt.feature_flag_cache_ttl_ms;
            if (!e || 0 >= e) return !1;
            var i = this.props[Ji];
            return !i || "number" != typeof i || Date.now() - i > e
        }
        properties() {
            var t = {};
            return br(this.props, ((e, i) => {
                var r = Gs(i);
                if ("derived" === (null == r ? void 0 : r.exposure)) {
                    if (null != r.shouldSkipFromEventProperties && r.shouldSkipFromEventProperties(e, i === Ci ? () => this.ii() : () => !1)) return;
                    r.transformToEventProperties && wr(t, r.transformToEventProperties(e))
                } else if (!r || "event" === r.exposure) {
                    if (null != r && null != r.shouldSkipFromEventProperties && r.shouldSkipFromEventProperties(e, (() => !1))) return;
                    t[i] = e
                }
            })), t
        }
        load() {
            if (!this.ti) {
                var t = this.Fr.F(this.Kr);
                t && (this.props = wr({}, t)), this.Zr && this.ni()
            }
        }
        ni() {
            for (var t of Bs) {
                var e = Ur.F(this.ri(t));
                if (e && !H(e)) {
                    var i = this.si(t);
                    i.persisted = !0, this.oi(t) || (i.fingerprint = this.ai(e, t)), this.li(t, e) || wr(this.props, e)
                }
            }
        }
        oi(t) {
            return Object.keys(this.props).some((e => {
                var i;
                return (null == (i = Gs(e)) ? void 0 : i.storageGroup) === t
            }))
        }
        li(t, e) {
            var i = vn[t];
            if (!i) return !1;
            var r = e[i],
                s = this.props[i];
            return K(r) && K(s) && s > r
        }
        refreshKey(t) {
            var e;
            if (!this.ti) {
                var i = this.Zr ? null == (e = Gs(t)) ? void 0 : e.storageGroup : void 0,
                    r = i ? Ur.F(this.ri(i)) : this.Fr.F(this.Kr);
                if (r && t in r) this.ui(t, r[t]);
                else {
                    if (i) {
                        var s = this.Fr.F(this.Kr);
                        if (s && t in s) return void this.ui(t, s[t])
                    }
                    this.hi(t)
                }
            }
        }
        save() {
            if (!this.ti) {
                var t = this.ei();
                t > 0 ? q(this.ci) && (this.ci = setTimeout((() => {
                    this.ci = void 0, this.di()
                }), t)) : this.di()
            }
        }
        flush() {
            q(this.ci) || (clearTimeout(this.ci), this.ci = void 0, this.di())
        }
        di() {
            this.ti || (this.Zr ? this.vi() : this.fi(this.Fr, this.Kr, this.props, fn))
        }
        vi() {
            var {
                main: t,
                groups: e
            } = this.pi();
            for (var i of (this.fi(this.Fr, this.Kr, t, fn), Bs)) {
                var r, s = e[i];
                (!H(s) || null != (r = this.Wr[i]) && r.persisted) && this.fi(Ur, this.ri(i), s, i)
            }
        }
        pi() {
            var t = {},
                e = {};
            for (var i of Bs) e[i] = {};
            return br(this.props, ((i, r) => {
                var s, n = null == (s = Gs(r)) ? void 0 : s.storageGroup;
                n ? e[n][r] = i : t[r] = i
            })), {
                main: t,
                groups: e
            }
        }
        ai(t, e) {
            if (e === fn) return JSON.stringify(t) + "|" + this.gi + "|" + this.mi + "|" + this.yi;
            var i = {};
            return br(t, ((t, e) => {
                var r;
                i[e] = null != (r = Gs(e)) && r.volatile ? "__volatile__" : t
            })), JSON.stringify(i)
        }
        fi(t, e, i, r) {
            var s = this.si(r);
            if (r === fn || s.dirty || q(s.fingerprint)) {
                var n;
                try {
                    if ((n = this.ai(i, r)) === s.fingerprint) return void(s.dirty = !1)
                } catch (t) {
                    n = void 0
                }
                t.A(e, i, this.gi, this.mi, this.yi, this.Dt.debug) ? (s.dirty = !1, r !== fn && (s.persisted = !0), q(n) || (s.fingerprint = n)) : this.Dt.debug && oi.warn('failed to persist storage entry "' + e + '"; will retry on next save')
            }
        }
        remove(t) {
            var {
                keepGroupEntries: e = !1
            } = void 0 === t ? {} : t;
            if (q(this.ci) || (clearTimeout(this.ci), this.ci = void 0), this.Fr.q(this.Kr, !1), this.Fr.q(this.Kr, !0), !e && this.Qr)
                for (var i of Bs) Ur.q(this.ri(i));
            e ? delete this.Wr[fn] : this.Wr = {}
        }
        clear() {
            this.remove(), this.props = {}
        }
        register_once(t, e, i) {
            if (B(t)) {
                q(e) && (e = "None"), this.gi = q(i) ? this.bi : i;
                var r = !1;
                if (br(t, ((t, i) => {
                        this.props.hasOwnProperty(i) && this.props[i] !== e || (this.ui(i, t), r = !0)
                    })), r) return this.save(), !0
            }
            return !1
        }
        register(t, e) {
            if (B(t)) {
                this.gi = q(e) ? this.bi : e;
                var i = !1;
                if (br(t, ((e, r) => {
                        t.hasOwnProperty(r) && this.props[r] !== e && (this.ui(r, e), i = !0)
                    })), i) return this.save(), !0
            }
            return !1
        }
        unregister(t) {
            t in this.props && (this.hi(t), this.save())
        }
        update_campaign_params() {
            if (!this.Jr) {
                var t = en(this.Dt.custom_campaign_params, this.Dt.mask_personal_data_properties, this.Dt.custom_personal_data_properties);
                H(kr(t)) || this.register(t), this.Jr = !0
            }
        }
        update_search_keyword() {
            var t;
            this.register((t = null == r ? void 0 : r.referrer) ? sn(t) : {})
        }
        update_referrer_info() {
            var t;
            this.register_once({
                $referrer: an(),
                $referring_domain: null != r && r.referrer && (null == (t = Vs(r.referrer)) ? void 0 : t.host) || on
            }, void 0)
        }
        set_initial_person_info() {
            this.props[Qi] || this.props[Zi] || this.register_once({
                [tr]: ln(this.Dt.mask_personal_data_properties, this.Dt.custom_personal_data_properties)
            }, void 0)
        }
        get_initial_props() {
            var t = {};
            br([Zi, Qi], (e => {
                var i = this.props[e];
                i && br(i, (function(e, i) {
                    t["$initial_" + D(i)] = e
                }))
            }));
            var e, i, r = this.props[tr];
            if (r) {
                var s = (e = un(r), i = {}, br(e, (function(t, e) {
                    i["$initial_" + D(e)] = t
                })), i);
                wr(t, s)
            }
            return t
        }
        safe_merge(t) {
            return br(this.props, (function(e, i) {
                i in t || (t[i] = e)
            })), t
        }
        update_config(t, e, i) {
            this.bi = this.gi = t.cookie_expiration, this.set_disabled(t.disable_persistence || !!i), this.set_cross_subdomain(t.cross_subdomain_cookie), this.set_secure(t.secure_cookie);
            var r = t.persistence !== e.persistence || !((t, e) => {
                    if (t.length !== e.length) return !1;
                    var i = [...t].sort(),
                        r = [...e].sort();
                    return i.every(((t, e) => t === r[e]))
                })(t.cookie_persisted_properties || [], e.cookie_persisted_properties || []),
                s = r ? this.Yr(t) : this.Fr,
                n = this.Xr(t);
            if (r || n !== this.Zr) {
                var o = this.props;
                this.clear(), this.Fr = s, this.Zr = n, this.props = o, this.save()
            }
        }
        set_disabled(t) {
            this.ti = t, this.ti ? this.remove() : this.save()
        }
        set_cross_subdomain(t) {
            t !== this.mi && (this.mi = t, this.remove({
                keepGroupEntries: !0
            }), this.save())
        }
        set_secure(t) {
            t !== this.yi && (this.yi = t, this.remove({
                keepGroupEntries: !0
            }), this.save())
        }
        set_event_timer(t, e) {
            var i = this.props[ci] || {};
            i[t] = e, this.ui(ci, i), this.save()
        }
        remove_event_timer(t) {
            var e = this.props[ci] || {},
                i = e[t];
            return q(i) || (delete e[t], this.ui(ci, e), this.save()), i
        }
        get_property(t) {
            return this.props[t]
        }
        set_property(t, e) {
            this.ui(t, e), this.save()
        }
        ui(t, e) {
            var i;
            this.props[t] = e, null != (i = Gs(t)) && i.volatile || this.wi(t)
        }
        hi(t) {
            delete this.props[t], this.wi(t)
        }
        wi(t) {
            var e, i = null == (e = Gs(t)) ? void 0 : e.storageGroup;
            i && (this.si(i).dirty = !0)
        }
        si(t) {
            return this.Wr[t] || (this.Wr[t] = {})
        }
    }
    var gn = "events",
        _n = "cancelEvents",
        mn = "survey shown",
        yn = "survey dismissed",
        bn = "survey sent",
        wn = "popover",
        xn = ai("[RateLimiter]");
    class En {
        constructor(t) {
            this.serverLimits = {}, this.lastEventRateLimited = !1, this.checkForLimiting = t => {
                var e = t.text;
                if (e && e.length) try {
                    (JSON.parse(e).quota_limited || []).forEach((t => {
                        xn.info((t || "events") + " is quota limited."), this.serverLimits[t] = (new Date).getTime() + 6e4
                    }))
                } catch (t) {
                    return void xn.warn('could not rate limit - continuing. Error: "' + (null == t ? void 0 : t.message) + '"', {
                        text: e
                    })
                }
            }, this.instance = t, this.lastEventRateLimited = this.clientRateLimitContext(!0).isRateLimited
        }
        get captureEventsPerSecond() {
            var t;
            return (null == (t = this.instance.config.rate_limiting) ? void 0 : t.events_per_second) || 10
        }
        get captureEventsBurstLimit() {
            var t;
            return Math.max((null == (t = this.instance.config.rate_limiting) ? void 0 : t.events_burst_limit) || 10 * this.captureEventsPerSecond, this.captureEventsPerSecond)
        }
        clientRateLimitContext(t) {
            var e, i, r;
            void 0 === t && (t = !1);
            var {
                captureEventsBurstLimit: s,
                captureEventsPerSecond: n
            } = this, o = (new Date).getTime(), a = null !== (e = null == (i = this.instance.persistence) ? void 0 : i.get_property(Xi)) && void 0 !== e ? e : {
                tokens: s,
                last: o
            };
            a.tokens += (o - a.last) / 1e3 * n, a.last = o, a.tokens > s && (a.tokens = s);
            var l = 1 > a.tokens;
            return l || t || (a.tokens = Math.max(0, a.tokens - 1)), !l || this.lastEventRateLimited || t || this.instance.capture("$$client_ingestion_warning", {
                $$client_ingestion_warning_message: "posthog-js client rate limited. Config is set to " + n + " events per second and " + s + " events burst limit."
            }, {
                skip_client_rate_limiting: !0
            }), this.lastEventRateLimited = l, null == (r = this.instance.persistence) || r.set_property(Xi, a), {
                isRateLimited: l,
                remainingTokens: a.tokens
            }
        }
        isServerRateLimited(t) {
            var e = this.serverLimits[t || "events"] || !1;
            return !1 !== e && (new Date).getTime() < e
        }
    }
    var Sn = ai("[RemoteConfig]");
    class kn {
        constructor(t) {
            this._instance = t
        }
        get remoteConfig() {
            var t;
            return null == (t = h._POSTHOG_REMOTE_CONFIG) || null == (t = t[this._instance.config.token]) ? void 0 : t.config
        }
        xi(t) {
            var e, i;
            null != (e = h.__PosthogExtensions__) && e.loadExternalDependency ? null == (i = h.__PosthogExtensions__) || null == i.loadExternalDependency || i.loadExternalDependency(this._instance, "remote-config", (() => t(this.remoteConfig))) : t()
        }
        ki(t) {
            this._instance._send_request({
                method: "GET",
                url: this._instance.requestRouter.endpointFor("assets", "/array/" + this._instance.config.token + "/config"),
                callback(e) {
                    t(e.json)
                }
            })
        }
        load() {
            try {
                if (this.remoteConfig) return Sn.info("Using preloaded remote config", this.remoteConfig), this.Si(this.remoteConfig), void this.Ci();
                if (this._instance.Ii()) return void Sn.warn("Remote config is disabled. Falling back to local config.");
                this.xi((t => {
                    if (!t) return Sn.info("No config found after loading remote JS config. Falling back to JSON."), void this.ki((t => {
                        this.Si(t), this.Ci()
                    }));
                    this.Si(t), this.Ci()
                }))
            } catch (t) {
                Sn.error("Error loading remote config", t)
            }
        }
        stop() {
            this.Ti && (clearInterval(this.Ti), this.Ti = void 0)
        }
        refresh() {
            !this._instance.Ii() && r && "hidden" !== r.visibilityState && this._instance.reloadFeatureFlags()
        }
        Ci() {
            var t;
            if (!this.Ti) {
                var e = null !== (t = this._instance.config.remote_config_refresh_interval_ms) && void 0 !== t ? t : 3e5;
                0 !== e && (this.Ti = setInterval((() => {
                    this.refresh()
                }), e))
            }
        }
        Si(t) {
            var e;
            t || Sn.error("Failed to fetch remote config from PostHog."), this._instance.Si(null != t ? t : {}), !1 !== (null == t ? void 0 : t.hasFeatureFlags) && (this._instance.config.advanced_disable_feature_flags_on_first_load || null == (e = this._instance.featureFlags) || e.ensureFlagsLoaded())
        }
    }
    var $n = "gzip-js",
        Pn = "base64",
        Tn = Uint8Array,
        In = Uint16Array,
        Rn = Uint32Array,
        Cn = new Tn([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0, 0]),
        Fn = new Tn([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 0, 0]),
        Mn = new Tn([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]),
        On = function(t, e) {
            for (var i = new In(31), r = 0; 31 > r; ++r) i[r] = e += 1 << t[r - 1];
            var s = new Rn(i[30]);
            for (r = 1; 30 > r; ++r)
                for (var n = i[r]; i[r + 1] > n; ++n) s[n] = n - i[r] << 5 | r;
            return [i, s]
        },
        An = On(Cn, 2),
        Dn = An[1];
    An[0][28] = 258, Dn[258] = 28;
    for (var Ln = On(Fn, 0)[1], jn = new In(32768), zn = 0; 32768 > zn; ++zn) {
        var Nn = (43690 & zn) >>> 1 | (21845 & zn) << 1;
        jn[zn] = ((65280 & (Nn = (61680 & (Nn = (52428 & Nn) >>> 2 | (13107 & Nn) << 2)) >>> 4 | (3855 & Nn) << 4)) >>> 8 | (255 & Nn) << 8) >>> 1
    }
    var Un = function(t, e, i) {
            for (var r = t.length, s = 0, n = new In(e); r > s; ++s) ++n[t[s] - 1];
            var o, a = new In(e);
            for (s = 0; e > s; ++s) a[s] = a[s - 1] + n[s - 1] << 1;
            if (i) {
                o = new In(1 << e);
                var l = 15 - e;
                for (s = 0; r > s; ++s)
                    if (t[s])
                        for (var u = s << 4 | t[s], h = e - t[s], d = a[t[s] - 1]++ << h, v = d | (1 << h) - 1; v >= d; ++d) o[jn[d] >>> l] = u
            } else
                for (o = new In(r), s = 0; r > s; ++s) o[s] = jn[a[t[s] - 1]++] >>> 15 - t[s];
            return o
        },
        Bn = new Tn(288);
    for (zn = 0; 144 > zn; ++zn) Bn[zn] = 8;
    for (zn = 144; 256 > zn; ++zn) Bn[zn] = 9;
    for (zn = 256; 280 > zn; ++zn) Bn[zn] = 7;
    for (zn = 280; 288 > zn; ++zn) Bn[zn] = 8;
    var Hn = new Tn(32);
    for (zn = 0; 32 > zn; ++zn) Hn[zn] = 5;
    var qn = Un(Bn, 9, 0),
        Gn = Un(Hn, 5, 0),
        Vn = function(t) {
            return (t / 8 >> 0) + (7 & t && 1)
        },
        Wn = function(t, e, i) {
            (null == i || i > t.length) && (i = t.length);
            var r = new(t instanceof In ? In : t instanceof Rn ? Rn : Tn)(i - e);
            return r.set(t.subarray(e, i)), r
        },
        Jn = function(t, e, i) {
            var r = e / 8 >> 0;
            t[r] |= i <<= 7 & e, t[r + 1] |= i >>> 8
        },
        Kn = function(t, e, i) {
            var r = e / 8 >> 0;
            t[r] |= i <<= 7 & e, t[r + 1] |= i >>> 8, t[r + 2] |= i >>> 16
        },
        Yn = function(t, e) {
            for (var i = [], r = 0; t.length > r; ++r) t[r] && i.push({
                s: r,
                f: t[r]
            });
            var s = i.length,
                n = i.slice();
            if (!s) return [new Tn(0), 0];
            if (1 == s) {
                var o = new Tn(i[0].s + 1);
                return o[i[0].s] = 1, [o, 1]
            }
            i.sort((function(t, e) {
                return t.f - e.f
            })), i.push({
                s: -1,
                f: 25001
            });
            var a = i[0],
                l = i[1],
                u = 0,
                h = 1,
                d = 2;
            for (i[0] = {
                    s: -1,
                    f: a.f + l.f,
                    l: a,
                    r: l
                }; h != s - 1;) a = i[i[d].f > i[u].f ? u++ : d++], l = i[u != h && i[d].f > i[u].f ? u++ : d++], i[h++] = {
                s: -1,
                f: a.f + l.f,
                l: a,
                r: l
            };
            var v = n[0].s;
            for (r = 1; s > r; ++r) n[r].s > v && (v = n[r].s);
            var c = new In(v + 1),
                f = Xn(i[h - 1], c, 0);
            if (f > e) {
                r = 0;
                var p = 0,
                    g = f - e,
                    _ = 1 << g;
                for (n.sort((function(t, e) {
                        return c[e.s] - c[t.s] || t.f - e.f
                    })); s > r; ++r) {
                    var m = n[r].s;
                    if (e >= c[m]) break;
                    p += _ - (1 << f - c[m]), c[m] = e
                }
                for (p >>>= g; p > 0;) {
                    var y = n[r].s;
                    e > c[y] ? p -= 1 << e - c[y]++ - 1 : ++r
                }
                for (; r >= 0 && p; --r) {
                    var b = n[r].s;
                    c[b] == e && (--c[b], ++p)
                }
                f = e
            }
            return [new Tn(c), f]
        },
        Xn = function(t, e, i) {
            return -1 == t.s ? Math.max(Xn(t.l, e, i + 1), Xn(t.r, e, i + 1)) : e[t.s] = i
        },
        Qn = function(t) {
            for (var e = t.length; e && !t[--e];);
            for (var i = new In(++e), r = 0, s = t[0], n = 1, o = function(t) {
                    i[r++] = t
                }, a = 1; e >= a; ++a)
                if (t[a] == s && a != e) ++n;
                else {
                    if (!s && n > 2) {
                        for (; n > 138; n -= 138) o(32754);
                        n > 2 && (o(n > 10 ? n - 11 << 5 | 28690 : n - 3 << 5 | 12305), n = 0)
                    } else if (n > 3) {
                        for (o(s), --n; n > 6; n -= 6) o(8304);
                        n > 2 && (o(n - 3 << 5 | 8208), n = 0)
                    }
                    for (; n--;) o(s);
                    n = 1, s = t[a]
                }
            return [i.subarray(0, r), e]
        },
        Zn = function(t, e) {
            for (var i = 0, r = 0; e.length > r; ++r) i += t[r] * e[r];
            return i
        },
        to = function(t, e, i) {
            var r = i.length,
                s = Vn(e + 2);
            t[s] = 255 & r, t[s + 1] = r >>> 8, t[s + 2] = 255 ^ t[s], t[s + 3] = 255 ^ t[s + 1];
            for (var n = 0; r > n; ++n) t[s + n + 4] = i[n];
            return 8 * (s + 4 + r)
        },
        eo = function(t, e, i, r, s, n, o, a, l, u, h) {
            Jn(e, h++, i), ++s[256];
            for (var d = Yn(s, 15), v = d[0], c = d[1], f = Yn(n, 15), p = f[0], g = f[1], _ = Qn(v), m = _[0], y = _[1], b = Qn(p), w = b[0], x = b[1], E = new In(19), S = 0; m.length > S; ++S) E[31 & m[S]]++;
            for (S = 0; w.length > S; ++S) E[31 & w[S]]++;
            for (var k = Yn(E, 7), P = k[0], T = k[1], I = 19; I > 4 && !P[Mn[I - 1]]; --I);
            var R, C, F, M, O = u + 5 << 3,
                A = Zn(s, Bn) + Zn(n, Hn) + o,
                D = Zn(s, v) + Zn(n, p) + o + 14 + 3 * I + Zn(E, P) + (2 * E[16] + 3 * E[17] + 7 * E[18]);
            if (A >= O && D >= O) return to(e, h, t.subarray(l, l + u));
            if (Jn(e, h, 1 + (A > D)), h += 2, A > D) {
                R = Un(v, c, 0), C = v, F = Un(p, g, 0), M = p;
                var L = Un(P, T, 0);
                for (Jn(e, h, y - 257), Jn(e, h + 5, x - 1), Jn(e, h + 10, I - 4), h += 14, S = 0; I > S; ++S) Jn(e, h + 3 * S, P[Mn[S]]);
                h += 3 * I;
                for (var j = [m, w], z = 0; 2 > z; ++z) {
                    var N = j[z];
                    for (S = 0; N.length > S; ++S) Jn(e, h, L[U = 31 & N[S]]), h += P[U], U > 15 && (Jn(e, h, N[S] >>> 5 & 127), h += N[S] >>> 12)
                }
            } else R = qn, C = Bn, F = Gn, M = Hn;
            for (S = 0; a > S; ++S)
                if (r[S] > 255) {
                    var U;
                    Kn(e, h, R[257 + (U = r[S] >>> 18 & 31)]), h += C[U + 257], U > 7 && (Jn(e, h, r[S] >>> 23 & 31), h += Cn[U]);
                    var B = 31 & r[S];
                    Kn(e, h, F[B]), h += M[B], B > 3 && (Kn(e, h, r[S] >>> 5 & 8191), h += Fn[B])
                } else Kn(e, h, R[r[S]]), h += C[r[S]];
            return Kn(e, h, R[256]), h + C[256]
        },
        io = new Rn([65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632]),
        ro = function() {
            for (var t = new Rn(256), e = 0; 256 > e; ++e) {
                for (var i = e, r = 9; --r;) i = (1 & i && 3988292384) ^ i >>> 1;
                t[e] = i
            }
            return t
        }(),
        so = function(t, e, i) {
            for (; i; ++e) t[e] = i, i >>>= 8
        };

    function no(t, e) {
        void 0 === e && (e = {});
        var i = function() {
                var t = 4294967295;
                return {
                    p(e) {
                        for (var i = t, r = 0; e.length > r; ++r) i = ro[255 & i ^ e[r]] ^ i >>> 8;
                        t = i
                    },
                    d() {
                        return 4294967295 ^ t
                    }
                }
            }(),
            r = t.length;
        i.p(t);
        var s, n, o, a, l, u = (a = 10 + ((s = e).filename && s.filename.length + 1 || 0), l = 8, function(t, e, i, r, s, n) {
                var o = t.length,
                    a = new Tn(r + o + 5 * (1 + Math.floor(o / 7e3)) + s),
                    l = a.subarray(r, a.length - s),
                    u = 0;
                if (!e || 8 > o)
                    for (var h = 0; o >= h; h += 65535) {
                        var d = h + 65535;
                        o > d ? u = to(l, u, t.subarray(h, d)) : (l[h] = !0, u = to(l, u, t.subarray(h, o)))
                    } else {
                        for (var v = io[e - 1], c = v >>> 13, f = 8191 & v, p = (1 << i) - 1, g = new In(32768), _ = new In(p + 1), m = Math.ceil(i / 3), y = 2 * m, b = function(e) {
                                return (t[e] ^ t[e + 1] << m ^ t[e + 2] << y) & p
                            }, w = new Rn(25e3), x = new In(288), E = new In(32), S = 0, k = 0, P = (h = 0, 0), T = 0, I = 0; o > h; ++h) {
                            var R = b(h),
                                C = 32767 & h,
                                F = _[R];
                            if (g[C] = F, _[R] = C, h >= T) {
                                var M = o - h;
                                if ((S > 7e3 || P > 24576) && M > 423) {
                                    u = eo(t, l, 0, w, x, E, k, P, I, h - I, u), P = S = k = 0, I = h;
                                    for (var O = 0; 286 > O; ++O) x[O] = 0;
                                    for (O = 0; 30 > O; ++O) E[O] = 0
                                }
                                var A = 2,
                                    D = 0,
                                    L = f,
                                    j = C - F & 32767;
                                if (M > 2 && R == b(h - j))
                                    for (var z = Math.min(c, M) - 1, N = Math.min(32767, h), U = Math.min(258, M); N >= j && --L && C != F;) {
                                        if (t[h + A] == t[h + A - j]) {
                                            for (var B = 0; U > B && t[h + B] == t[h + B - j]; ++B);
                                            if (B > A) {
                                                if (A = B, D = j, B > z) break;
                                                var H = Math.min(j, B - 2),
                                                    q = 0;
                                                for (O = 0; H > O; ++O) {
                                                    var G = h - j + O + 32768 & 32767,
                                                        V = G - g[G] + 32768 & 32767;
                                                    V > q && (q = V, F = G)
                                                }
                                            }
                                        }
                                        j += (C = F) - (F = g[C]) + 32768 & 32767
                                    }
                                if (D) {
                                    w[P++] = 268435456 | Dn[A] << 18 | Ln[D];
                                    var W = 31 & Dn[A],
                                        J = 31 & Ln[D];
                                    k += Cn[W] + Fn[J], ++x[257 + W], ++E[J], T = h + A, ++S
                                } else w[P++] = t[h], ++x[t[h]]
                            }
                        }
                        u = eo(t, l, !0, w, x, E, k, P, I, h - I, u)
                    }
                return Wn(a, 0, r + Vn(u) + s)
            }(n = t, null == (o = e).level ? 6 : o.level, null == o.mem ? Math.ceil(1.5 * Math.max(8, Math.min(13, Math.log(n.length)))) : 12 + o.mem, a, l)),
            h = u.length;
        return function(t, e) {
            var i = e.filename;
            if (t[0] = 31, t[1] = 139, t[2] = 8, t[8] = 2 > e.level ? 4 : 9 == e.level ? 2 : 0, t[9] = 3, 0 != e.mtime && so(t, 4, Math.floor(new Date(e.mtime || Date.now()) / 1e3)), i) {
                t[3] = 8;
                for (var r = 0; i.length >= r; ++r) t[r + 10] = i.charCodeAt(r)
            }
        }(u, e), so(u, h - 8, i.d()), so(u, h - 4, r), u
    }
    var oo = !!o || !!n,
        ao = "text/plain",
        lo = !1,
        uo = (t, e) => {
            var [i, r] = t.split("#"), [s, n] = i.split("?");
            if (!n) return t;
            var o = n.split("&").filter((t => t.split("=")[0] !== e)).join("&");
            return s + (o ? "?" + o : "") + (r ? "#" + r : "")
        },
        ho = function(t, e, i) {
            var r;
            void 0 === i && (i = !0);
            var [s, n] = t.split("?"), o = p({}, e), a = null !== (r = null == n ? void 0 : n.split("&").map((t => {
                var e, [r, s] = t.split("="),
                    n = i && null !== (e = o[r]) && void 0 !== e ? e : s;
                return delete o[r], r + "=" + n
            }))) && void 0 !== r ? r : [], l = function(t, e) {
                var i, r;
                void 0 === e && (e = "&");
                var s = [];
                return br(t, (function(t, e) {
                    q(t) || q(e) || "undefined" === e || (i = encodeURIComponent((t => t instanceof File)(t) ? t.name : t.toString()), r = encodeURIComponent(e), s[s.length] = r + "=" + i)
                })), s.join(e)
            }(o);
            return l && a.push(l), s + "?" + a.join("&")
        },
        vo = (t, e) => JSON.stringify(t, ((t, e) => "bigint" == typeof e ? e.toString() : e), e),
        co = t => {
            if (t.Or) return t.Or;
            var {
                data: e,
                compression: i
            } = t;
            if (e) {
                if (i === $n) {
                    var r = no(function(t, e) {
                        var i = t.length;
                        if ("undefined" != typeof TextEncoder) return (new TextEncoder).encode(t);
                        for (var r = new Tn(t.length + (t.length >>> 1)), s = 0, n = function(t) {
                                r[s++] = t
                            }, o = 0; i > o; ++o) {
                            if (s + 5 > r.length) {
                                var a = new Tn(s + 8 + (i - o << 1));
                                a.set(r), r = a
                            }
                            var l = t.charCodeAt(o);
                            128 > l ? n(l) : 2048 > l ? (n(192 | l >>> 6), n(128 | 63 & l)) : l > 55295 && 57344 > l ? (n(240 | (l = 65536 + (1047552 & l) | 1023 & t.charCodeAt(++o)) >>> 18), n(128 | l >>> 12 & 63), n(128 | l >>> 6 & 63), n(128 | 63 & l)) : (n(224 | l >>> 12), n(128 | l >>> 6 & 63), n(128 | 63 & l))
                        }
                        return Wn(r, 0, s)
                    }(vo(e)), {
                        mtime: 0
                    });
                    return {
                        contentType: ao,
                        body: r.buffer.slice(r.byteOffset, r.byteOffset + r.byteLength),
                        estimatedSize: r.byteLength
                    }
                }
                if (i === Pn) {
                    var s = function(t) {
                            return t ? btoa(encodeURIComponent(t).replace(/%([0-9A-F]{2})/g, ((t, e) => String.fromCharCode(parseInt(e, 16))))) : t
                        }(vo(e)),
                        n = (t => "data=" + encodeURIComponent("string" == typeof t ? t : vo(t)))(s);
                    return {
                        contentType: "application/x-www-form-urlencoded",
                        body: n,
                        estimatedSize: new Blob([n]).size
                    }
                }
                var o = vo(e);
                return {
                    contentType: "application/json",
                    body: o,
                    estimatedSize: new Blob([o]).size
                }
            }
        },
        fo = t => {
            var e, i, r, s = co(t);
            return !s || (i = t.compression, r = Ws(t.url, "compression"), i !== x.GZipJS && r !== x.GZipJS && "gzip" !== r) || ((e = s.body) instanceof ArrayBuffer ? P(new Uint8Array(e)) : ArrayBuffer.isView(e) && P(new Uint8Array(e.buffer, e.byteOffset, e.byteLength))) ? {
                url: t.url,
                encodedBody: s
            } : (lo = !0, {
                url: uo(t.url, "compression"),
                encodedBody: co(p({}, t, {
                    compression: void 0,
                    Or: void 0
                }))
            })
        },
        po = function() {
            var t = f((function*(t) {
                var e = vo(t.data),
                    i = yield function(t, e, i) {
                        return C.apply(this, arguments)
                    }(e, v.DEBUG, {
                        rethrow: !0
                    });
                if (!i) return t;
                var r = yield i.arrayBuffer();
                return p({}, t, {
                    Or: {
                        contentType: ao,
                        body: r,
                        estimatedSize: r.byteLength
                    }
                })
            }));
            return function(e) {
                return t.apply(this, arguments)
            }
        }(),
        go = (t, e) => ho(t, {
            _: (new Date).getTime().toString(),
            ver: v.JS_SDK_VERSION,
            compression: e
        }),
        _o = [];
    n && _o.push({
        transport: "fetch",
        method(t) {
            var e, {
                    url: i,
                    encodedBody: r
                } = fo(t),
                {
                    contentType: s,
                    body: o,
                    estimatedSize: l
                } = null != r ? r : {},
                u = new Headers;
            br(t.headers, (function(t, e) {
                u.append(e, t)
            })), s && u.append("Content-Type", s);
            var h = null;
            if (a) {
                var d = new a;
                h = {
                    signal: d.signal,
                    timeout: setTimeout((() => d.abort()), t.timeout)
                }
            }
            n(i, p({
                method: (null == t ? void 0 : t.method) || "GET",
                headers: u,
                keepalive: "POST" === t.method && 52428.8 > (l || 0),
                body: o,
                signal: null == (e = h) ? void 0 : e.signal
            }, t.fetchOptions)).then((e => e.text().then((i => {
                var r = {
                    statusCode: e.status,
                    text: i
                };
                if (200 === e.status) try {
                    r.json = JSON.parse(i)
                } catch (t) {
                    oi.error(t)
                }
                null == t.callback || t.callback(r)
            })))).catch((e => {
                oi.error(e), null == t.callback || t.callback({
                    statusCode: 0,
                    error: e
                })
            })).finally((() => h ? clearTimeout(h.timeout) : null))
        }
    }), o && _o.push({
        transport: "XHR",
        method(t) {
            var e = new o,
                {
                    url: i,
                    encodedBody: r
                } = fo(t);
            e.open(t.method || "GET", i, !0);
            var {
                contentType: s,
                body: n
            } = null != r ? r : {};
            br(t.headers, (function(t, i) {
                e.setRequestHeader(i, t)
            })), s && e.setRequestHeader("Content-Type", s), t.timeout && (e.timeout = t.timeout), e.onreadystatechange = () => {
                if (4 === e.readyState) {
                    var i = {
                        statusCode: e.status,
                        text: e.responseText
                    };
                    if (200 === e.status) try {
                        i.json = JSON.parse(e.responseText)
                    } catch (t) {}
                    null == t.callback || t.callback(i)
                }
            }, e.send(n)
        }
    }), null != i && i.sendBeacon && _o.push({
        transport: "sendBeacon",
        method(t) {
            try {
                var {
                    url: e,
                    encodedBody: r
                } = fo(t), s = ho(e, {
                    beacon: "1"
                }), {
                    contentType: n,
                    body: o
                } = null != r ? r : {};
                if (!o) return;
                var a = o instanceof Blob ? o : new Blob([o], {
                    type: n
                });
                i.sendBeacon(s, a)
            } catch (t) {}
        }
    });
    var mo = 3e3;
    class yo {
        constructor(t, e) {
            this.Ei = !0, this.Mi = [], this.Pi = at((null == e ? void 0 : e.flush_interval_ms) || mo, 250, 5e3, oi.createLogger("flush interval"), mo), this.Ri = t
        }
        enqueue(t) {
            this.Mi.push(t), this.Oi || this.Li()
        }
        unload() {
            this.Ai();
            var t = this.Mi.length > 0 ? this.Fi() : {},
                e = Object.values(t);
            [...e.filter((t => 0 === t.url.indexOf("/e"))), ...e.filter((t => 0 !== t.url.indexOf("/e")))].map((t => {
                this.Ri(p({}, t, {
                    transport: "sendBeacon"
                }))
            }))
        }
        enable() {
            this.Ei = !1, this.Li()
        }
        Li() {
            var t = this;
            this.Ei || (this.Oi = setTimeout((() => {
                if (this.Ai(), this.Mi.length > 0) {
                    var e = this.Fi(),
                        i = function() {
                            var i = e[r],
                                s = (new Date).getTime();
                            i.data && N(i.data) && br(i.data, (t => {
                                t.offset = Math.abs(t.timestamp - s), delete t.timestamp
                            })), t.Ri(i)
                        };
                    for (var r in e) i()
                }
            }), this.Pi))
        }
        Ai() {
            clearTimeout(this.Oi), this.Oi = void 0
        }
        Fi() {
            var t = {};
            return br(this.Mi, (e => {
                var i, r = e,
                    s = (r ? r.batchKey : null) || r.url;
                q(t[s]) && (t[s] = p({}, r, {
                    data: []
                })), null == (i = t[s].data) || i.push(r.data)
            })), this.Mi = [], t
        }
    }
    var bo = ["retriesPerformedSoFar"];
    class wo {
        constructor(e) {
            this.Ni = !1, this.Di = 3e3, this.Mi = [], this._instance = e, this.Mi = [], this.$i = !0, !q(t) && "onLine" in t.navigator && (this.$i = t.navigator.onLine, this.qi = () => {
                this.$i = !0, this.ji()
            }, this.Bi = () => {
                this.$i = !1
            }, Tr(t, "online", this.qi), Tr(t, "offline", this.Bi))
        }
        get length() {
            return this.Mi.length
        }
        retriableRequest(t) {
            var {
                retriesPerformedSoFar: e
            } = t, i = g(t, bo);
            Y(e) && (i.url = ho(i.url, {
                retry_count: e
            })), this._instance._send_request(p({}, i, {
                callback: t => {
                    if (200 !== t.statusCode && (400 > t.statusCode || t.statusCode >= 500)) {
                        if ((0 === t.statusCode ? 3 : 10) > (null != e ? e : 0)) return void this.br(p({
                            retriesPerformedSoFar: e
                        }, i));
                        0 === t.statusCode && oi.warn("Request failed before receiving an HTTP response; this can happen due to network issues, CORS, browser blocking, or ad blockers. Stopped retrying after " + (null != e ? e : 0) + " retries.")
                    }
                    null == i.callback || i.callback(t)
                }
            }))
        }
        br(t) {
            var e = t.retriesPerformedSoFar || 0;
            t.retriesPerformedSoFar = e + 1;
            var i = function(t) {
                    var e = 3e3 * Math.pow(2, t),
                        i = e / 2,
                        r = Math.min(18e5, e),
                        s = Math.random() - .5;
                    return Math.ceil(r + s * (r - i))
                }(e),
                r = Date.now() + i;
            this.Mi.push({
                retryAt: r,
                requestOptions: t
            });
            var s = "Enqueued failed request for retry in " + i;
            navigator.onLine || (s += " (Browser is offline)"), oi.warn(s), this.Ni || (this.Ni = !0, this.Hi())
        }
        Hi() {
            if (this.Ui && clearTimeout(this.Ui), 0 === this.Mi.length) return this.Ni = !1, void(this.Ui = void 0);
            this.Ui = setTimeout((() => {
                this.$i && this.Mi.length > 0 && this.ji(), this.Hi()
            }), this.Di)
        }
        ji() {
            var t = Date.now(),
                e = [],
                i = this.Mi.filter((i => t > i.retryAt || (e.push(i), !1)));
            if (this.Mi = e, i.length > 0)
                for (var {
                        requestOptions: r
                    } of i) this.retriableRequest(r)
        }
        unload() {
            for (var {
                    requestOptions: e
                } of (this.Ui && (clearTimeout(this.Ui), this.Ui = void 0), this.Ni = !1, q(t) || (this.qi && (t.removeEventListener("online", this.qi), this.qi = void 0), this.Bi && (t.removeEventListener("offline", this.Bi), this.Bi = void 0)), this.Mi)) try {
                this._instance._send_request(p({}, e, {
                    transport: "sendBeacon"
                }))
            } catch (t) {
                oi.error(t)
            }
            this.Mi = []
        }
    }
    class xo {
        constructor(t) {
            this.zi = () => {
                var t, e, i, r;
                this.Vi || (this.Vi = {});
                var s = this.scrollElement(),
                    n = this.scrollY(),
                    o = s ? Math.max(0, s.scrollHeight - s.clientHeight) : 0,
                    a = n + ((null == s ? void 0 : s.clientHeight) || 0),
                    l = (null == s ? void 0 : s.scrollHeight) || 0;
                this.Vi.lastScrollY = Math.ceil(n), this.Vi.maxScrollY = Math.max(n, null !== (t = this.Vi.maxScrollY) && void 0 !== t ? t : 0), this.Vi.maxScrollHeight = Math.max(o, null !== (e = this.Vi.maxScrollHeight) && void 0 !== e ? e : 0), this.Vi.lastContentY = a, this.Vi.maxContentY = Math.max(a, null !== (i = this.Vi.maxContentY) && void 0 !== i ? i : 0), this.Vi.maxContentHeight = Math.max(l, null !== (r = this.Vi.maxContentHeight) && void 0 !== r ? r : 0)
            }, this._instance = t
        }
        get Wi() {
            return this._instance.config.scroll_root_selector
        }
        getContext() {
            return this.Vi
        }
        resetContext() {
            var t = this.Vi;
            return setTimeout(this.zi, 0), t
        }
        startMeasuringScrollPosition() {
            Tr(t, "scroll", this.zi, {
                capture: !0
            }), Tr(t, "scrollend", this.zi, {
                capture: !0
            }), Tr(t, "resize", this.zi)
        }
        scrollElement() {
            if (!this.Wi) return null == t ? void 0 : t.document.documentElement;
            var e = N(this.Wi) ? this.Wi : [this.Wi];
            for (var i of e) {
                var r = null == t ? void 0 : t.document.querySelector(i);
                if (r) return r
            }
        }
        Gi(e) {
            var i = "y" === e ? "scrollTop" : "scrollLeft";
            if (this.Wi) {
                var r = this.scrollElement();
                return r && r[i] || 0
            }
            return t ? "y" === e ? t.scrollY || t.pageYOffset || t.document.documentElement.scrollTop || 0 : t.scrollX || t.pageXOffset || t.document.documentElement.scrollLeft || 0 : 0
        }
        scrollY() {
            return this.Gi("y")
        }
        scrollX() {
            return this.Gi("x")
        }
    }
    var Eo = t => ln(null == t ? void 0 : t.config.mask_personal_data_properties, null == t ? void 0 : t.config.custom_personal_data_properties);
    class So {
        constructor(t, e, i, r) {
            this.Zi = t => {
                var e = this.Qi();
                if (!e || e.sessionId !== t) {
                    var i = {
                        sessionId: t,
                        props: this.Ji(this._instance)
                    };
                    this.Ki.register({
                        [Yi]: i
                    })
                }
            }, this._instance = t, this.Yi = e, this.Ki = i, this.Ji = r || Eo, this.Yi.onSessionId(this.Zi)
        }
        Qi() {
            return this.Ki.props[Yi]
        }
        getSetOnceProps() {
            var t, e = null == (t = this.Qi()) ? void 0 : t.props;
            return e ? "r" in e ? un(e) : {
                $referring_domain: e.referringDomain,
                $pathname: e.initialPathName,
                utm_source: e.utm_source,
                utm_campaign: e.utm_campaign,
                utm_medium: e.utm_medium,
                utm_content: e.utm_content,
                utm_term: e.utm_term
            } : {}
        }
        getSessionProps() {
            var t = {};
            return br(kr(this.getSetOnceProps()), ((e, i) => {
                "$current_url" === i && (i = "url"), t["$session_entry_" + D(i)] = e
            })), t
        }
    }
    class ko {
        constructor() {
            this.Xi = {}
        }
        on(t, e) {
            return this.Xi[t] || (this.Xi[t] = []), this.Xi[t].push(e), () => {
                this.Xi[t] = this.Xi[t].filter((t => t !== e))
            }
        }
        emit(t, e) {
            for (var i of this.Xi[t] || []) i(e);
            for (var r of this.Xi["*"] || []) r(t, e)
        }
    }
    var $o = ai("[SessionId]");
    class Po {
        on(t, e) {
            return this.en.on(t, e)
        }
        constructor(t, e, i) {
            var r;
            if (this.tn = null, this.rn = [], this.nn = void 0, this.sn = !1, this.en = new ko, this.an = (t, e) => !(!Y(t) || !Y(e)) && Math.abs(t - e) > this.sessionTimeoutMs, !t.persistence) throw new Error("SessionIdManager requires a PostHogPersistence instance");
            if (t.config.cookieless_mode === ur) throw new Error('SessionIdManager cannot be used with cookieless_mode="always"');
            this.Dt = t.config, this.Ki = t.persistence, this.ln = void 0, this.un = void 0, this._sessionStartTimestamp = null, this._sessionActivityTimestamp = null, this.hn = e || Ar, this.cn = i || Ar;
            var s = this.Dt.persistence_name || this.Dt.token;
            if (this._sessionTimeoutMs = 1e3 * at(this.Dt.session_idle_timeout_seconds || 1800, 60, 36e3, $o.createLogger("session_idle_timeout_seconds"), 1800), t.register({
                    $configured_session_timeout_ms: this._sessionTimeoutMs
                }), this.dn(), this.vn = "ph_" + s + "_window_id", this.fn = "ph_" + s + "_primary_window_exists", this.pn()) {
                var n = Vr.F(this.vn),
                    o = Vr.F(this.fn);
                n && !o ? this.ln = n : Vr.q(this.vn), Vr.A(this.fn, !0)
            }
            if (null != (r = this.Dt.bootstrap) && r.sessionID) try {
                var a = (t => {
                    var e = this.Dt.bootstrap.sessionID.replace(/-/g, "");
                    if (32 !== e.length) throw new Error("Not a valid UUID");
                    if ("7" !== e[12]) throw new Error("Not a UUIDv7");
                    return parseInt(e.substring(0, 12), 16)
                })();
                this.gn(this.Dt.bootstrap.sessionID, (new Date).getTime(), a)
            } catch (t) {
                $o.error("Invalid sessionID in bootstrap", t)
            }
            this.mn()
        }
        get sessionTimeoutMs() {
            return this._sessionTimeoutMs
        }
        onSessionId(t) {
            return q(this.rn) && (this.rn = []), this.rn.push(t), this.un && t(this.un, this.ln), () => {
                this.rn = this.rn.filter((e => e !== t))
            }
        }
        pn() {
            return "memory" !== this.Dt.persistence && !this.Ki.ti && Vr.N()
        }
        yn(t) {
            t !== this.ln && (this.ln = t, this.pn() && Vr.A(this.vn, t))
        }
        bn() {
            return this.ln ? this.ln : this.pn() ? Vr.F(this.vn) : null
        }
        _n(t) {
            var e = this.tn;
            return !W(e) && !W(t) && 5e3 > Math.abs(t - e)
        }
        gn(t, e, i) {
            var r = e !== this._sessionActivityTimestamp,
                s = !(t !== this.un || i !== this._sessionStartTimestamp);
            this._sessionStartTimestamp = i, this._sessionActivityTimestamp = e, this.un = t, s && !r || s && this._n(e) || (this.tn = e, this.Ki.register({
                [Ii]: [e, t, i]
            }))
        }
        wn() {
            var t, e = null == (t = this.Dt) ? void 0 : t.persistence_save_debounce_ms;
            return Y(e) && e > 0
        }
        xn() {
            this.wn() ? this.Ki.refreshKey(Ii) : (this.Ki.flush(), this.Ki.load())
        }
        kn() {
            var t;
            if (!W(this._sessionActivityTimestamp) && this._sessionActivityTimestamp !== this.tn) {
                this.xn();
                var [, e, i] = this.Sn();
                e === this.un && i === this._sessionStartTimestamp && (this.tn = this._sessionActivityTimestamp, this.Ki.register({
                    [Ii]: [this._sessionActivityTimestamp, null !== (t = this.un) && void 0 !== t ? t : null, this._sessionStartTimestamp]
                }), this.Ki.flush())
            }
        }
        Cn() {
            var [t] = this.Sn(), e = Y(t) ? t : 0, i = Y(this._sessionActivityTimestamp) ? this._sessionActivityTimestamp : 0;
            return Math.max(e, i)
        }
        In(t) {
            return this.xn(), this.an(t, this.Cn())
        }
        Sn() {
            var t = this.Ki.props[Ii];
            return N(t) && 2 === t.length && t.push(t[0]), t || [0, null, 0]
        }
        resetSessionId() {
            this.tn = null, clearTimeout(this.Tn), this.Tn = void 0, this.gn(null, null, null)
        }
        destroy() {
            this.sn = !0, this.kn(), clearTimeout(this.Tn), this.Tn = void 0, this.nn && t && (t.removeEventListener(fr, this.nn, {
                capture: !1
            }), this.nn = void 0), this.rn = []
        }
        mn() {
            this.nn = () => {
                this.kn(), this.pn() && Vr.q(this.fn)
            }, Tr(t, fr, this.nn, {
                capture: !1
            })
        }
        checkAndGetSessionAndWindowId(t, e) {
            if (void 0 === t && (t = !1), void 0 === e && (e = null), this.Dt.cookieless_mode === ur) throw new Error('checkAndGetSessionAndWindowId should not be called with cookieless_mode="always"');
            var i = e || (new Date).getTime(),
                [, r, s] = this.Sn(),
                n = this.Cn(),
                o = this.bn(),
                a = Y(s) && Math.abs(i - s) > 864e5,
                l = !1,
                u = !1,
                h = !r,
                d = r,
                v = !h && !t && this.an(i, n);
            v && ((v = this.In(i)) || $o.info("cross-tab refresh kept the session alive", {
                sessionId: r
            }), [, r, s] = this.Sn()), h || v || a ? (r = this.hn(), o = this.cn(), $o.info("new session ID generated", {
                sessionId: r,
                windowId: o,
                changeReason: {
                    noSessionId: h,
                    activityTimeout: v,
                    sessionPastMaximumLength: a
                }
            }), s = i, l = !0) : (o || (o = this.cn(), l = !0), (u = r !== d) && ($o.info("adopted cross-tab session id", {
                sessionId: r,
                windowId: o
            }), l = !0));
            var c = Y(n) && t && !a ? n : i,
                f = Y(s) ? s : (new Date).getTime();
            this.yn(o), this.gn(r, c, f), t || this.dn();
            var p = {
                noSessionId: h,
                activityTimeout: v,
                sessionPastMaximumLength: a,
                crossTabAdoption: u
            };
            return l && this.rn.forEach((t => t(r, o, p))), {
                sessionId: r,
                windowId: o,
                sessionStartTimestamp: f,
                changeReason: l ? p : void 0,
                lastActivityTimestamp: n
            }
        }
        dn() {
            this.sn || (clearTimeout(this.Tn), this.Tn = setTimeout((() => {
                if (!this.sn)
                    if (this.In((new Date).getTime())) {
                        var t = this.un;
                        this.resetSessionId(), this.en.emit("forcedIdleReset", {
                            idleSessionId: t
                        })
                    } else this.dn()
            }), 1.1 * this.sessionTimeoutMs))
        }
    }
    var To = function(t, e) {
            if (!t) return !1;
            var i = t.userAgent;
            if (i && M(i, e)) return !0;
            try {
                var r = null == t ? void 0 : t.userAgentData;
                if (null != r && r.brands && r.brands.some((t => M(null == t ? void 0 : t.brand, e)))) return !0
            } catch (t) {}
            return !!t.webdriver
        },
        Io = function(t, e) {
            if (! function(t) {
                    try {
                        new RegExp(t)
                    } catch (t) {
                        return !1
                    }
                    return !0
                }(e)) return !1;
            try {
                return new RegExp(e).test(t)
            } catch (t) {
                return !1
            }
        };

    function Ro(t, e, i) {
        return vo({
            distinct_id: t,
            userPropertiesToSet: e,
            userPropertiesToSetOnce: i
        })
    }
    var Co = {
            exact: (t, e) => e.some((e => t.some((t => e === t)))),
            is_not: (t, e) => e.every((e => t.every((t => e !== t)))),
            regex: (t, e) => e.some((e => t.some((t => Io(e, t))))),
            not_regex: (t, e) => e.every((e => t.every((t => !Io(e, t))))),
            icontains: (t, e) => e.map(Fo).some((e => t.map(Fo).some((t => e.includes(t))))),
            not_icontains: (t, e) => e.map(Fo).every((e => t.map(Fo).every((t => !e.includes(t))))),
            gt: (t, e) => e.some((e => {
                var i = parseFloat(e);
                return !isNaN(i) && t.some((t => i > parseFloat(t)))
            })),
            lt: (t, e) => e.some((e => {
                var i = parseFloat(e);
                return !isNaN(i) && t.some((t => i < parseFloat(t)))
            }))
        },
        Fo = t => t.toLowerCase();

    function Mo(t, e) {
        return !t || Object.entries(t).every((t => {
            var [i, r] = t, s = null == e ? void 0 : e[i];
            if (q(s) || W(s)) return !1;
            var n = [String(s)],
                o = Co[r.operator];
            return !!o && o(r.values, n)
        }))
    }
    var Oo = "custom",
        Ao = "i.posthog.com",
        Do = /^\/static\//;
    class Lo {
        constructor(t) {
            this.En = {}, this.instance = t
        }
        get apiHost() {
            var t = this.instance.config.api_host.trim().replace(/\/$/, "");
            return "https://app.posthog.com" === t ? "https://us.i.posthog.com" : t
        }
        get flagsApiHost() {
            var t = this.instance.config.flags_api_host;
            return t ? t.trim().replace(/\/$/, "") : this.apiHost
        }
        get uiHost() {
            var t, e = null == (t = this.instance.config.ui_host) ? void 0 : t.replace(/\/$/, "");
            return e || (e = this.apiHost.replace("." + Ao, ".posthog.com")), "https://app.posthog.com" === e ? "https://us.posthog.com" : e
        }
        get region() {
            return this.En[this.apiHost] || (this.En[this.apiHost] = /https:\/\/(app|us|us-assets)(\.i)?\.posthog\.com/i.test(this.apiHost) ? "us" : /https:\/\/(eu|eu-assets)(\.i)?\.posthog\.com/i.test(this.apiHost) ? "eu" : Oo), this.En[this.apiHost]
        }
        Mn(t) {
            if (Do.test(t)) {
                var e = this.instance.config.asset_host;
                if ("string" == typeof e) return e.trim().replace(/\/$/, "") || void 0
            }
        }
        endpointFor(t, e) {
            if (void 0 === e && (e = ""), e && (e = "/" === e[0] ? e : "/" + e), "ui" === t) return this.uiHost + e;
            if ("flags" === t) return this.flagsApiHost + e;
            if ("assets" === t) {
                var i = this.Mn(e);
                if (i) return "" + i + e
            }
            if (this.region === Oo) return this.apiHost + e;
            var r = Ao + e;
            switch (t) {
                case "assets":
                    return "https://" + this.region + "-assets." + r;
                case "api":
                    return "https://" + this.region + "." + r
            }
        }
    }
    var jo = ai("[Surveys]"),
        zo = "seenSurvey_",
        No = ["popover", "widget", "api"],
        Uo = {
            ignoreConditions: !1,
            ignoreDelay: !1,
            displayType: wn
        },
        Bo = ai("[PostHog ExternalIntegrations]"),
        Ho = {
            intercom: "intercom-integration",
            crispChat: "crisp-chat-integration"
        };
    class qo {
        constructor(t) {
            this._instance = t
        }
        qr(t, e) {
            var i;
            null == (i = h.__PosthogExtensions__) || null == i.loadExternalDependency || i.loadExternalDependency(this._instance, t, (t => {
                if (t) return Bo.error("failed to load script", t);
                e()
            }))
        }
        startIfEnabledOrStop() {
            var t = this,
                e = function(e) {
                    var i, s, n;
                    !r || null != (i = h.__PosthogExtensions__) && null != (i = i.integrations) && i[e] || t.qr(Ho[e], (() => {
                        var i;
                        null == (i = h.__PosthogExtensions__) || null == (i = i.integrations) || null == (i = i[e]) || i.start(t._instance)
                    })), !r && null != (s = h.__PosthogExtensions__) && null != (s = s.integrations) && s[e] && (null == (n = h.__PosthogExtensions__) || null == (n = n.integrations) || null == (n = n[e]) || n.stop())
                };
            for (var [i, r] of Object.entries(null !== (s = this._instance.config.integrations) && void 0 !== s ? s : {})) {
                var s;
                e(i)
            }
        }
    }
    var Go, Vo = {},
        Wo = 0,
        Jo = () => {},
        Ko = 'Consent opt in/out is not valid with cookieless_mode="always" and will be ignored',
        Yo = "Surveys module not available",
        Xo = "sanitize_properties is deprecated. Use before_send instead",
        Qo = "Invalid value for property_denylist config: ",
        Zo = "posthog",
        ta = !oo && -1 === (null == u ? void 0 : u.indexOf("MSIE")) && -1 === (null == u ? void 0 : u.indexOf("Mozilla")),
        ea = e => {
            var i;
            return p({
                api_host: "https://us.i.posthog.com",
                flags_api_host: null,
                ui_host: null,
                asset_host: null,
                token: "",
                autocapture: !0,
                cross_subdomain_cookie: Pr(null == r ? void 0 : r.location),
                persistence: "localStorage+cookie",
                persistence_name: "",
                cookie_persisted_properties: [],
                loaded: Jo,
                save_campaign_params: !0,
                custom_campaign_params: [],
                custom_blocked_useragents: [],
                save_referrer: !0,
                capture_pageleave: "if_capture_pageview",
                defaults: null != e ? e : "unset",
                __preview_deferred_init_extensions: !1,
                __preview_external_dependency_versioned_paths: !1,
                __preview_cookie_wins_on_conflict: !1,
                debug: s && G(null == s ? void 0 : s.search) && -1 !== s.search.indexOf("__posthog_debug=true") || !1,
                cookie_expiration: 365,
                upgrade: !1,
                disable_session_recording: !1,
                disable_persistence: !1,
                disable_web_experiments: !0,
                disable_surveys: !1,
                disable_surveys_automatic_display: !1,
                disable_conversations: !1,
                disable_product_tours: !1,
                disable_external_dependency_loading: !1,
                strict_script_versioning: !1,
                enable_recording_console_log: void 0,
                secure_cookie: "https:" === (null == t || null == (i = t.location) ? void 0 : i.protocol),
                ip: !1,
                opt_out_capturing_by_default: !1,
                opt_out_persistence_by_default: !1,
                opt_out_useragent_filter: !1,
                opt_out_capturing_persistence_type: "localStorage",
                consent_persistence_name: null,
                opt_out_capturing_cookie_prefix: null,
                opt_in_site_apps: !1,
                property_denylist: [],
                respect_dnt: !1,
                sanitize_properties: null,
                request_headers: {},
                request_batching: !0,
                properties_string_max_length: 65535,
                mask_all_element_attributes: !1,
                mask_all_text: !1,
                mask_personal_data_properties: !1,
                custom_personal_data_properties: [],
                advanced_disable_flags: !1,
                advanced_disable_decide: !1,
                advanced_disable_feature_flags: !1,
                advanced_disable_feature_flags_on_first_load: !1,
                advanced_only_evaluate_survey_feature_flags: !1,
                advanced_feature_flags_dedup_per_session: !1,
                advanced_enable_surveys: !1,
                advanced_disable_toolbar_metrics: !1,
                feature_flag_request_timeout_ms: 3e3,
                surveys_request_timeout_ms: 1e4,
                on_request_error(t) {
                    oi.error("Bad HTTP status: " + t.statusCode + " " + t.text)
                },
                get_device_id: t => t,
                capture_performance: void 0,
                name: "posthog",
                bootstrap: {},
                disable_compression: !1,
                session_idle_timeout_seconds: 1800,
                person_profiles: vr,
                before_send: void 0,
                request_queue_config: {
                    flush_interval_ms: mo
                },
                error_tracking: {},
                _onCapture: Jo
            }, (t => ({
                rageclick: t && t >= "2026-05-30" ? {
                    content_ignorelist: cs,
                    ignore_text_selection: !0
                } : !t || "2025-11-30" > t || {
                    content_ignorelist: !0
                },
                capture_pageview: !t || "2025-05-24" > t || "history_change",
                session_recording: t && t >= "2026-05-30" ? {
                    strictMinimumDuration: !0,
                    canvasCapture: {
                        resolutionScale: .6
                    }
                } : t && t >= "2025-11-30" ? {
                    strictMinimumDuration: !0
                } : {},
                external_scripts_inject_target: t && t >= "2026-01-30" ? "head" : "body",
                internal_or_test_user_hostname: t && t >= "2026-01-30" ? /^(localhost|127\.0\.0\.1)$/ : void 0,
                persistence_save_debounce_ms: t && t >= "2026-05-30" ? 250 : 0,
                split_storage: !(!t || "2026-05-30" > t),
                detect_google_search_app: !(!t || "2026-05-30" > t)
            }))(e))
        },
        ia = [
            ["process_person", "person_profiles"],
            ["xhr_headers", "request_headers"],
            ["cookie_name", "persistence_name"],
            ["disable_cookie", "disable_persistence"],
            ["__preview_disable_beacon", "disable_beacon"],
            ["store_google", "save_campaign_params"],
            ["verbose", "debug"]
        ],
        ra = t => {
            var e = {};
            for (var [i, r] of ia) q(t[i]) || (e[r] = t[i]);
            var s = wr({}, e, t),
                n = t.__preview_external_dependency_versioned_paths;
            return q(n) || (q(t.strict_script_versioning) && (s.strict_script_versioning = !!n), G(n) && q(t.asset_host) && (s.asset_host = n)), N(t.property_blacklist) && (q(t.property_denylist) ? s.property_denylist = t.property_blacklist : N(t.property_denylist) ? s.property_denylist = [...t.property_blacklist, ...t.property_denylist] : oi.error(Qo + t.property_denylist)), s
        };
    class sa {
        constructor() {
            this.__forceAllowLocalhost = !1
        }
        get Pn() {
            return this.__forceAllowLocalhost
        }
        set Pn(t) {
            oi.error("WebPerformanceObserver is deprecated and has no impact on network capture. Use `_forceAllowLocalhostNetworkCapture` on `posthog.sessionRecording`"), this.__forceAllowLocalhost = t
        }
    }
    class na {
        Rn(t, e) {
            if (t) {
                var i = this.On.indexOf(t); - 1 !== i && this.On.splice(i, 1)
            }
            return this.On.push(e), null == e.initialize || e.initialize(), e
        }
        Ln() {
            return this.config.cookieless_mode === ur || this.config.cookieless_mode === lr && this.consent.isRejected()
        }
        get decideEndpointWasHit() {
            var t, e;
            return null !== (t = null == (e = this.featureFlags) ? void 0 : e.hasLoadedFlags) && void 0 !== t && t
        }
        get flagsEndpointWasHit() {
            var t, e;
            return null !== (t = null == (e = this.featureFlags) ? void 0 : e.hasLoadedFlags) && void 0 !== t && t
        }
        constructor() {
            var t;
            this.webPerformance = new sa, this.An = !1, this.version = v.LIB_VERSION, this.Fn = new ko, this.On = [], this._calculate_event_properties = this.calculateEventProperties.bind(this), this.config = ea(), this.SentryIntegration = Ns, this.sentryIntegration = t => function(t, e) {
                var i = zs(t, e);
                return {
                    name: js,
                    processEvent: t => i(t)
                }
            }(this, t), this.__request_queue = [], this.__loaded = !1, this.analyticsDefaultEndpoint = "/e/", this.Nn = !1, this.Dn = null, this.$n = null, this.qn = null, this.scrollManager = new xo(this), this.pageViewManager = new Us(this), this.rateLimiter = new En(this), this.requestRouter = new Lo(this), this.consent = new Wr(this), this.externalIntegrations = new qo(this);
            var e = null !== (t = na.__defaultExtensionClasses) && void 0 !== t ? t : {};
            this.featureFlags = e.featureFlags && new e.featureFlags(this), this.toolbar = e.toolbar && new e.toolbar(this), this.surveys = e.surveys && new e.surveys(this), this.conversations = e.conversations && new e.conversations(this), this.logs = e.logs && new e.logs(this), this.experiments = e.experiments && new e.experiments(this), this.exceptions = e.exceptions && new e.exceptions(this), this.people = {
                set: (t, e, i) => {
                    var r = G(t) ? {
                        [t]: e
                    } : t;
                    this.setPersonProperties(r), null == i || i({})
                },
                set_once: (t, e, i) => {
                    var r = G(t) ? {
                        [t]: e
                    } : t;
                    this.setPersonProperties(void 0, r), null == i || i({})
                }
            }, this.on("eventCaptured", (t => oi.info('send "' + (null == t ? void 0 : t.event) + '"', t)))
        }
        init(t, e, i) {
            if (i && i !== Zo) {
                var r, s = null !== (r = Vo[i]) && void 0 !== r ? r : new na;
                return s._init(t, e, i), Vo[i] = s, Vo[Zo][i] = s, s
            }
            return this._init(t, e, i)
        }
        _init(e, i, r) {
            var s, n;
            void 0 === i && (i = {});
            var o = G(e) ? e.trim() : "";
            if (!o) return oi.critical("PostHog was initialized without a token. This likely indicates a misconfiguration. Please check the first argument passed to posthog.init()"), this;
            if (this.__loaded) return console.warn("[PostHog.js]", "You have already initialized PostHog! Re-initializing is a no-op"), this;
            this.__loaded = !0, this.config = {}, i.debug = this.jn(i.debug), this.Bn = i, this.Hn = [], i.person_profiles ? this.$n = i.person_profiles : i.process_person && (this.$n = i.process_person);
            var a = ea(i.defaults),
                l = ra(i),
                u = wr({}, a, l, {
                    name: r,
                    token: o
                });
            B(a.rageclick) && B(l.rageclick) && (u.rageclick = wr({}, a.rageclick, l.rageclick)), B(a.session_recording) && B(l.session_recording) && (u.session_recording = wr({}, a.session_recording, l.session_recording)), this.set_config(u), this.config.on_xhr_error && oi.error("on_xhr_error is deprecated. Use on_request_error instead"), this.compression = i.disable_compression ? void 0 : $n;
            var h = this.Un();
            this.persistence = new pn(this.config, h), this.sessionPersistence = "sessionStorage" === this.config.persistence || "memory" === this.config.persistence ? this.persistence : new pn(p({}, this.config, {
                persistence: "sessionStorage"
            }), h, !1);
            var d = p({}, this.persistence.props),
                c = p({}, this.sessionPersistence.props);
            this.register({
                $initialization_time: (new Date).toISOString()
            }), this.zn = new yo((t => this.Vn(t)), this.config.request_queue_config), this.Wn = new wo(this), this.__request_queue = [];
            var f = this.Ln();
            if (f || (this.sessionManager = new Po(this), this.sessionPropsManager = new So(this, this.sessionManager, this.persistence)), this.config.__preview_deferred_init_extensions ? (oi.info("Deferring extension initialization to improve startup performance"), setTimeout((() => {
                    this.Gn(f)
                }), 0)) : (oi.info("Initializing extensions synchronously"), this.Gn(f)), v.DEBUG = v.DEBUG || this.config.debug, v.DEBUG && oi.info("Starting in debug mode", {
                    this: this,
                    config: i,
                    thisC: p({}, this.config),
                    p: d,
                    s: c
                }), !this.config.identity_distinct_id || null != (s = i.bootstrap) && s.distinctID || (i.bootstrap = p({}, i.bootstrap, {
                    distinctID: this.config.identity_distinct_id,
                    isIdentifiedID: !0
                })), void 0 !== (null == (n = i.bootstrap) ? void 0 : n.distinctID)) {
                var g = i.bootstrap.distinctID,
                    _ = this.get_distinct_id(),
                    m = this.persistence.get_property(Ki);
                if (i.bootstrap.isIdentifiedID && null != _ && _ !== g && m === hr) this.identify(g);
                else if (i.bootstrap.isIdentifiedID && null != _ && _ !== g && m === dr) oi.warn("Bootstrap distinctID differs from an already-identified user. The existing identity is preserved. Call reset() before reinitializing if you intend to switch users.");
                else {
                    var y = this.config.get_device_id(Ar()),
                        b = i.bootstrap.isIdentifiedID ? y : g;
                    this.persistence.set_property(Ki, i.bootstrap.isIdentifiedID ? dr : hr), this.register({
                        distinct_id: g,
                        $device_id: b
                    })
                }
            }
            if (f) this.register_once({
                distinct_id: rr,
                $device_id: null
            }, "");
            else if (!this.get_distinct_id()) {
                var w = this.config.get_device_id(Ar());
                this.register_once({
                    distinct_id: w,
                    $device_id: w
                }, ""), this.persistence.set_property(Ki, hr)
            }
            return Tr(t, "onpagehide" in self ? "pagehide" : "unload", this._handle_unload.bind(this), {
                passive: !1
            }), i.segment ? function(t, e) {
                var i = t.config.segment;
                if (!i) return e();
                ! function(t, e) {
                    var i = t.config.segment;
                    if (!i) return e();
                    var r = i => {
                            var r = () => i.anonymousId() || Ar();
                            t.config.get_device_id = r, i.id() && (t.register({
                                distinct_id: i.id(),
                                $device_id: r()
                            }), t.persistence.set_property(Ki, dr)), e()
                        },
                        s = i.user();
                    "then" in s && U(s.then) ? s.then(r) : r(s)
                }(t, (() => {
                    i.register((t => {
                        Promise && Promise.resolve || Ls.warn("This browser does not have Promise support, and can not use the segment integration");
                        var e = (e, i) => {
                            if (!i) return e;
                            e.event.userId || e.event.anonymousId === t.get_distinct_id() || (Ls.info("No userId set, resetting PostHog"), t.reset()), e.event.userId && e.event.userId !== t.get_distinct_id() && (Ls.info("UserId set, identifying with PostHog"), t.identify(e.event.userId));
                            var r = t.calculateEventProperties(i, e.event.properties);
                            return e.event.properties = Object.assign({}, r, e.event.properties), e
                        };
                        return {
                            name: "PostHog JS",
                            type: "enrichment",
                            version: "1.0.0",
                            isLoaded: () => !0,
                            load: () => Promise.resolve(),
                            track: t => e(t, t.event.event),
                            page: t => e(t, pr),
                            identify: t => e(t, _r),
                            screen: t => e(t, "$screen")
                        }
                    })(t)).then((() => {
                        e()
                    }))
                }))
            }(this, (() => this.Zn())) : this.Zn(), U(this.config._onCapture) && this.config._onCapture !== Jo && (oi.warn("onCapture is deprecated. Please use `before_send` instead"), this.on("eventCaptured", (t => this.config._onCapture(t.event, t)))), this.config.ip && oi.warn('The `ip` config option has NO EFFECT AT ALL and has been deprecated. Use a custom transformation or "Discard IP data" project setting instead. See https://posthog.com/tutorials/web-redact-properties#hiding-customer-ip-address for more information.'), this
        }
        Gn(t) {
            var e, i, r, s, n, o, a, l = performance.now(),
                u = p({}, na.__defaultExtensionClasses, this.config.__extensionClasses),
                h = [];
            u.featureFlags && this.On.push(this.featureFlags = null !== (e = this.featureFlags) && void 0 !== e ? e : new u.featureFlags(this)), u.exceptions && this.On.push(this.exceptions = null !== (i = this.exceptions) && void 0 !== i ? i : new u.exceptions(this)), u.historyAutocapture && this.On.push(this.historyAutocapture = new u.historyAutocapture(this)), u.tracingHeaders && this.On.push(this.tracingHeaders = new u.tracingHeaders(this)), u.siteApps && this.On.push(this.siteApps = new u.siteApps(this)), u.sessionRecording && !t && this.On.push(this.sessionRecording = new u.sessionRecording(this)), this.config.disable_scroll_properties || h.push((() => {
                this.scrollManager.startMeasuringScrollPosition()
            })), u.autocapture && this.On.push(this.autocapture = new u.autocapture(this)), u.surveys && this.On.push(this.surveys = null !== (r = this.surveys) && void 0 !== r ? r : new u.surveys(this)), u.logs && this.On.push(this.logs = null !== (s = this.logs) && void 0 !== s ? s : new u.logs(this)), u.conversations && this.On.push(this.conversations = null !== (n = this.conversations) && void 0 !== n ? n : new u.conversations(this)), u.productTours && this.On.push(this.productTours = new u.productTours(this)), u.heatmaps && this.On.push(this.heatmaps = new u.heatmaps(this)), u.webVitalsAutocapture && this.On.push(this.webVitalsAutocapture = new u.webVitalsAutocapture(this)), u.exceptionObserver && this.On.push(this.exceptionObserver = new u.exceptionObserver(this)), u.deadClicksAutocapture && this.On.push(this.deadClicksAutocapture = new u.deadClicksAutocapture(this, As)), u.toolbar && this.On.push(this.toolbar = null !== (o = this.toolbar) && void 0 !== o ? o : new u.toolbar(this)), u.experiments && this.On.push(this.experiments = null !== (a = this.experiments) && void 0 !== a ? a : new u.experiments(this)), this.On.forEach((t => {
                t.initialize && h.push((() => {
                    null == t.initialize || t.initialize()
                }))
            })), h.push((() => {
                if (this.Qn) {
                    var t = this.Qn;
                    this.Qn = void 0, this.Si(t)
                }
            })), this.Jn(h, l)
        }
        Jn(t, e) {
            for (; t.length > 0;) {
                if (this.config.__preview_deferred_init_extensions && performance.now() - e >= 30 && t.length > 0) return void setTimeout((() => {
                    this.Jn(t, e)
                }), 0);
                var i = t.shift();
                if (i) try {
                    i()
                } catch (t) {
                    oi.error("Error initializing extension:", t)
                }
            }
            var r = Math.round(performance.now() - e);
            this.register_for_session({
                [sr]: this.config.__preview_deferred_init_extensions ? "deferred" : "synchronous",
                [nr]: r
            }), this.config.__preview_deferred_init_extensions && oi.info("PostHog extensions initialized (" + r + "ms)")
        }
        Si(t) {
            var e;
            if (!r || !r.body) return oi.info("document not ready yet, trying again in 500 milliseconds..."), void setTimeout((() => {
                this.Si(t)
            }), 500);
            this.config.__preview_deferred_init_extensions && (this.Qn = t), this.Kn = t, this.compression = void 0, t.supportedCompression && !this.config.disable_compression && (this.compression = O(t.supportedCompression, $n) ? $n : O(t.supportedCompression, Pn) ? Pn : void 0), null != (e = t.analytics) && e.endpoint && (this.analyticsDefaultEndpoint = t.analytics.endpoint), this.set_config({
                person_profiles: this.$n ? this.$n : vr
            }), this.On.forEach((e => null == e.onRemoteConfig ? void 0 : e.onRemoteConfig(t)))
        }
        Zn() {
            try {
                this.config.loaded(this)
            } catch (t) {
                oi.critical("`loaded` function failed", t)
            }
            if (this.Yn(), this.config.internal_or_test_user_hostname && null != s && s.hostname) {
                var t = s.hostname,
                    e = this.config.internal_or_test_user_hostname;
                ("string" == typeof e ? t === e : e.test(t)) && this.setInternalOrTestUser()
            }
            this.config.capture_pageview && setTimeout((() => {
                (this.consent.isOptedIn() || this.Ln()) && this.Xn()
            }), 1), this.es = new kn(this), this.es.load()
        }
        Yn() {
            var t;
            this.is_capturing() && this.config.request_batching && (null == (t = this.zn) || t.enable())
        }
        _dom_loaded() {
            this.is_capturing() && yr(this.__request_queue, (t => this.Vn(t))), this.__request_queue = [], this.Yn()
        }
        _handle_unload() {
            var t, e, i, r;
            null == (t = this.surveys) || t.handlePageUnload(), this.config.request_batching ? (this.ts() && this.capture(gr), null == (e = this.logs) || e.flushLogs("sendBeacon"), null == (i = this.zn) || i.unload(), null == (r = this.Wn) || r.unload()) : this.ts() && this.capture(gr, null, {
                transport: "sendBeacon"
            })
        }
        _send_request(t) {
            this.__loaded ? ta ? this.__request_queue.push(t) : this.rateLimiter.isServerRateLimited(t.batchKey) ? t.fireCallbackOnDrop && (null == t.callback || t.callback({
                statusCode: 429
            })) : (t.transport = t.transport || this.config.api_transport, t.skipIPParam || (t.url = ho(t.url, {
                ip: this.config.ip ? 1 : 0
            })), t.headers = p({}, this.config.request_headers, t.headers), t.compression = "best-available" === t.compression ? this.compression : t.compression, (q(this.config.disable_beacon) ? this.config.__preview_disable_beacon : this.config.disable_beacon) && (t.disableTransport = ["sendBeacon"]), t.fetchOptions = t.fetchOptions || this.config.fetch_options, (t => {
                var e, i, r, s = p({}, t);
                s.timeout = s.timeout || 6e4, s.url = go(s.url, s.compression);
                var n = null !== (e = s.transport) && void 0 !== e ? e : "fetch",
                    o = _o.filter((t => !s.disableTransport || !t.transport || !s.disableTransport.includes(t.transport))),
                    a = null !== (i = null == (r = function(t, e) {
                        for (var i = 0; t.length > i; i++)
                            if (t[i].transport === n) return t[i]
                    }(o)) ? void 0 : r.method) && void 0 !== i ? i : o[0].method;
                if (!a) throw new Error("No available transport method");
                "sendBeacon" !== n && s.data && s.compression === $n && l && !lo ? po(s).then((t => {
                    a(t)
                })).catch((e => {
                    if (T(e)) return lo = !0, void a(p({}, s, {
                        compression: void 0,
                        url: go(t.url, void 0)
                    }));
                    (t => {
                        if (!t || "object" != typeof t) return !1;
                        var e = "name" in t ? String(t.name) : "";
                        return T(t) || e === k
                    })(e) && (lo = !0), a(s)
                })) : a(s)
            })(p({}, t, {
                callback: e => {
                    var i, r;
                    this.rateLimiter.checkForLimiting(e), 400 > e.statusCode || null == (i = (r = this.config).on_request_error) || i.call(r, e), null == t.callback || t.callback(e)
                }
            }))) : t.fireCallbackOnDrop && (null == t.callback || t.callback({
                statusCode: 0
            }))
        }
        Vn(t) {
            this.Wn ? this.Wn.retriableRequest(t) : this._send_request(t)
        }
        _execute_array(t) {
            Wo++;
            try {
                var e, i = [],
                    r = [],
                    s = [];
                yr(t, (t => {
                    if (t)
                        if (N(e = t[0])) s.push(t);
                        else if (U(t)) try {
                        t.call(this)
                    } catch (e) {
                        oi.error("Error executing queued PostHog call", t, e)
                    } else N(t) && "alias" === e ? i.push(t) : N(t) && -1 !== e.indexOf("capture") && U(this[e]) ? s.push(t) : r.push(t)
                }));
                var n = function(t, e) {
                    yr(t, (function(t) {
                        try {
                            if (N(t[0])) {
                                var i = e;
                                br(t, (function(t) {
                                    i = i[t[0]].apply(i, t.slice(1))
                                }))
                            } else e[t[0]].apply(e, t.slice(1))
                        } catch (e) {
                            oi.error("Error executing queued PostHog call", t, e)
                        }
                    }))
                };
                n(i, this), n(r, this), n(s, this)
            } finally {
                Wo--
            }
        }
        push(t) {
            if (Wo > 0 && N(t) && G(t[0])) {
                var e = na.prototype[t[0]];
                U(e) && e.apply(this, t.slice(1))
            } else this._execute_array([t])
        }
        capture(t, e, i) {
            var r, s, n, o, a;
            if (this.__loaded && this.persistence && this.sessionPersistence && this.zn) {
                if (this.is_capturing())
                    if (!q(t) && G(t)) {
                        var l = !this.config.opt_out_useragent_filter && this._is_bot();
                        if (!l || this.config.__preview_capture_bot_pageviews) {
                            var u = null != i && i.skip_client_rate_limiting ? void 0 : this.rateLimiter.clientRateLimitContext();
                            if (null == u || !u.isRateLimited) {
                                null != e && e.$current_url && !G(null == e ? void 0 : e.$current_url) && (oi.error("Invalid `$current_url` property provided to `posthog.capture`. Input must be a string. Ignoring provided value."), null == e || delete e.$current_url), "$exception" !== t || null != i && i.rs || oi.warn("Using `posthog.capture('$exception')` is unreliable because it does not attach required metadata. Use `posthog.captureException(error)` instead, which attaches required metadata automatically."), this.sessionPersistence.update_search_keyword(), this.config.save_campaign_params && this.sessionPersistence.update_campaign_params(), this.config.save_referrer && this.sessionPersistence.update_referrer_info(), (this.config.save_campaign_params || this.config.save_referrer) && this.persistence.set_initial_person_info();
                                var h = new Date,
                                    d = (null == i ? void 0 : i.timestamp) || h,
                                    v = fe(null == i ? void 0 : i.uuid, Ar),
                                    c = {
                                        uuid: v,
                                        event: t,
                                        properties: this.calculateEventProperties(t, e || {}, d, v)
                                    };
                                t === pr && this.config.__preview_capture_bot_pageviews && l && (c.event = "$bot_pageview", c.properties.$browser_type = "bot"), u && (c.properties.$lib_rate_limit_remaining_tokens = u.remainingTokens), (null == i ? void 0 : i.$set) && (c.$set = null == i ? void 0 : i.$set);
                                var f = null == i ? void 0 : i.$unset;
                                f && (c.$unset = f);
                                var g, _, m, y = this.ns(null == i ? void 0 : i.$set_once, t !== mr, t === _r);
                                if (y && (c.$set_once = y), null != i && i._noTruncate || (s = this.config.properties_string_max_length, n = c, o = t => G(t) ? t.slice(0, s) : t, a = new Set, c = function t(e, i) {
                                        return e !== Object(e) ? o ? o(e) : e : a.has(e) ? void 0 : (a.add(e), N(e) ? (r = [], yr(e, (e => {
                                            r.push(t(e))
                                        }))) : (r = {}, br(e, ((e, i) => {
                                            a.has(e) || (r[i] = t(e, i))
                                        }))), r);
                                        var r
                                    }(n)), c.timestamp = d, q(null == i ? void 0 : i.timestamp) || (c.properties.$event_time_override_provided = !0, c.properties.$event_time_override_system_time = h), t === yn || t === bn) {
                                    var b = null == e ? void 0 : e.$survey_id,
                                        w = null == e ? void 0 : e.$survey_iteration;
                                    (t => {
                                        try {
                                            var e = (t => ((t, e) => {
                                                var i = "" + t + e.id;
                                                return e.current_iteration && e.current_iteration > 0 && (i = "" + t + e.id + "_" + e.current_iteration), i
                                            })(zo, t))(t);
                                            if (localStorage.getItem(e)) return;
                                            localStorage.setItem(e, "true")
                                        } catch (t) {
                                            jo.error("Failed to persist survey seen state", t)
                                        }
                                    })({
                                        id: b,
                                        current_iteration: w
                                    }), c.$set = p({}, c.$set, {
                                        [(g = {
                                            id: b,
                                            current_iteration: w
                                        }, _ = t === bn ? "responded" : "dismissed", m = "$survey_" + _ + "/" + g.id, g.current_iteration && g.current_iteration > 0 && (m = "$survey_" + _ + "/" + g.id + "/" + g.current_iteration), m)]: !0
                                    })
                                } else t === mn && (c.$set = p({}, c.$set, {
                                    $survey_last_seen_date: (new Date).toISOString()
                                }));
                                if ("product tour shown" === t) {
                                    var x = null == e ? void 0 : e.$product_tour_type;
                                    x && (c.$set = p({}, c.$set, {
                                        ["$product_tour_last_seen_date/" + x]: (new Date).toISOString()
                                    }))
                                }
                                var E = p({}, c.properties.$set, c.$set);
                                if (H(E) || this.setPersonPropertiesForFlags(E), !J(this.config.before_send)) {
                                    var S = this.mr(c);
                                    if (!S) return;
                                    (c = S).uuid = fe(c.uuid, Ar)
                                }
                                this.Fn.emit("eventCaptured", c);
                                var k = {
                                    method: "POST",
                                    url: null !== (r = null == i ? void 0 : i._url) && void 0 !== r ? r : this.requestRouter.endpointFor("api", this.analyticsDefaultEndpoint),
                                    data: c,
                                    compression: "best-available",
                                    batchKey: null == i ? void 0 : i._batchKey,
                                    transport: null == i ? void 0 : i.transport
                                };
                                return !this.config.request_batching || i && (null == i || !i._batchKey) || null != i && i.send_instantly ? this.Vn(k) : this.zn.enqueue(k), c
                            }
                            oi.critical("This capture call is ignored due to client rate limiting.")
                        }
                    } else oi.error("No event name provided to posthog.capture")
            } else oi.uninitializedWarning("posthog.capture")
        }
        _addCaptureHook(t) {
            return this.on("eventCaptured", (e => t(e.event, e)))
        }
        calculateEventProperties(e, i, n, o, a) {
            if (n = n || new Date, !this.persistence || !this.sessionPersistence) return i;
            var l = a ? void 0 : this.persistence.remove_event_timer(e),
                h = p({}, i);
            if (h.token = this.config.token, h.$config_defaults = this.config.defaults, this.Ln() && (h.$cookieless_mode = !0), "$snapshot" === e) {
                var d = p({}, this.persistence.properties(), this.sessionPersistence.properties());
                return h.distinct_id = d.distinct_id, (!G(h.distinct_id) && !K(h.distinct_id) || V(h.distinct_id)) && oi.error("Invalid distinct_id for replay event. This indicates a bug in your implementation"), h
            }
            var c, f = function(e, i, r) {
                var n, o, a, l;
                if (!u) return {};
                var h, d, c, f, p, g, _, m, y, b = e ? [...Xs, ...i || []] : [],
                    [w, x] = function(t) {
                        for (var e = 0; de.length > e; e++) {
                            var [i, r] = de[e], s = i.exec(t), n = s && (U(r) ? r(s, t) : r);
                            if (n) return n
                        }
                        return ["", ""]
                    }(u),
                    E = null != (h = "undefined" != typeof navigator ? navigator : void 0) && h.brave ? {
                        brave: !0
                    } : {},
                    S = {
                        detectGoogleSearchApp: r
                    },
                    k = wr(kr({
                        $os: w,
                        $os_version: x,
                        $browser: le(u, navigator.vendor, E, S),
                        $device: ve(u),
                        $device_type: (c = u, f = {
                            userAgentDataPlatform: null == (n = navigator) || null == (n = n.userAgentData) ? void 0 : n.platform,
                            maxTouchPoints: null == (o = navigator) ? void 0 : o.maxTouchPoints,
                            screenWidth: null == t || null == (a = t.screen) ? void 0 : a.width,
                            screenHeight: null == t || null == (l = t.screen) ? void 0 : l.height,
                            devicePixelRatio: null == t ? void 0 : t.devicePixelRatio
                        }, y = ve(c), y === ft || y === ct || "Kobo" === y || "Kindle Fire" === y || y === qt ? vt : y === Mt || y === At || y === Ot || y === Ut ? "Console" : y === gt ? "Wearable" : y ? ut : "Android" === (null == f ? void 0 : f.userAgentDataPlatform) && (null !== (p = null == f ? void 0 : f.maxTouchPoints) && void 0 !== p ? p : 0) > 0 ? 600 > Math.min(null !== (g = null == f ? void 0 : f.screenWidth) && void 0 !== g ? g : 0, null !== (_ = null == f ? void 0 : f.screenHeight) && void 0 !== _ ? _ : 0) / (null !== (m = null == f ? void 0 : f.devicePixelRatio) && void 0 !== m ? m : 1) ? ut : vt : "Desktop"),
                        $timezone: hn(),
                        $timezone_offset: dn()
                    }), {
                        $current_url: Js(null == s ? void 0 : s.href, b, Zs),
                        $host: null == s ? void 0 : s.host,
                        $pathname: null == s ? void 0 : s.pathname,
                        $raw_user_agent: u.length > 1e3 ? u.substring(0, 997) + "..." : u,
                        $browser_version: he(u, navigator.vendor, E, S),
                        $browser_language: nn(),
                        $browser_language_prefix: (d = nn(), "string" == typeof d ? d.split("-")[0] : void 0),
                        $screen_height: null == t ? void 0 : t.screen.height,
                        $screen_width: null == t ? void 0 : t.screen.width,
                        $viewport_height: null == t ? void 0 : t.innerHeight,
                        $viewport_width: null == t ? void 0 : t.innerWidth,
                        $lib: v.LIB_NAME,
                        $lib_version: v.LIB_VERSION,
                        $insert_id: Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10),
                        $time: Date.now() / 1e3
                    });
                return v.SDK_DIST_CHANNEL && (k.$sdk_dist_channel = v.SDK_DIST_CHANNEL), k
            }(this.config.mask_personal_data_properties, this.config.custom_personal_data_properties, this.config.detect_google_search_app);
            if (this.sessionManager) {
                var {
                    sessionId: g,
                    windowId: _
                } = this.sessionManager.checkAndGetSessionAndWindowId(a, n.getTime());
                h.$session_id = g, h.$window_id = _
            }
            this.sessionPropsManager && wr(h, this.sessionPropsManager.getSessionProps());
            try {
                var m;
                this.sessionRecording && wr(h, this.sessionRecording.sdkDebugProperties), h.$sdk_debug_retry_queue_size = null == (m = this.Wn) ? void 0 : m.length
            } catch (t) {
                h.$sdk_debug_error_capturing_properties = String(t)
            }
            if (this.requestRouter.region === Oo && (h.$lib_custom_api_host = this.config.api_host), c = e !== pr || a ? e !== gr || a ? this.pageViewManager.doEvent() : this.pageViewManager.doPageLeave(n) : this.pageViewManager.doPageView(n, o), h = wr(h, c), e === pr && r && (h.title = r.title), !q(l)) {
                var y = n.getTime() - l;
                h.$duration = parseFloat((y / 1e3).toFixed(3))
            }
            u && this.config.opt_out_useragent_filter && (h.$browser_type = this._is_bot() ? "bot" : "browser"), (h = wr({}, f, this.persistence.properties(), this.sessionPersistence.properties(), h)).$is_identified = this._isIdentified(), N(this.config.property_denylist) ? br(this.config.property_denylist, (function(t) {
                delete h[t]
            })) : oi.error(Qo + this.config.property_denylist + " or property_blacklist config: " + this.config.property_blacklist);
            var b = this.config.sanitize_properties;
            b && (oi.error(Xo), h = b(h, e));
            var w = this.ss();
            return h.$process_person_profile = w, w && !a && this.os("_calculate_event_properties"), h
        }
        ns(t, e, i) {
            var r;
            if (void 0 === e && (e = !0), void 0 === i && (i = !1), !this.persistence || !this.ss()) return t;
            if (this.An && !i) return t;
            var s = this.persistence.get_initial_props(),
                n = null == (r = this.sessionPropsManager) ? void 0 : r.getSetOnceProps(),
                o = wr({}, s, n || {}, t || {}),
                a = this.config.sanitize_properties;
            return a && (oi.error(Xo), o = a(o, "$set_once")), e && (this.An = !0), H(o) ? void 0 : o
        }
        register(t, e) {
            var i;
            null == (i = this.persistence) || i.register(t, e)
        }
        register_once(t, e, i) {
            var r;
            null == (r = this.persistence) || r.register_once(t, e, i)
        }
        register_for_session(t) {
            var e;
            null == (e = this.sessionPersistence) || e.register(t)
        }
        unregister(t) {
            var e;
            null == (e = this.persistence) || e.unregister(t)
        }
        unregister_for_session(t) {
            var e;
            null == (e = this.sessionPersistence) || e.unregister(t)
        }
        ls(t, e) {
            this.register({
                [t]: e
            })
        }
        getFeatureFlag(t, e) {
            var i;
            return null == (i = this.featureFlags) ? void 0 : i.getFeatureFlag(t, e)
        }
        getFeatureFlagPayload(t) {
            var e;
            return null == (e = this.featureFlags) ? void 0 : e.getFeatureFlagPayload(t)
        }
        getFeatureFlagResult(t, e) {
            var i;
            return null == (i = this.featureFlags) ? void 0 : i.getFeatureFlagResult(t, e)
        }
        isFeatureEnabled(t, e) {
            var i;
            return null == (i = this.featureFlags) ? void 0 : i.isFeatureEnabled(t, e)
        }
        reloadFeatureFlags() {
            var t;
            null == (t = this.featureFlags) || t.reloadFeatureFlags()
        }
        updateFlags(t, e, i) {
            var r;
            null == (r = this.featureFlags) || r.updateFlags(t, e, i)
        }
        updateEarlyAccessFeatureEnrollment(t, e, i) {
            var r;
            null == (r = this.featureFlags) || r.updateEarlyAccessFeatureEnrollment(t, e, i)
        }
        getEarlyAccessFeatures(t, e, i) {
            var r;
            return void 0 === e && (e = !1), null == (r = this.featureFlags) ? void 0 : r.getEarlyAccessFeatures(t, e, i)
        }
        on(t, e) {
            return this.Fn.on(t, e)
        }
        onFeatureFlags(t) {
            return this.featureFlags ? this.featureFlags.onFeatureFlags(t) : (t([], {}, {
                errorsLoading: !0
            }), () => {})
        }
        onSurveysLoaded(t) {
            return this.surveys ? this.surveys.onSurveysLoaded(t) : (t([], {
                isLoaded: !1,
                error: Yo
            }), () => {})
        }
        onSessionId(t) {
            var e, i;
            return null !== (e = null == (i = this.sessionManager) ? void 0 : i.onSessionId(t)) && void 0 !== e ? e : () => {}
        }
        getSurveys(t, e) {
            void 0 === e && (e = !1), this.surveys ? this.surveys.getSurveys(t, e) : t([], {
                isLoaded: !1,
                error: Yo
            })
        }
        getActiveMatchingSurveys(t, e) {
            void 0 === e && (e = !1), this.surveys ? this.surveys.getActiveMatchingSurveys(t, e) : t([], {
                isLoaded: !1,
                error: Yo
            })
        }
        renderSurvey(t, e) {
            var i;
            null == (i = this.surveys) || i.renderSurvey(t, e)
        }
        displaySurvey(t, e) {
            var i;
            void 0 === e && (e = Uo), null == (i = this.surveys) || i.displaySurvey(t, e)
        }
        cancelPendingSurvey(t) {
            var e;
            null == (e = this.surveys) || e.cancelPendingSurvey(t)
        }
        canRenderSurvey(t) {
            var e, i;
            return null !== (e = null == (i = this.surveys) ? void 0 : i.canRenderSurvey(t)) && void 0 !== e ? e : {
                visible: !1,
                disabledReason: Yo
            }
        }
        canRenderSurveyAsync(t, e) {
            var i, r;
            return void 0 === e && (e = !1), null !== (i = null == (r = this.surveys) ? void 0 : r.canRenderSurveyAsync(t, e)) && void 0 !== i ? i : Promise.resolve({
                visible: !1,
                disabledReason: Yo
            })
        }
        us(t) {
            return !t || V(t) ? (oi.critical("Unique user id has not been set in posthog.identify"), !1) : t === rr ? (oi.critical('The string "' + t + '" was set in posthog.identify which indicates an error. This ID is only used as a sentinel value.'), !1) : !["distinct_id", "distinctid"].includes(t.toLowerCase()) && !["undefined", "null"].includes(t.toLowerCase()) || (oi.critical('The string "' + t + '" was set in posthog.identify which indicates an error. This ID should be unique to the user and not a hardcoded string.'), !1)
        }
        identify(t, e, i) {
            if (!this.__loaded || !this.persistence) return oi.uninitializedWarning("posthog.identify");
            if (K(t) && (t = t.toString(), oi.warn("The first argument to posthog.identify was a number, but it should be a string. It has been converted to a string.")), this.us(t) && this.os("posthog.identify")) {
                var r = this.get_distinct_id();
                this.register({
                    $user_id: t
                }), this.get_property(di) || this.register_once({
                    $had_persisted_distinct_id: !0,
                    $device_id: r
                }, ""), t !== r && t !== this.get_property(vi) && (this.unregister(vi), this.register({
                    distinct_id: t
                }));
                var s, n = (this.persistence.get_property(Ki) || hr) === hr;
                t !== r && n ? (this.persistence.set_property(Ki, dr), this.setPersonPropertiesForFlags({
                    $set: e || {},
                    $set_once: i || {}
                }, !1), this.capture(_r, {
                    distinct_id: t,
                    $anon_distinct_id: r
                }, {
                    $set: e || {},
                    $set_once: i || {}
                }), this.qn = Ro(t, e, i), null == (s = this.featureFlags) || s.setAnonymousDistinctId(r)) : (e || i) && this.setPersonProperties(e, i), t !== r && (this.reloadFeatureFlags(), this.unregister(Gi))
            }
        }
        setPersonProperties(t, e) {
            if ((t || e) && this.os("posthog.setPersonProperties")) {
                var i = Ro(this.get_distinct_id(), t, e);
                this.qn !== i ? (this.setPersonPropertiesForFlags({
                    $set: t || {},
                    $set_once: e || {}
                }, !0), this.capture("$set", {
                    $set: t || {},
                    $set_once: e || {}
                }), this.qn = i) : oi.info("A duplicate setPersonProperties call was made with the same properties. It has been ignored.")
            }
        }
        unsetPersonProperties(t) {
            var e, i = (N(t) ? t : [t]).filter((t => G(t) && t.length > 0));
            0 !== i.length && this.os("posthog.unsetPersonProperties") && (null == (e = this.featureFlags) || e.unsetPersonPropertiesForFlags(i, !0), this.capture("$set", {
                $unset: i
            }), this.qn = null)
        }
        group(t, e, i) {
            if (t && e) {
                var r = this.getGroups(),
                    s = r[t] !== e;
                if (s && this.resetGroupPropertiesForFlags(t), this.register({
                        $groups: p({}, r, {
                            [t]: e
                        })
                    }), s || i) {
                    var n = {
                        $group_type: t,
                        $group_key: e
                    };
                    i && (n.$group_set = i), this.capture(mr, n)
                }
                i && this.setGroupPropertiesForFlags({
                    [t]: i
                }), s && !i && this.reloadFeatureFlags()
            } else oi.error("posthog.group requires a group type and group key")
        }
        resetGroups() {
            this.register({
                $groups: {}
            }), this.resetGroupPropertiesForFlags(), this.reloadFeatureFlags()
        }
        setPersonPropertiesForFlags(t, e) {
            var i;
            void 0 === e && (e = !0), null == (i = this.featureFlags) || i.setPersonPropertiesForFlags(t, e)
        }
        resetPersonPropertiesForFlags(t) {
            var e;
            void 0 === t && (t = !0), null == (e = this.featureFlags) || e.resetPersonPropertiesForFlags(t)
        }
        setGroupPropertiesForFlags(t, e) {
            var i;
            void 0 === e && (e = !0), this.os("posthog.setGroupPropertiesForFlags") && (null == (i = this.featureFlags) || i.setGroupPropertiesForFlags(t, e))
        }
        resetGroupPropertiesForFlags(t) {
            var e;
            null == (e = this.featureFlags) || e.resetGroupPropertiesForFlags(t)
        }
        reset(t) {
            var e, i, r, s, n, o, a, l, u;
            if (oi.info("reset"), !this.__loaded) return oi.uninitializedWarning("posthog.reset");
            var h, d = this.get_property(di),
                v = this.get_property(Ei);
            if (this.consent.reset(), null == (e = this.persistence) || e.clear(), null == (i = this.sessionPersistence) || i.clear(), q(v) || null == (h = this.persistence) || h.register({
                    [Ei]: v
                }), null == (r = this.surveys) || r.reset(), null == (s = this.es) || s.stop(), null == (n = this.featureFlags) || n.reset(), null == (o = this.conversations) || o.reset(), null == (a = this.logs) || a.reset(), null == (l = this.persistence) || l.set_property(Ki, hr), null == (u = this.sessionManager) || u.resetSessionId(), this.qn = null, this.config.cookieless_mode === ur) this.register_once({
                distinct_id: rr,
                $device_id: null
            }, "");
            else {
                var c = this.config.get_device_id(Ar());
                this.register_once({
                    distinct_id: c,
                    $device_id: t ? c : d
                }, "")
            }
            this.register({
                $last_posthog_reset: (new Date).toISOString()
            }, 1), delete this.config.identity_distinct_id, delete this.config.identity_hash, this.reloadFeatureFlags()
        }
        setIdentity(t, e) {
            var i;
            this.config.identity_distinct_id = t, this.config.identity_hash = e, this.alias(t), null == (i = this.conversations) || i.hs()
        }
        clearIdentity() {
            var t;
            delete this.config.identity_distinct_id, delete this.config.identity_hash, null == (t = this.conversations) || t.cs()
        }
        get_distinct_id() {
            return this.get_property("distinct_id")
        }
        getGroups() {
            return this.get_property("$groups") || {}
        }
        get_session_id() {
            var t, e;
            return null !== (t = null == (e = this.sessionManager) ? void 0 : e.checkAndGetSessionAndWindowId(!0).sessionId) && void 0 !== t ? t : ""
        }
        get_session_replay_url(t) {
            if (!this.sessionManager) return "";
            var {
                sessionId: e,
                sessionStartTimestamp: i
            } = this.sessionManager.checkAndGetSessionAndWindowId(!0), r = this.requestRouter.endpointFor("ui", "/project/" + this.config.token + "/replay/" + e);
            if (null != t && t.withTimestamp && i) {
                var s, n = null !== (s = t.timestampLookBack) && void 0 !== s ? s : 10;
                if (!i) return r;
                r += "?t=" + Math.max(Math.floor(((new Date).getTime() - i) / 1e3) - n, 0)
            }
            return r
        }
        alias(t, e) {
            return t === this.get_property(hi) ? (oi.critical("Attempting to create alias for existing People user - aborting."), -2) : this.os("posthog.alias") ? (q(e) && (e = this.get_distinct_id()), t !== e ? (this.ls(vi, t), this.capture("$create_alias", {
                alias: t,
                distinct_id: e
            })) : (oi.warn("alias matches current distinct_id - skipping api call."), this.identify(t), -1)) : void 0
        }
        set_config(t) {
            var e = p({}, this.config);
            if (B(t)) {
                var i, r, s, n, o, a, l, u, h, d, c;
                wr(this.config, ra(t));
                var f = this.Un();
                null == (i = this.persistence) || i.update_config(this.config, e, f), this.sessionPersistence = "sessionStorage" === this.config.persistence || "memory" === this.config.persistence ? this.persistence : new pn(p({}, this.config, {
                    persistence: "sessionStorage"
                }), f, !1);
                var g = this.jn(this.config.debug);
                X(g) && (this.config.debug = g), X(this.config.debug) && (this.config.debug ? (v.DEBUG = !0, Ur.N() && Ur.A("ph_debug", !0), oi.info("set_config", {
                    config: t,
                    oldConfig: e,
                    newConfig: p({}, this.config)
                })) : (v.DEBUG = !1, Ur.N() && Ur.q("ph_debug"))), null == (r = this.exceptionObserver) || r.onConfigChange(), null == (s = this.exceptions) || s.onConfigChange(), null == (n = this.sessionRecording) || n.startIfEnabledOrStop(), null == (o = this.tracingHeaders) || o.startIfEnabledOrStop(), null == (a = this.autocapture) || a.startIfEnabled(), null == (l = this.heatmaps) || l.startIfEnabled(), null == (u = this.exceptionObserver) || u.startIfEnabledOrStop(), null == (h = this.deadClicksAutocapture) || h.startIfEnabledOrStop(), null == (d = this.surveys) || d.loadIfEnabled(), this.ds(), null == (c = this.externalIntegrations) || c.startIfEnabledOrStop()
            }
        }
        _overrideSDKInfo(t, e) {
            v.LIB_NAME = t, v.LIB_VERSION = e
        }
        startSessionRecording(t) {
            var e, i, r, s, n, o = !0 === t,
                a = {
                    sampling: o || !(null == t || !t.sampling),
                    linked_flag: o || !(null == t || !t.linked_flag),
                    url_trigger: o || !(null == t || !t.url_trigger),
                    event_trigger: o || !(null == t || !t.event_trigger)
                };
            Object.values(a).some(Boolean) && (null == (e = this.sessionManager) || e.checkAndGetSessionAndWindowId(), a.sampling && (null == (i = this.sessionRecording) || i.overrideSampling()), a.linked_flag && (null == (r = this.sessionRecording) || r.overrideLinkedFlag()), a.url_trigger && (null == (s = this.sessionRecording) || s.overrideTrigger("url")), a.event_trigger && (null == (n = this.sessionRecording) || n.overrideTrigger("event")));
            this.set_config({
                disable_session_recording: !1
            })
        }
        stopSessionRecording() {
            this.set_config({
                disable_session_recording: !0
            })
        }
        sessionRecordingStarted() {
            var t;
            return !(null == (t = this.sessionRecording) || !t.started)
        }
        captureException(t, e) {
            if (this.exceptions) {
                var i = new Error("PostHog syntheticException"),
                    r = this.exceptions.buildProperties(t, {
                        handled: !0,
                        syntheticException: i
                    });
                return this.exceptions.sendExceptionEvent(p({}, r, e))
            }
        }
        addExceptionStep(t, e) {
            var i;
            null == (i = this.exceptions) || i.addExceptionStep(t, e)
        }
        captureLog(t) {
            var e;
            null == (e = this.logs) || e.captureLog(t)
        }
        get logger() {
            var t, e;
            return null !== (t = null == (e = this.logs) ? void 0 : e.logger) && void 0 !== t ? t : na.vs
        }
        startExceptionAutocapture(t) {
            this.set_config({
                capture_exceptions: null == t || t
            })
        }
        stopExceptionAutocapture() {
            this.set_config({
                capture_exceptions: !1
            })
        }
        loadToolbar(t) {
            var e, i;
            return null !== (e = null == (i = this.toolbar) ? void 0 : i.loadToolbar(t)) && void 0 !== e && e
        }
        get_property(t) {
            var e;
            return null == (e = this.persistence) ? void 0 : e.props[t]
        }
        getSessionProperty(t) {
            var e;
            return null == (e = this.sessionPersistence) ? void 0 : e.props[t]
        }
        toString() {
            var t, e = null !== (t = this.config.name) && void 0 !== t ? t : Zo;
            return e !== Zo && (e = Zo + "." + e), e
        }
        _isIdentified() {
            var t, e;
            return (null == (t = this.persistence) ? void 0 : t.get_property(Ki)) === dr || (null == (e = this.sessionPersistence) ? void 0 : e.get_property(Ki)) === dr
        }
        ss() {
            var t, e;
            return !("never" === this.config.person_profiles || this.config.person_profiles === vr && !this._isIdentified() && H(this.getGroups()) && (null == (t = this.persistence) || null == (t = t.props) || !t[vi]) && (null == (e = this.persistence) || null == (e = e.props) || !e[er]))
        }
        ts() {
            return !0 === this.config.capture_pageleave || "if_capture_pageview" === this.config.capture_pageleave && (!0 === this.config.capture_pageview || "history_change" === this.config.capture_pageview)
        }
        createPersonProfile() {
            this.ss() || this.os("posthog.createPersonProfile") && this.setPersonProperties({}, {})
        }
        setInternalOrTestUser() {
            this.os("posthog.setInternalOrTestUser") && this.setPersonProperties({
                $internal_or_test_user: !0
            })
        }
        os(t) {
            return "never" === this.config.person_profiles ? (oi.error(t + ' was called, but process_person is set to "never". This call will be ignored.'), !1) : (this.ls(er, !0), !0)
        }
        Un() {
            if ("always" === this.config.cookieless_mode) return !0;
            var t = this.consent.isOptedOut();
            return this.config.disable_persistence || t && !(!this.config.opt_out_persistence_by_default && this.config.cookieless_mode !== lr)
        }
        ds() {
            var t, e, i, r, s = this.Un();
            return (null == (t = this.persistence) ? void 0 : t.ti) !== s && (null == (i = this.persistence) || i.set_disabled(s)), (null == (e = this.sessionPersistence) ? void 0 : e.ti) !== s && (null == (r = this.sessionPersistence) || r.set_disabled(s)), s
        }
        opt_in_capturing(t) {
            var e;
            if (this.config.cookieless_mode !== ur) {
                if (this.Ln()) {
                    var i, r, s, n, o;
                    this.reset(!0), null == (i = this.sessionManager) || i.destroy(), null == (r = this.pageViewManager) || r.destroy(), this.sessionManager = new Po(this), this.pageViewManager = new Us(this), this.persistence && (this.sessionPropsManager = new So(this, this.sessionManager, this.persistence));
                    var a, l = null !== (s = null == (n = this.config.__extensionClasses) ? void 0 : n.sessionRecording) && void 0 !== s ? s : null == (o = na.__defaultExtensionClasses) ? void 0 : o.sessionRecording;
                    l && (this.sessionRecording = this.Rn(this.sessionRecording, new l(this)), this.Kn && (null == (a = this.sessionRecording) || null == a.onRemoteConfig || a.onRemoteConfig(this.Kn)))
                }
                var u, h;
                this.consent.optInOut(!0), this.ds(), this.Yn(), null == (e = this.sessionRecording) || e.startIfEnabledOrStop(), this.config.cookieless_mode == lr && (null == (u = this.surveys) || u.loadIfEnabled()), (q(null == t ? void 0 : t.captureEventName) || null != t && t.captureEventName) && this.capture(null !== (h = null == t ? void 0 : t.captureEventName) && void 0 !== h ? h : "$opt_in", null == t ? void 0 : t.captureProperties, {
                    send_instantly: !0
                }), this.config.capture_pageview && this.Xn()
            } else oi.warn(Ko)
        }
        opt_out_capturing() {
            var t, e, i;
            this.config.cookieless_mode !== ur ? (this.config.cookieless_mode === lr && this.consent.isOptedIn() && this.reset(!0), this.consent.optInOut(!1), this.ds(), this.config.cookieless_mode === lr && (this.register({
                distinct_id: rr,
                $device_id: null
            }), null == (t = this.sessionRecording) || t.stopRecording(), this.sessionRecording = void 0, null == (e = this.sessionManager) || e.destroy(), null == (i = this.pageViewManager) || i.destroy(), this.sessionManager = void 0, this.sessionPropsManager = void 0, this.config.capture_pageview && this.Xn(), this.Yn())) : oi.warn(Ko)
        }
        has_opted_in_capturing() {
            return this.consent.isOptedIn()
        }
        has_opted_out_capturing() {
            return this.consent.isOptedOut()
        }
        get_explicit_consent_status() {
            var t = this.consent.consent;
            return 1 === t ? "granted" : 0 === t ? "denied" : "pending"
        }
        is_capturing() {
            return this.config.cookieless_mode === ur || (this.config.cookieless_mode === lr ? this.consent.isRejected() || this.consent.isOptedIn() : !this.has_opted_out_capturing())
        }
        clear_opt_in_out_capturing() {
            this.consent.reset(), this.ds()
        }
        _is_bot() {
            return i ? To(i, this.config.custom_blocked_useragents) : void 0
        }
        Xn() {
            r && ("visible" === r.visibilityState ? this.Nn || (this.Nn = !0, this.capture(pr, {
                title: r.title
            }, {
                send_instantly: !0
            }), this.Dn && (r.removeEventListener(cr, this.Dn), this.Dn = null)) : this.Dn || (this.Dn = this.Xn.bind(this), Tr(r, cr, this.Dn)))
        }
        debug(e) {
            !1 === e ? (null == t || t.console.log("You've disabled debug mode."), this.set_config({
                debug: !1
            })) : (null == t || t.console.log("You're now in debug mode. All calls to PostHog will be logged in your console.\nYou can disable this with `posthog.debug(false)`."), this.set_config({
                debug: !0
            }))
        }
        Ii() {
            var t, e, i, r, s, n, o = this.Bn || {};
            return "advanced_disable_flags" in o ? !!o.advanced_disable_flags : !1 !== this.config.advanced_disable_flags ? !!this.config.advanced_disable_flags : !0 === this.config.advanced_disable_decide ? (oi.warn("Config field 'advanced_disable_decide' is deprecated. Please use 'advanced_disable_flags' instead. The old field will be removed in a future major version."), !0) : (i = "advanced_disable_decide", !1, r = oi, s = (e = "advanced_disable_flags") in (t = o) && !J(t[e]), n = i in t && !J(t[i]), s ? t[e] : !!n && (r && r.warn("Config field '" + i + "' is deprecated. Please use '" + e + "' instead. The old field will be removed in a future major version."), t[i]))
        }
        mr(t) {
            var e;
            if (J(this.config.before_send)) return t;
            var i = Object.keys(null !== (e = t.properties) && void 0 !== e ? e : {}).filter(tt),
                r = N(this.config.before_send) ? this.config.before_send : [this.config.before_send],
                s = t;
            for (var n of r) {
                if (s = n(s), J(s)) {
                    var o = "Event '" + t.event + "' was rejected in beforeSend function";
                    return Z(t.event) ? oi.warn(o + ". This can cause unexpected behavior.") : oi.info(o), null
                }
                s.properties && !H(s.properties) || oi.warn("Event '" + t.event + "' has no properties after beforeSend function, this is likely an error.")
            }
            for (var a of i)
                if (s.properties && J(s.properties[a])) return oi.warn("Event '" + t.event + "' had its '" + a + "' property removed in a beforeSend function. This property is required for ingestion, so the event will be dropped."), null;
            return s
        }
        getPageViewId() {
            var t;
            return null == (t = this.pageViewManager.Hr) ? void 0 : t.pageViewId
        }
        captureTraceFeedback(t, e) {
            this.capture("$ai_feedback", {
                $ai_trace_id: String(t),
                $ai_feedback_text: e
            })
        }
        captureTraceMetric(t, e, i) {
            this.capture("$ai_metric", {
                $ai_trace_id: String(t),
                $ai_metric_name: e,
                $ai_metric_value: String(i)
            })
        }
        jn(t) {
            var e = X(t) && !t,
                i = Ur.N() && "true" === Ur.P("ph_debug");
            return !e && (!!i || t)
        }
    }
    na.__defaultExtensionClasses = {}, na.vs = {
            trace: Go = () => {},
            debug: Go,
            info: Go,
            warn: Go,
            error: Go,
            fatal: Go
        },
        function(t, e) {
            for (var i = 0; e.length > i; i++) t.prototype[e[i]] = Sr(t.prototype[e[i]])
        }(na, ["identify"]);
    class oa {
        constructor(t) {
            this.disabled = !1 === t;
            var e = B(t) ? t : {};
            this.thresholdPx = e.threshold_px || 30, this.timeoutMs = e.timeout_ms || 1e3, this.clickCount = e.click_count || 3, this.clicks = []
        }
        isRageClick(t, e, i) {
            if (this.disabled) return !1;
            var r = this.clicks[this.clicks.length - 1];
            if (r && Math.abs(t - r.x) + Math.abs(e - r.y) < this.thresholdPx && this.timeoutMs > i - r.timestamp) {
                if (this.clicks.push({
                        x: t,
                        y: e,
                        timestamp: i
                    }), this.clicks.length === this.clickCount) return !0
            } else this.clicks = [{
                x: t,
                y: e,
                timestamp: i
            }];
            return !1
        }
    }
    var aa = "$copy_autocapture",
        la = ai("[AutoCapture]");

    function ua(t, e) {
        return e.length > t ? e.slice(0, t) + "..." : e
    }

    function ha(t) {
        if (t.previousElementSibling) return t.previousElementSibling;
        var e = t;
        do {
            e = e.previousSibling
        } while (e && !Qr(e));
        return e
    }

    function da(e, i) {
        var r, s, {
            e: n,
            maskAllElementAttributes: o,
            maskAllText: a,
            elementAttributeIgnoreList: l,
            elementsChainAsString: u
        } = i;
        if (!Qr(e)) return {
            props: {}
        };
        for (var h = [e], d = e; d.parentNode && !Zr(d, "body");)
            if (es(d.parentNode)) h.push(d.parentNode.host), d = d.parentNode.host;
            else {
                if (!Qr(d.parentNode)) break;
                h.push(d.parentNode), d = d.parentNode
            }
        var v, c, f = [],
            g = {},
            _ = !1,
            m = !1;
        if (br(h, (t => {
                var e = bs(t);
                if (Zr(t, "a")) {
                    var i = t.getAttribute("href");
                    _ = e && !!i && Ts(i) && i
                }
                O(ss(t), "ph-no-capture") && (m = !0), f.push(function(t, e, i, r) {
                    var s = t.tagName.toLowerCase(),
                        n = {
                            tag_name: s
                        };
                    ls.indexOf(s) > -1 && !i && (n.$el_text = "a" === s.toLowerCase() || "button" === s.toLowerCase() ? ua(1024, Is(t)) : ua(1024, os(t)));
                    var o = ss(t);
                    o.length > 0 && (n.classes = o.filter((function(t) {
                        return "" !== t
                    }))), br(t.attributes, (function(i) {
                        var s;
                        if ((!ws(t) || -1 !== ["name", "id", "class", "aria-label"].indexOf(i.name)) && (null == r || !r.includes(i.name)) && !e && Ts(i.value) && (!G(s = i.name) || "_ngcontent" !== s.substring(0, 10) && "_nghost" !== s.substring(0, 7))) {
                            var o = i.value;
                            "class" === i.name && (o = is(o).join(" ")), n["attr__" + i.name] = ua(1024, o)
                        }
                    }));
                    for (var a = 1, l = 1, u = t; u = ha(u);) a++, u.tagName === t.tagName && l++;
                    return n.nth_child = a, n.nth_of_type = l, n
                }(t, o, a, l));
                var r = function(t) {
                    if (!bs(t)) return {};
                    var e = {};
                    return br(t.attributes, (function(t) {
                        if (t.name && 0 === t.name.indexOf("data-ph-capture-attribute")) {
                            var i = t.name.replace("data-ph-capture-attribute-", ""),
                                r = t.value;
                            i && r && Ts(r) && (e[i] = r)
                        }
                    })), e
                }(t);
                wr(g, r)
            })), m) return {
            props: {},
            explicitNoCapture: m
        };
        if (a || (f[0].$el_text = Zr(e, "a") || Zr(e, "button") ? Is(e) : os(e)), _) {
            var y, b;
            f[0].attr__href = _;
            var w = null == (y = Vs(_)) ? void 0 : y.host,
                x = null == t || null == (b = t.location) ? void 0 : b.host;
            w && x && w !== x && (v = _)
        }
        return {
            props: wr({
                $event_type: n.type,
                $ce_version: 1
            }, u ? {} : {
                $elements: f
            }, {
                $elements_chain: (c = f, function(t) {
                    return t.map((t => {
                        var e, i, r = "";
                        if (t.tag_name && (r += t.tag_name), t.attr_class)
                            for (var s of (t.attr_class.sort(), t.attr_class)) r += "." + s.replace(/"/g, "");
                        var n = p({}, t.text ? {
                                text: t.text
                            } : {}, {
                                "nth-child": null !== (e = t.nth_child) && void 0 !== e ? e : 0,
                                "nth-of-type": null !== (i = t.nth_of_type) && void 0 !== i ? i : 0
                            }, t.href ? {
                                href: t.href
                            } : {}, t.attr_id ? {
                                attr_id: t.attr_id
                            } : {}, t.attributes),
                            o = {};
                        return xr(n).sort(((t, e) => {
                            var [i] = t, [r] = e;
                            return i.localeCompare(r)
                        })).forEach((t => {
                            var [e, i] = t;
                            return o[Cs(e.toString())] = Cs(i.toString())
                        })), (r += ":") + xr(o).map((t => {
                            var [e, i] = t;
                            return e + '="' + i + '"'
                        })).join("")
                    })).join(";")
                }(function(t) {
                    return t.map((t => {
                        var e, i, r = {
                            text: null == (e = t.$el_text) ? void 0 : e.slice(0, 400),
                            tag_name: t.tag_name,
                            href: null == (i = t.attr__href) ? void 0 : i.slice(0, 2048),
                            attr_class: Fs(t),
                            attr_id: t.attr__id,
                            nth_child: t.nth_child,
                            nth_of_type: t.nth_of_type,
                            attributes: {}
                        };
                        return xr(t).filter((t => {
                            var [e] = t;
                            return 0 === e.indexOf("attr__")
                        })).forEach((t => {
                            var [e, i] = t;
                            return r.attributes[e] = i
                        })), r
                    }))
                }(c)))
            }, null != (r = f[0]) && r.$el_text ? {
                $el_text: null == (s = f[0]) ? void 0 : s.$el_text
            } : {}, v && "click" === n.type ? {
                $external_click_url: v
            } : {}, g)
        }
    }
    var va = ai("[ExceptionAutocapture]"),
        ca = ai("[TracingHeaders]"),
        fa = ai("[Web Vitals]"),
        pa = 9e5,
        ga = "disabled",
        _a = "lazy_loading",
        ma = "awaiting_config",
        ya = "missing_config";
    ai("[SessionRecording]"), ai("[SessionRecording]");
    var ba = "[SessionRecording]",
        wa = ai(ba),
        xa = ai("[Heatmaps]");

    function Ea(t) {
        return B(t) && "clientX" in t && "clientY" in t && K(t.clientX) && K(t.clientY)
    }
    var Sa = ai("[Product Tours]"),
        ka = t => {
            var e;
            return !t.config.disable_product_tours && !(null == (e = t.persistence) || !e.get_property(wi))
        },
        $a = ["$set_once", "$set"],
        Pa = ai("[SiteApps]"),
        Ta = "Error while initializing PostHog app with config id ";

    function Ia(t, e, i) {
        if (J(t)) return !1;
        switch (i) {
            case "exact":
                return t === e;
            case "contains":
                var r = e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/_/g, ".").replace(/%/g, ".*");
                return new RegExp(r, "i").test(t);
            case "regex":
                try {
                    return new RegExp(e).test(t)
                } catch (t) {
                    return !1
                }
            default:
                return !1
        }
    }
    class Ra {
        constructor(t) {
            this.fs = new ko, this.ps = (t, e) => this.gs(t, e) && this.ys(t, e) && this.bs(t, e) && this._s(t, e), this.gs = (t, e) => null == e || !e.event || (null == t ? void 0 : t.event) === (null == e ? void 0 : e.event), this._instance = t, this.ws = new Set, this.xs = new Set
        }
        init() {
            var t, e;
            q(null == (t = this._instance) ? void 0 : t._addCaptureHook) || (null == (e = this._instance) || e._addCaptureHook(((t, e) => {
                this.on(t, e)
            })))
        }
        register(t) {
            var e, i;
            if (!q(null == (e = this._instance) ? void 0 : e._addCaptureHook) && (t.forEach((t => {
                    var e, i;
                    null == (e = this.xs) || e.add(t), null == (i = t.steps) || i.forEach((t => {
                        var e;
                        null == (e = this.ws) || e.add((null == t ? void 0 : t.event) || "")
                    }))
                })), null != (i = this._instance) && i.autocapture)) {
                var r, s = new Set;
                t.forEach((t => {
                    var e;
                    null == (e = t.steps) || e.forEach((t => {
                        null != t && t.selector && s.add(null == t ? void 0 : t.selector)
                    }))
                })), null == (r = this._instance) || r.autocapture.setElementSelectors(s)
            }
        }
        on(t, e) {
            var i;
            null != e && 0 != t.length && (this.ws.has(t) || this.ws.has(null == e ? void 0 : e.event)) && this.xs && (null == (i = this.xs) ? void 0 : i.size) > 0 && this.xs.forEach((t => {
                this.ks(e, t) && this.fs.emit("actionCaptured", t.name)
            }))
        }
        Ss(t) {
            this.onAction("actionCaptured", (e => t(e)))
        }
        ks(t, e) {
            if (null == (null == e ? void 0 : e.steps)) return !1;
            for (var i of e.steps)
                if (this.ps(t, i)) return !0;
            return !1
        }
        onAction(t, e) {
            return this.fs.on(t, e)
        }
        ys(t, e) {
            if (null != e && e.url) {
                var i, r = null == t || null == (i = t.properties) ? void 0 : i.$current_url;
                if (!r || "string" != typeof r) return !1;
                if (!Ia(r, e.url, e.url_matching || "contains")) return !1
            }
            return !0
        }
        bs(t, e) {
            return !!this.Cs(t, e) && !!this.Is(t, e) && !!this.Ts(t, e)
        }
        Cs(t, e) {
            var i;
            if (null == e || !e.href) return !0;
            var r = this.Es(t);
            if (r.length > 0) return r.some((t => Ia(t.href, e.href, e.href_matching || "exact")));
            var s, n = (null == t || null == (i = t.properties) ? void 0 : i.$elements_chain) || "";
            return !!n && Ia((s = n.match(/(?::|")href="(.*?)"/)) ? s[1] : "", e.href, e.href_matching || "exact")
        }
        Is(t, e) {
            var i;
            if (null == e || !e.text) return !0;
            var r = this.Es(t);
            if (r.length > 0) return r.some((t => Ia(t.text, e.text, e.text_matching || "exact") || Ia(t.$el_text, e.text, e.text_matching || "exact")));
            var s, n, o, a = (null == t || null == (i = t.properties) ? void 0 : i.$elements_chain) || "";
            return !!a && (s = function(t) {
                for (var e, i = [], r = /(?::|")text="(.*?)"/g; !J(e = r.exec(t));) i.includes(e[1]) || i.push(e[1]);
                return i
            }(a), n = e.text, o = e.text_matching || "exact", s.some((t => Ia(t, n, o))))
        }
        Ts(t, e) {
            var i, r;
            if (null == e || !e.selector) return !0;
            var s = null == t || null == (i = t.properties) ? void 0 : i.$element_selectors;
            if (null != s && s.includes(e.selector)) return !0;
            var n = (null == t || null == (r = t.properties) ? void 0 : r.$elements_chain) || "";
            if (e.selector_regex && n) try {
                return new RegExp(e.selector_regex).test(n)
            } catch (t) {
                return !1
            }
            return !1
        }
        Es(t) {
            var e;
            return null == (null == t || null == (e = t.properties) ? void 0 : e.$elements) ? [] : null == t ? void 0 : t.properties.$elements
        }
        _s(t, e) {
            return null == e || !e.properties || 0 === e.properties.length || Mo(e.properties.reduce(((t, e) => {
                var i = N(e.value) ? e.value.map(String) : null != e.value ? [String(e.value)] : [];
                return t[e.key] = {
                    values: i,
                    operator: e.operator || "exact"
                }, t
            }), {}), null == t ? void 0 : t.properties)
        }
    }
    class Ca {
        constructor(t) {
            this.Ms = [], this._instance = t, this.Ps = new Map, this.Rs = new Map, this.Os = new Map
        }
        Ls(t, e) {
            return !!t && Mo(t.propertyFilters, null == e ? void 0 : e.properties)
        }
        As(t, e) {
            var i = new Map;
            return t.forEach((t => {
                var r;
                null == (r = t.conditions) || null == (r = r[e]) || null == (r = r.values) || r.forEach((e => {
                    if (null != e && e.name) {
                        var r = i.get(e.name) || [];
                        r.push(t.id), i.set(e.name, r)
                    }
                }))
            })), i
        }
        Fs(t, e, i) {
            var r = (i === gn ? this.Ps : this.Rs).get(t),
                s = [];
            return this.Ns((t => {
                s = t.filter((t => null == r ? void 0 : r.includes(t.id)))
            })), s.filter((r => {
                var s, n = null == (s = r.conditions) || null == (s = s[i]) || null == (s = s.values) ? void 0 : s.find((e => e.name === t));
                return this.Ls(n, e)
            }))
        }
        register(t) {
            var e;
            q(null == (e = this._instance) ? void 0 : e._addCaptureHook) || (this.Ds(t), this.$s(t))
        }
        $s(t) {
            var e = t.filter((t => {
                var e, i;
                return (null == (e = t.conditions) ? void 0 : e.actions) && (null == (i = t.conditions) || null == (i = i.actions) || null == (i = i.values) ? void 0 : i.length) > 0
            }));
            0 !== e.length && (null == this.qs && (this.qs = new Ra(this._instance), this.qs.init(), this.qs.Ss((t => {
                this.onAction(t)
            }))), e.forEach((t => {
                var e, i, r, s, n;
                t.conditions && null != (e = t.conditions) && e.actions && null != (i = t.conditions) && null != (i = i.actions) && i.values && (null == (r = t.conditions) || null == (r = r.actions) || null == (r = r.values) ? void 0 : r.length) > 0 && (null == (s = this.qs) || s.register(t.conditions.actions.values), null == (n = t.conditions) || null == (n = n.actions) || null == (n = n.values) || n.forEach((e => {
                    if (e && e.name) {
                        var i = this.Os.get(e.name);
                        i && i.push(t.id), this.Os.set(e.name, i || [t.id])
                    }
                })))
            })))
        }
        Ds(t) {
            var e, i = t.filter((t => {
                    var e, i;
                    return (null == (e = t.conditions) ? void 0 : e.events) && (null == (i = t.conditions) || null == (i = i.events) || null == (i = i.values) ? void 0 : i.length) > 0
                })),
                r = t.filter((t => {
                    var e, i;
                    return (null == (e = t.conditions) ? void 0 : e.cancelEvents) && (null == (i = t.conditions) || null == (i = i.cancelEvents) || null == (i = i.values) ? void 0 : i.length) > 0
                }));
            0 === i.length && 0 === r.length || (null == (e = this._instance) || e._addCaptureHook(((t, e) => {
                this.onEvent(t, e)
            })), this.Ps = this.As(t, gn), this.Rs = this.As(t, _n))
        }
        onEvent(t, e) {
            var i, r, s = this.ce(),
                n = (null == e || null == (i = e.properties) ? void 0 : i.$survey_id) || (null == e || null == (r = e.properties) ? void 0 : r.$product_tour_id);
            if (n && this.getActivatedIds().includes(n)) {
                var o = this.js(t, n);
                if ("consume" === o) return s.info("event consumed activated item, removing it", {
                    event: t,
                    itemId: n
                }), void this.Bs([n]);
                if ("persist" === o) return s.info("shown item promoted to persisted activation", {
                    event: t,
                    itemId: n
                }), void this.Hs(n)
            }
            if (this.Rs.has(t)) {
                var a = this.Fs(t, e, _n);
                a.length > 0 && (s.info("cancel event matched, cancelling items", {
                    event: t,
                    itemsToCancel: a.map((t => t.id))
                }), this.Bs(a.map((t => t.id))), a.forEach((t => this.Us(t.id))))
            }
            if (this.Ps.has(t)) {
                s.info("event name matched", {
                    event: t,
                    eventPayload: e,
                    items: this.Ps.get(t)
                });
                var l = this.Fs(t, e, gn);
                this.zs(l.map((t => t.id)))
            }
        }
        onAction(t) {
            this.Os.has(t) && this.zs(this.Os.get(t) || [])
        }
        zs(t) {
            0 !== t.length && (this.Ms = [...new Set([...this.Ms, ...t])], this.ce().info("updating activated items", {
                activatedItems: this.getActivatedIds()
            }))
        }
        Hs(t) {
            this.Ms = this.Ms.filter((e => e !== t));
            var e = this.Vs();
            e.includes(t) || this.Ws([...e, t])
        }
        Bs(t) {
            var e = new Set(t);
            this.Ms = this.Ms.filter((t => !e.has(t)));
            var i = this.Vs(),
                r = i.filter((t => !e.has(t)));
            r.length !== i.length && this.Ws(r)
        }
        Vs() {
            var t, e = this.Gs();
            return (null == (t = this._instance) || null == (t = t.persistence) ? void 0 : t.props[e]) || []
        }
        getActivatedIds() {
            return [...new Set([...this.Vs(), ...this.Ms])].filter((t => !this.Zs(t)))
        }
        reset() {
            this.Ms = [], this.Vs().length > 0 && this.Ws([])
        }
        getEventToItemsMap() {
            return this.Ps
        }
        Qs() {
            return this.qs
        }
    }
    class Fa extends Ca {
        constructor(t) {
            super(t)
        }
        Gs() {
            return Hi
        }
        Js() {
            return mn
        }
        Ns(t) {
            var e;
            null == (e = this._instance) || e.getSurveys(t)
        }
        Us(t) {
            var e;
            null == (e = this._instance) || e.cancelPendingSurvey(t)
        }
        ce() {
            return jo
        }
        Ws(t) {
            var e;
            null == (e = this._instance) || null == (e = e.persistence) || e.register({
                [Hi]: t
            })
        }
        Zs() {
            return !1
        }
        js(t, e) {
            var i;
            this.Ns((t => {
                i = t.find((t => t.id === e))
            }));
            var r = !i || function(t) {
                var e, i, r, s = (null !== (e = null == (i = t.conditions) || null == (i = i.events) || null == (i = i.values) ? void 0 : i.length) && void 0 !== e ? e : 0) > 0;
                return "always" === t.schedule || !(null == (r = t.conditions) || null == (r = r.events) || !r.repeatedActivation || !s)
            }(i);
            return r ? t === mn ? "consume" : "ignore" : t === mn ? "persist" : t === yn || t === bn ? "consume" : "ignore"
        }
        getSurveys() {
            return this.getActivatedIds()
        }
        getEventToSurveys() {
            return this.getEventToItemsMap()
        }
    }
    var Ma = "SDK is not enabled or survey functionality is not yet loaded",
        Oa = "Disabled. Not loading surveys.",
        Aa = null != t && t.location ? Ks(t.location.hash, "__posthog") || Ks(location.hash, "state") : null,
        Da = "_postHogToolbarParams",
        La = ai("[Toolbar]"),
        ja = ai("[FeatureFlags]"),
        za = ai("[FeatureFlags]", {
            debugEnabled: !0
        }),
        Na = "\" failed. Feature flags didn't load in time.",
        Ua = t => {
            for (var e = {}, i = 0; t.length > i; i++) e[t[i]] = !0;
            return e
        },
        Ba = t => {
            var e = {};
            for (var [i, r] of xr(t || {})) r && (e[i] = r);
            return e
        },
        Ha = ai("[Error tracking]"),
        qa = "Refusing to render web experiment since the viewer is a likely bot",
        Ga = {
            icontains: (e, i) => !!t && i.href.toLowerCase().indexOf(e.toLowerCase()) > -1,
            not_icontains: (e, i) => !!t && -1 === i.href.toLowerCase().indexOf(e.toLowerCase()),
            regex: (e, i) => !!t && Io(i.href, e),
            not_regex: (e, i) => !!t && !Io(i.href, e),
            exact: (t, e) => e.href === t,
            is_not: (t, e) => e.href !== t
        };
    class Va {
        get Dt() {
            return this._instance.config
        }
        constructor(t) {
            var e = this;
            this.getWebExperimentsAndEvaluateDisplayLogic = function(t) {
                void 0 === t && (t = !1), e.getWebExperiments((t => {
                    Va.Ks("retrieved web experiments from the server"), e.Ys = new Map, t.forEach((t => {
                        if (t.feature_flag_key) {
                            var i;
                            e.Ys && (Va.Ks("setting flag key ", t.feature_flag_key, " to web experiment ", t), null == (i = e.Ys) || i.set(t.feature_flag_key, t));
                            var r = e._instance.getFeatureFlag(t.feature_flag_key);
                            G(r) && t.variants[r] && e.Xs(t.name, r, t.variants[r].transforms)
                        } else if (t.variants)
                            for (var s in t.variants) {
                                var n = t.variants[s];
                                Va.eo(n) && e.Xs(t.name, s, n.transforms)
                            }
                    }))
                }), t)
            }, this._instance = t, this._instance.onFeatureFlags((t => {
                this.onFeatureFlags(t)
            }))
        }
        initialize() {}
        onFeatureFlags(t) {
            if (this._is_bot()) Va.Ks(qa);
            else if (!this.Dt.disable_web_experiments) {
                if (J(this.Ys)) return this.Ys = new Map, this.loadIfEnabled(), void this.previewWebExperiment();
                Va.Ks("applying feature flags", t), t.forEach((t => {
                    var e;
                    if (this.Ys && null != (e = this.Ys) && e.has(t)) {
                        var i, r = this._instance.getFeatureFlag(t),
                            s = null == (i = this.Ys) ? void 0 : i.get(t);
                        r && null != s && s.variants[r] && this.Xs(s.name, r, s.variants[r].transforms)
                    }
                }))
            }
        }
        previewWebExperiment() {
            var t = Va.getWindowLocation();
            if (null != t && t.search) {
                var e = Ws(null == t ? void 0 : t.search, "__experiment_id"),
                    i = Ws(null == t ? void 0 : t.search, "__experiment_variant");
                e && i && (Va.Ks("previewing web experiments " + e + " && " + i), this.getWebExperiments((t => {
                    this.ro(parseInt(e), i, t)
                }), !1, !0))
            }
        }
        loadIfEnabled() {
            this.Dt.disable_web_experiments || this.getWebExperimentsAndEvaluateDisplayLogic()
        }
        getWebExperiments(t, e, i) {
            if (this.Dt.disable_web_experiments && !i) return t([]);
            var r = this._instance.get_property("$web_experiments");
            if (r && !e) return t(r);
            this._instance._send_request({
                url: this._instance.requestRouter.endpointFor("api", "/api/web_experiments/?token=" + this.Dt.token),
                method: "GET",
                callback: e => t(200 === e.statusCode && e.json && e.json.experiments || [])
            })
        }
        ro(t, e, i) {
            var r = i.filter((e => e.id === t));
            r && r.length > 0 && (Va.Ks("Previewing web experiment [" + r[0].name + "] with variant [" + e + "]"), this.Xs(r[0].name, e, r[0].variants[e].transforms))
        }
        static eo(t) {
            return !J(t.conditions) && Va.io(t) && Va.no(t)
        }
        static io(t) {
            var e;
            if (J(t.conditions) || J(null == (e = t.conditions) ? void 0 : e.url)) return !0;
            var i, r, s, n = Va.getWindowLocation();
            return !!n && (null == (i = t.conditions) || !i.url || Ga[null !== (r = null == (s = t.conditions) ? void 0 : s.urlMatchType) && void 0 !== r ? r : "icontains"](t.conditions.url, n))
        }
        static getWindowLocation() {
            return null == t ? void 0 : t.location
        }
        static no(t) {
            var e;
            if (J(t.conditions) || J(null == (e = t.conditions) ? void 0 : e.utm)) return !0;
            var i = en();
            if (i.utm_source) {
                var r, s, n, o, a, l, u, h, d = null == (r = t.conditions) || null == (r = r.utm) || !r.utm_campaign || (null == (s = t.conditions) || null == (s = s.utm) ? void 0 : s.utm_campaign) == i.utm_campaign,
                    v = null == (n = t.conditions) || null == (n = n.utm) || !n.utm_source || (null == (o = t.conditions) || null == (o = o.utm) ? void 0 : o.utm_source) == i.utm_source,
                    c = null == (a = t.conditions) || null == (a = a.utm) || !a.utm_medium || (null == (l = t.conditions) || null == (l = l.utm) ? void 0 : l.utm_medium) == i.utm_medium,
                    f = null == (u = t.conditions) || null == (u = u.utm) || !u.utm_term || (null == (h = t.conditions) || null == (h = h.utm) ? void 0 : h.utm_term) == i.utm_term;
                return d && c && f && v
            }
            return !1
        }
        static Ks(t) {
            for (var e = arguments.length, i = new Array(e > 1 ? e - 1 : 0), r = 1; e > r; r++) i[r - 1] = arguments[r];
            oi.info("[WebExperiments] " + t, i)
        }
        Xs(t, e, i) {
            this._is_bot() ? Va.Ks(qa) : "control" !== e ? i.forEach((i => {
                if (i.selector) {
                    var r;
                    Va.Ks("applying transform of variant " + e + " for experiment " + t + " ", i);
                    var s = null == (r = document) ? void 0 : r.querySelectorAll(i.selector);
                    null == s || s.forEach((t => {
                        var e = t;
                        i.html && (e.innerHTML = i.html), i.css && e.setAttribute("style", i.css)
                    }))
                }
            })) : Va.Ks("Control variants leave the page unmodified.")
        }
        _is_bot() {
            return i && this._instance ? To(i, this.Dt.custom_blocked_useragents) : void 0
        }
    }
    var Wa = ai("[Conversations]"),
        Ja = "Conversations not available yet.",
        Ka = {
            featureFlags: class {
                constructor(t) {
                    this.so = !1, this.oo = !1, this.ao = !1, this.lo = !1, this.uo = !1, this.ho = !1, this.co = !1, this.do = !1, this._instance = t, this.featureFlagEventHandlers = []
                }
                get Dt() {
                    return this._instance.config
                }
                get Ki() {
                    return this._instance.persistence
                }
                vo(t) {
                    return this._instance.get_property(t)
                }
                fo() {
                    var t, e;
                    return null !== (t = null == (e = this.Ki) ? void 0 : e.ii(this.Dt.feature_flag_cache_ttl_ms)) && void 0 !== t && t
                }
                po() {
                    return !!this.fo() && (this.do || this.ao || (this.do = !0, ja.warn("Feature flag cache is stale, triggering refresh..."), this.reloadFeatureFlags()), !0)
                }
                mo() {
                    var t, e = null !== (t = this.Dt.evaluation_contexts) && void 0 !== t ? t : this.Dt.evaluation_environments;
                    return !this.Dt.evaluation_environments || this.Dt.evaluation_contexts || this.co || (ja.warn("evaluation_environments is deprecated. Use evaluation_contexts instead. evaluation_environments will be removed in a future version."), this.co = !0), null != e && e.length ? e.filter((t => {
                        var e = t && "string" == typeof t && t.trim().length > 0;
                        return e || ja.error("Invalid evaluation context found:", t, "Expected non-empty string"), e
                    })) : []
                }
                yo() {
                    return this.mo().length > 0
                }
                bo() {
                    var t = this.Dt.flag_keys;
                    if (!q(t)) {
                        if (N(t)) return t.filter((t => {
                            var e = t && "string" == typeof t && t.trim().length > 0;
                            return e || ja.error("Invalid flag key found:", t, "Expected non-empty string"), e
                        }));
                        ja.error("Invalid flag_keys found:", t, "Expected array of non-empty strings")
                    }
                }
                initialize() {
                    var t, e, {
                            config: i
                        } = this._instance,
                        r = null !== (t = null == (e = i.bootstrap) ? void 0 : e.featureFlags) && void 0 !== t ? t : {};
                    if (Object.keys(r).length) {
                        var s, n, o = null !== (s = null == (n = i.bootstrap) ? void 0 : n.featureFlagPayloads) && void 0 !== s ? s : {},
                            a = Object.keys(r).filter((t => !!r[t])).reduce(((t, e) => (t[e] = r[e] || !1, t)), {}),
                            l = Object.keys(o).filter((t => a[t])).reduce(((t, e) => (o[e] && (t[e] = o[e]), t)), {});
                        this.receivedFeatureFlags({
                            featureFlags: a,
                            featureFlagPayloads: l
                        })
                    }
                }
                updateFlags(t, e, i) {
                    var r, s, n = null != i && i.merge && null !== (r = this.vo(Ci)) && void 0 !== r ? r : {},
                        o = null != i && i.merge && null !== (s = this.vo(Ai)) && void 0 !== s ? s : {},
                        a = p({}, n, t),
                        l = p({}, o, e),
                        u = {};
                    for (var [h, d] of Object.entries(a)) u[h] = {
                        key: h,
                        enabled: m(d),
                        variant: y(d),
                        reason: void 0,
                        metadata: q(null == l ? void 0 : l[h]) ? void 0 : {
                            id: 0,
                            version: void 0,
                            description: void 0,
                            payload: l[h]
                        }
                    };
                    this.receivedFeatureFlags({
                        flags: u
                    })
                }
                get hasLoadedFlags() {
                    return this.oo
                }
                getFlags() {
                    return Object.keys(this.getFlagVariants())
                }
                getFlagsWithDetails() {
                    var t = this.vo(Oi),
                        e = this.vo(Li),
                        i = this.vo(ji);
                    if (!i && !e) return t || {};
                    var r = wr({}, t || {}),
                        s = [...new Set([...Object.keys(i || {}), ...Object.keys(e || {})])];
                    for (var n of s) {
                        var o, a, l = r[n],
                            u = null == e ? void 0 : e[n],
                            h = q(u) ? null !== (o = null == l ? void 0 : l.enabled) && void 0 !== o && o : !!u,
                            d = q(u) ? l.variant : "string" == typeof u ? u : void 0,
                            v = null == i ? void 0 : i[n],
                            c = p({}, l, {
                                enabled: h,
                                variant: h ? null != d ? d : null == l ? void 0 : l.variant : void 0
                            });
                        h !== (null == l ? void 0 : l.enabled) && (c.original_enabled = null == l ? void 0 : l.enabled), d !== (null == l ? void 0 : l.variant) && (c.original_variant = null == l ? void 0 : l.variant), v && (c.metadata = p({}, null == l ? void 0 : l.metadata, {
                            payload: v,
                            original_payload: null == l || null == (a = l.metadata) ? void 0 : a.payload
                        })), r[n] = c
                    }
                    return this.so || (ja.warn(" Overriding feature flag details!", {
                        flagDetails: t,
                        overriddenPayloads: i,
                        finalDetails: r
                    }), this.so = !0), r
                }
                getFlagVariants() {
                    var t = this.vo(Ci),
                        e = this.vo(Li);
                    if (!e) return t || {};
                    for (var i = wr({}, t), r = Object.keys(e), s = 0; r.length > s; s++) i[r[s]] = e[r[s]];
                    return this.so || (ja.warn(" Overriding feature flags!", {
                        enabledFlags: t,
                        overriddenFlags: e,
                        finalFlags: i
                    }), this.so = !0), i
                }
                getFlagPayloads() {
                    var t = this.vo(Ai),
                        e = this.vo(ji);
                    if (!e) return t || {};
                    for (var i = wr({}, t || {}), r = Object.keys(e), s = 0; r.length > s; s++) i[r[s]] = e[r[s]];
                    return this.so || (ja.warn(" Overriding feature flag payloads!", {
                        flagPayloads: t,
                        overriddenPayloads: e,
                        finalPayloads: i
                    }), this.so = !0), i
                }
                reloadFeatureFlags() {
                    this.lo || this.Dt.advanced_disable_feature_flags || this._o || (this._instance.Fn.emit("featureFlagsReloading", !0), this._o = setTimeout((() => {
                        this.wo()
                    }), 5))
                }
                xo() {
                    clearTimeout(this._o), this._o = void 0
                }
                ensureFlagsLoaded() {
                    this.oo || this.ao || this._o || this.reloadFeatureFlags()
                }
                setAnonymousDistinctId(t) {
                    this.$anon_distinct_id = t
                }
                setReloadingPaused(t) {
                    this.lo = t
                }
                wo(t) {
                    var e;
                    if (this.xo(), !this._instance.Ii())
                        if (this.ao) this.uo = !0;
                        else {
                            var i = this.Dt.token,
                                r = this.vo(di),
                                s = {
                                    token: i,
                                    distinct_id: this._instance.get_distinct_id(),
                                    groups: this._instance.getGroups(),
                                    $anon_distinct_id: this.$anon_distinct_id,
                                    person_properties: p({}, (null == (e = this.Ki) ? void 0 : e.get_initial_props()) || {}, this.vo(zi) || {}),
                                    group_properties: this.vo(Ni),
                                    timezone: hn()
                                };
                            W(r) || q(r) || (s.$device_id = r), (null != t && t.disableFlags || this.Dt.advanced_disable_feature_flags) && (s.disable_flags = !0), this.yo() && (s.evaluation_contexts = this.mo());
                            var n = this.bo();
                            q(n) || (s.flag_keys = n);
                            var o = !!this.Dt.advanced_only_evaluate_survey_feature_flags,
                                a = this._instance.requestRouter.endpointFor("flags", "/flags/?v=2" + (this.Dt.advanced_only_evaluate_survey_feature_flags ? "&only_evaluate_survey_feature_flags=true" : ""));
                            this.ao = !0, this._instance._send_request({
                                method: "POST",
                                url: a,
                                data: s,
                                skipIPParam: !0,
                                compression: this.Dt.disable_compression ? void 0 : Pn,
                                timeout: this.Dt.feature_flag_request_timeout_ms,
                                callback: t => {
                                    var e, i, r, n = !0;
                                    if (200 === t.statusCode && (this.uo || (this.$anon_distinct_id = void 0), n = !1), this.ao = !1, !s.disable_flags || this.uo) {
                                        this.ho = !n;
                                        var a = [];
                                        t.error ? t.error instanceof Error ? a.push("AbortError" === t.error.name ? "timeout" : "connection_error") : a.push("unknown_error") : 200 !== t.statusCode && a.push("api_error_" + t.statusCode), null != (e = t.json) && e.errorsWhileComputingFlags && a.push("errors_while_computing_flags");
                                        var l, u = !(null == (i = t.json) || null == (i = i.quotaLimited) || !i.includes("feature_flags"));
                                        if (u && a.push("quota_limited"), null == (r = this.Ki) || r.register({
                                                [Wi]: a
                                            }), u) ja.warn("You have hit your feature flags quota limit, and will not be able to load feature flags until the quota is reset.  Please visit https://posthog.com/docs/billing/limits-alerts to learn more.");
                                        else s.disable_flags || this.receivedFeatureFlags(null !== (l = t.json) && void 0 !== l ? l : {}, n, {
                                            partialResponse: o
                                        }), this.uo && (this.uo = !1, this.wo())
                                    }
                                }
                            })
                        }
                }
                getFeatureFlag(t, e) {
                    var i;
                    if (void 0 === e && (e = {}), !e.fresh || this.ho)
                        if (this.oo || this.getFlags() && this.getFlags().length > 0) {
                            if (!this.po()) {
                                var r = this.getFeatureFlagResult(t, e);
                                return null !== (i = null == r ? void 0 : r.variant) && void 0 !== i ? i : null == r ? void 0 : r.enabled
                            }
                        } else ja.warn('getFeatureFlag for key "' + t + Na)
                }
                getFeatureFlagDetails(t) {
                    return this.getFlagsWithDetails()[t]
                }
                getFeatureFlagPayload(t) {
                    var e = this.getFeatureFlagResult(t, {
                        send_event: !1
                    });
                    return null == e ? void 0 : e.payload
                }
                getFeatureFlagResult(t, e) {
                    if (void 0 === e && (e = {}), !e.fresh || this.ho)
                        if (this.oo || this.getFlags() && this.getFlags().length > 0) {
                            if (!this.po()) {
                                var i = this.getFlagVariants(),
                                    r = t in i,
                                    s = i[t],
                                    n = this.getFlagPayloads()[t],
                                    o = String(s),
                                    a = this.vo(Di) || void 0,
                                    l = this.vo(Ji) || void 0,
                                    u = this.vo(Gi) || {};
                                if (this.Dt.advanced_feature_flags_dedup_per_session) {
                                    var h, d = this._instance.get_session_id(),
                                        v = this.vo(Vi);
                                    d && d !== v && (u = {}, null == (h = this.Ki) || h.register({
                                        [Gi]: u,
                                        [Vi]: d
                                    }))
                                }
                                if ((e.send_event || !("send_event" in e)) && (!(t in u) || !u[t].includes(o))) {
                                    var c, f, p, g, m, y, b, w, x, E;
                                    N(u[t]) ? u[t].push(o) : u[t] = [o], null == (c = this.Ki) || c.register({
                                        [Gi]: u
                                    });
                                    var S = this.getFeatureFlagDetails(t),
                                        k = [...null !== (f = this.vo(Wi)) && void 0 !== f ? f : []];
                                    q(s) && k.push("flag_missing");
                                    var P = {
                                        $feature_flag: t,
                                        $feature_flag_response: s,
                                        $feature_flag_payload: n || null,
                                        $feature_flag_request_id: a,
                                        $feature_flag_evaluated_at: l,
                                        $feature_flag_bootstrapped_response: (null == (p = this.Dt.bootstrap) || null == (p = p.featureFlags) ? void 0 : p[t]) || null,
                                        $feature_flag_bootstrapped_payload: (null == (g = this.Dt.bootstrap) || null == (g = g.featureFlagPayloads) ? void 0 : g[t]) || null,
                                        $used_bootstrap_value: !this.ho
                                    };
                                    q(null == S || null == (m = S.metadata) ? void 0 : m.version) || (P.$feature_flag_version = S.metadata.version);
                                    var T, I = null !== (y = null == S || null == (b = S.reason) ? void 0 : b.description) && void 0 !== y ? y : null == S || null == (w = S.reason) ? void 0 : w.code;
                                    I && (P.$feature_flag_reason = I), null != S && null != (x = S.metadata) && x.id && (P.$feature_flag_id = S.metadata.id), q(null == S ? void 0 : S.original_variant) && q(null == S ? void 0 : S.original_enabled) || (P.$feature_flag_original_response = q(S.original_variant) ? S.original_enabled : S.original_variant), null != S && null != (E = S.metadata) && E.original_payload && (P.$feature_flag_original_payload = null == S || null == (T = S.metadata) ? void 0 : T.original_payload), k.length && (P.$feature_flag_error = k.join(",")), this._instance.capture("$feature_flag_called", P)
                                }
                                if (r) return {
                                    key: t,
                                    enabled: !!s,
                                    variant: "string" == typeof s ? s : void 0,
                                    payload: _(n)
                                }
                            }
                        } else ja.warn('getFeatureFlagResult for key "' + t + Na)
                }
                getRemoteConfigPayload(t, e) {
                    var i = this.Dt.token,
                        r = {
                            distinct_id: this._instance.get_distinct_id(),
                            token: i
                        };
                    this.yo() && (r.evaluation_contexts = this.mo());
                    var s = this.bo();
                    q(s) || (r.flag_keys = s), this._instance._send_request({
                        method: "POST",
                        url: this._instance.requestRouter.endpointFor("flags", "/flags/?v=2"),
                        data: r,
                        skipIPParam: !0,
                        compression: this.Dt.disable_compression ? void 0 : Pn,
                        timeout: this.Dt.feature_flag_request_timeout_ms,
                        callback(i) {
                            var r, s = null == (r = i.json) ? void 0 : r.featureFlagPayloads;
                            e((null == s ? void 0 : s[t]) || void 0)
                        }
                    })
                }
                isFeatureEnabled(t, e) {
                    if (void 0 === e && (e = {}), !e.fresh || this.ho) {
                        if (this.oo || this.getFlags() && this.getFlags().length > 0) {
                            var i = this.getFeatureFlag(t, e);
                            return q(i) ? void 0 : !!i
                        }
                        ja.warn('isFeatureEnabled for key "' + t + Na)
                    }
                }
                addFeatureFlagsHandler(t) {
                    this.featureFlagEventHandlers.push(t)
                }
                removeFeatureFlagsHandler(t) {
                    this.featureFlagEventHandlers = this.featureFlagEventHandlers.filter((e => e !== t))
                }
                receivedFeatureFlags(t, e, i) {
                    if (this.Ki) {
                        this.oo = !0;
                        var r = this.getFlagVariants(),
                            s = this.getFlagPayloads(),
                            n = this.getFlagsWithDetails();
                        ! function(t, e, i, r, s, n) {
                            void 0 === i && (i = {}), void 0 === r && (r = {}), void 0 === s && (s = {});
                            var o = (t => {
                                    var e = t.flags;
                                    return e ? (t.featureFlags = Object.fromEntries(Object.keys(e).map((t => {
                                        var i;
                                        return [t, null !== (i = e[t].variant) && void 0 !== i ? i : e[t].enabled]
                                    }))), t.featureFlagPayloads = Object.fromEntries(Object.keys(e).filter((t => e[t].enabled)).filter((t => {
                                        var i;
                                        return null == (i = e[t].metadata) ? void 0 : i.payload
                                    })).map((t => {
                                        var i;
                                        return [t, null == (i = e[t].metadata) ? void 0 : i.payload]
                                    })))) : ja.warn("Using an older version of the feature flags endpoint. Please upgrade your PostHog server to the latest version"), t
                                })(t),
                                a = o.flags,
                                l = o.featureFlags,
                                u = o.featureFlagPayloads;
                            if (l) {
                                var h = t.requestId,
                                    d = t.evaluatedAt;
                                if (N(l)) {
                                    ja.warn("v1 of the feature flags endpoint is deprecated. Please use the latest version.");
                                    var v = {};
                                    if (l)
                                        for (var c = 0; l.length > c; c++) v[l[c]] = !0;
                                    e && e.register({
                                        [Fi]: l,
                                        [Ci]: v
                                    })
                                } else {
                                    var f = l,
                                        g = u,
                                        _ = a;
                                    if (null != n && n.partialResponse) f = p({}, i, f), g = p({}, r, g), _ = p({}, s, _);
                                    else if (t.errorsWhileComputingFlags)
                                        if (a) {
                                            var m = new Set(Object.keys(a).filter((t => {
                                                var e;
                                                return !(null != (e = a[t]) && e.failed)
                                            })));
                                            f = p({}, i, Object.fromEntries(Object.entries(f).filter((t => {
                                                var [e] = t;
                                                return m.has(e)
                                            })))), g = p({}, r, Object.fromEntries(Object.entries(g || {}).filter((t => {
                                                var [e] = t;
                                                return m.has(e)
                                            })))), _ = p({}, s, Object.fromEntries(Object.entries(_ || {}).filter((t => {
                                                var [e] = t;
                                                return m.has(e)
                                            }))))
                                        } else f = p({}, i, f), g = p({}, r, g), _ = p({}, s, _);
                                    e && e.register(p({
                                        [Fi]: Object.keys(Ba(f)),
                                        [Ci]: f || {},
                                        [Ai]: g || {},
                                        [Oi]: _ || {}
                                    }, h ? {
                                        [Di]: h
                                    } : {}, d ? {
                                        [Ji]: d
                                    } : {}))
                                }
                            }
                        }(t, this.Ki, r, s, n, i), e || (this.do = !1), this.ko(e)
                    }
                }
                override(t, e) {
                    void 0 === e && (e = !1), ja.warn("override is deprecated. Please use overrideFeatureFlags instead."), this.overrideFeatureFlags({
                        flags: t,
                        suppressWarning: e
                    })
                }
                overrideFeatureFlags(t) {
                    if (!this._instance.__loaded || !this.Ki) return ja.uninitializedWarning("posthog.featureFlags.overrideFeatureFlags");
                    if (!1 === t) return this.Ki.unregister(Li), this.Ki.unregister(ji), this.ko(), za.info("All overrides cleared");
                    if (N(t)) {
                        var e = Ua(t);
                        return this.Ki.register({
                            [Li]: e
                        }), this.ko(), za.info("Flag overrides set", {
                            flags: t
                        })
                    }
                    if (t && "object" == typeof t && ("flags" in t || "payloads" in t)) {
                        var i, r = t;
                        if (this.so = Boolean(null !== (i = r.suppressWarning) && void 0 !== i && i), "flags" in r)
                            if (!1 === r.flags) this.Ki.unregister(Li), za.info("Flag overrides cleared");
                            else if (r.flags) {
                            if (N(r.flags)) {
                                var s = Ua(r.flags);
                                this.Ki.register({
                                    [Li]: s
                                })
                            } else this.Ki.register({
                                [Li]: r.flags
                            });
                            za.info("Flag overrides set", {
                                flags: r.flags
                            })
                        }
                        return "payloads" in r && (!1 === r.payloads ? (this.Ki.unregister(ji), za.info("Payload overrides cleared")) : r.payloads && (this.Ki.register({
                            [ji]: r.payloads
                        }), za.info("Payload overrides set", {
                            payloads: r.payloads
                        }))), void this.ko()
                    }
                    if (t && "object" == typeof t) return this.Ki.register({
                        [Li]: t
                    }), this.ko(), za.info("Flag overrides set", {
                        flags: t
                    });
                    ja.warn("Invalid overrideOptions provided to overrideFeatureFlags", {
                        overrideOptions: t
                    })
                }
                onFeatureFlags(t) {
                    if (this.addFeatureFlagsHandler(t), this.oo) {
                        var {
                            flags: e,
                            flagVariants: i
                        } = this.So();
                        t(e, i)
                    }
                    return () => this.removeFeatureFlagsHandler(t)
                }
                updateEarlyAccessFeatureEnrollment(t, e, i) {
                    var r, s = (this.vo(Mi) || []).find((e => e.flagKey === t)),
                        n = {
                            ["$feature_enrollment/" + t]: e
                        },
                        o = {
                            $feature_flag: t,
                            $feature_enrollment: e,
                            $set: n
                        };
                    s && (o.$early_access_feature_name = s.name), i && (o.$feature_enrollment_stage = i), this._instance.capture("$feature_enrollment_update", o), this.setPersonPropertiesForFlags(n, !1);
                    var a = p({}, this.getFlagVariants(), {
                        [t]: e
                    });
                    null == (r = this.Ki) || r.register({
                        [Fi]: Object.keys(Ba(a)),
                        [Ci]: a
                    }), this.ko()
                }
                getEarlyAccessFeatures(t, e, i) {
                    void 0 === e && (e = !1);
                    var r = this.vo(Mi),
                        s = i ? "&" + i.map((t => "stage=" + t)).join("&") : "";
                    if (r && !e) return t(r);
                    this._instance._send_request({
                        url: this._instance.requestRouter.endpointFor("api", "/api/early_access_features/?token=" + this.Dt.token + s),
                        method: "GET",
                        callback: e => {
                            var i, r;
                            if (e.json) {
                                var s = e.json.earlyAccessFeatures;
                                return null == (i = this.Ki) || i.unregister(Mi), null == (r = this.Ki) || r.register({
                                    [Mi]: s
                                }), t(s)
                            }
                        }
                    })
                }
                So() {
                    var t = this.getFlags(),
                        e = this.getFlagVariants();
                    return {
                        flags: t.filter((t => e[t])),
                        flagVariants: Object.keys(e).filter((t => e[t])).reduce(((t, i) => (t[i] = e[i], t)), {})
                    }
                }
                ko(t) {
                    var {
                        flags: e,
                        flagVariants: i
                    } = this.So();
                    this.featureFlagEventHandlers.forEach((r => r(e, i, {
                        errorsLoading: t
                    })))
                }
                setPersonPropertiesForFlags(t, e) {
                    void 0 === e && (e = !0);
                    var i = this.vo(zi) || {},
                        r = (null == t ? void 0 : t.$set) || (null != t && t.$set_once ? {} : t),
                        s = null == t ? void 0 : t.$set_once,
                        n = {};
                    if (s)
                        for (var o in s)({}).hasOwnProperty.call(s, o) && (o in i || (n[o] = s[o]));
                    this._instance.register({
                        [zi]: p({}, i, n, r)
                    }), e && this._instance.reloadFeatureFlags()
                }
                unsetPersonPropertiesForFlags(t, e) {
                    void 0 === e && (e = !0);
                    var i = p({}, this.vo(zi) || {});
                    t.forEach((t => {
                        delete i[t]
                    })), this._instance.register({
                        [zi]: i
                    }), e && this._instance.reloadFeatureFlags()
                }
                resetPersonPropertiesForFlags(t) {
                    void 0 === t && (t = !0), this._instance.unregister(zi), t && this._instance.reloadFeatureFlags()
                }
                setGroupPropertiesForFlags(t, e) {
                    void 0 === e && (e = !0);
                    var i = this.vo(Ni) || {};
                    0 !== Object.keys(i).length && Object.keys(i).forEach((e => {
                        i[e] = p({}, i[e], t[e]), delete t[e]
                    })), this._instance.register({
                        [Ni]: p({}, i, t)
                    }), e && this._instance.reloadFeatureFlags()
                }
                resetGroupPropertiesForFlags(t) {
                    if (t) {
                        var e = this.vo(Ni) || {};
                        this._instance.register({
                            [Ni]: p({}, e, {
                                [t]: {}
                            })
                        })
                    } else this._instance.unregister(Ni)
                }
                reset() {
                    this.oo = !1, this.ao = !1, this.lo = !1, this.uo = !1, this.ho = !1, this.$anon_distinct_id = void 0, this.xo(), this.so = !1
                }
            }
        },
        Ya = {
            sessionRecording: class {
                get Dt() {
                    return this._instance.config
                }
                get Ki() {
                    return this._instance.persistence
                }
                get started() {
                    var t;
                    return !(null == (t = this.Co) || !t.isStarted)
                }
                get status() {
                    var t, e;
                    return this.Io === ma || this.Io === ya ? this.Io : null !== (t = null == (e = this.Co) ? void 0 : e.status) && void 0 !== t ? t : this.Io
                }
                constructor(t) {
                    if (this._forceAllowLocalhostNetworkCapture = !1, this.Io = ga, this.To = void 0, this._instance = t, !this._instance.sessionManager) throw wa.error("started without valid sessionManager"), new Error(ba + " started without valid sessionManager. This is a bug.");
                    if (this.Dt.cookieless_mode === ur) throw new Error(ba + ' cannot be used with cookieless_mode="always"')
                }
                initialize() {
                    this.startIfEnabledOrStop()
                }
                get Eo() {
                    var e, i = !(null == (e = this._instance.get_property(Ei)) || !e.enabled),
                        r = !this.Dt.disable_session_recording,
                        s = this.Dt.disable_session_recording || this._instance.consent.isOptedOut();
                    return t && i && r && !s
                }
                startIfEnabledOrStop(t) {
                    var e;
                    if (!this.Eo || null == (e = this.Co) || !e.isStarted) {
                        var i = !q(Object.assign) && !q(Array.from);
                        this.Eo && i ? (this.Mo(t), wa.info("starting")) : (this.Io = ga, this.stopRecording())
                    }
                }
                Mo(t) {
                    var e, i, r;
                    this.Eo && (this.Io !== ma && this.Io !== ya && (this.Io = _a), null != h && null != (e = h.__PosthogExtensions__) && null != (e = e.rrweb) && e.record && null != (i = h.__PosthogExtensions__) && i.initSessionRecording ? this.Po(t) : null == (r = h.__PosthogExtensions__) || null == r.loadExternalDependency || r.loadExternalDependency(this._instance, this.Ro, (e => {
                        if (e) return wa.error("could not load recorder", e);
                        this.Po(t)
                    })))
                }
                stopRecording() {
                    var t, e;
                    null == (t = this.To) || t.call(this), this.To = void 0, null == (e = this.Co) || e.stop()
                }
                Oo() {
                    var t, e;
                    null == (t = this.To) || t.call(this), this.To = void 0, null == (e = this.Co) || e.discard()
                }
                Lo() {
                    var t, e;
                    null == (t = this.Ki) || t.unregister(Ri), null == (e = this.Ki) || e.unregister(Si)
                }
                Ao(t, e) {
                    if (J(t)) return null;
                    var i, r = K(t) ? t : parseFloat(t);
                    return "number" != typeof(i = r) || !Number.isFinite(i) || 0 > i || i > 1 ? (wa.warn(e + " must be between 0 and 1. Ignoring invalid value:", t), null) : r
                }
                Fo(t) {
                    if (this.Ki) {
                        var e, i, r = this.Ki,
                            s = () => {
                                var e, i = !1 === t.sessionRecording ? void 0 : t.sessionRecording,
                                    s = this.Ao(null == (e = this.Dt.session_recording) ? void 0 : e.sampleRate, "session_recording.sampleRate"),
                                    n = this.Ao(null == i ? void 0 : i.sampleRate, "remote config sampleRate"),
                                    o = null != s ? s : n;
                                J(o) && this.Lo();
                                var a = null == i ? void 0 : i.minimumDurationMilliseconds;
                                r.register({
                                    [Ei]: p({
                                        cache_timestamp: Date.now(),
                                        enabled: !!i
                                    }, i, {
                                        networkPayloadCapture: p({
                                            capturePerformance: t.capturePerformance
                                        }, null == i ? void 0 : i.networkPayloadCapture),
                                        canvasRecording: {
                                            enabled: null == i ? void 0 : i.recordCanvas,
                                            fps: null == i ? void 0 : i.canvasFps,
                                            quality: null == i ? void 0 : i.canvasQuality
                                        },
                                        sampleRate: o,
                                        minimumDurationMilliseconds: q(a) ? null : a,
                                        endpoint: null == i ? void 0 : i.endpoint,
                                        triggerMatchType: null == i ? void 0 : i.triggerMatchType,
                                        masking: null == i ? void 0 : i.masking,
                                        urlTriggers: null == i ? void 0 : i.urlTriggers,
                                        version: null == i ? void 0 : i.version,
                                        triggerGroups: null == i ? void 0 : i.triggerGroups
                                    })
                                })
                            };
                        s(), null == (e = this.To) || e.call(this), this.To = null == (i = this._instance.sessionManager) ? void 0 : i.onSessionId(s)
                    }
                }
                onRemoteConfig(t) {
                    return "sessionRecording" in t ? !1 === t.sessionRecording ? (this.Fo(t), void this.Oo()) : (this.Fo(t), void this.startIfEnabledOrStop()) : (this.Io === ma && (this.Io = ya, wa.warn("config refresh failed, recording will not start until page reload")), void this.startIfEnabledOrStop())
                }
                log(t, e) {
                    var i;
                    void 0 === e && (e = "log"), null != (i = this.Co) && i.log ? this.Co.log(t, e) : wa.warn("log called before recorder was ready")
                }
                get Ro() {
                    var t, e, i = null == (t = this._instance) || null == (t = t.persistence) ? void 0 : t.get_property(Ei);
                    return (null == i || null == (e = i.scriptConfig) ? void 0 : e.script) || "lazy-recorder"
                }
                No() {
                    var t, e, i = this._instance.get_property(Ei);
                    if (!i) return !1;
                    try {
                        e = "object" == typeof i ? i : JSON.parse(i)
                    } catch (t) {
                        return wa.warn("persisted remote config for session recording is invalid and will be ignored", t), !1
                    }
                    var r = null !== (t = e.cache_timestamp) && void 0 !== t ? t : Date.now();
                    return 36e5 >= Date.now() - r
                }
                Po(t) {
                    var e, i;
                    if (null == (e = h.__PosthogExtensions__) || !e.initSessionRecording) return wa.warn("Called on script loaded before session recording is available. This can be caused by adblockers."), void this._instance.register_for_session({
                        [or]: !0
                    });
                    if (this.Co || (this.Co = null == (i = h.__PosthogExtensions__) ? void 0 : i.initSessionRecording(this._instance), this.Co._forceAllowLocalhostNetworkCapture = this._forceAllowLocalhostNetworkCapture), !this.No()) {
                        if (this.Io === ya || this.Io === ma) return;
                        return this.Io = ma, wa.info("persisted remote config is stale, requesting fresh config before starting"), void new kn(this._instance).load()
                    }
                    this.Io = _a, this.Co.start(t)
                }
                onRRwebEmit(t) {
                    var e;
                    null == (e = this.Co) || null == e.onRRwebEmit || e.onRRwebEmit(t)
                }
                overrideLinkedFlag() {
                    var t, e;
                    this.Co || null == (e = this.Ki) || e.register({
                        [$i]: !0
                    }), null == (t = this.Co) || t.overrideLinkedFlag()
                }
                overrideSampling() {
                    var t, e;
                    this.Co || null == (e = this.Ki) || e.register({
                        [ki]: !0
                    }), null == (t = this.Co) || t.overrideSampling()
                }
                overrideTrigger(t) {
                    var e, i;
                    this.Co || null == (i = this.Ki) || i.register({
                        ["url" === t ? Pi : Ti]: !0
                    }), null == (e = this.Co) || e.overrideTrigger(t)
                }
                get sdkDebugProperties() {
                    var t;
                    return (null == (t = this.Co) ? void 0 : t.sdkDebugProperties) || {
                        $recording_status: this.status
                    }
                }
                tryAddCustomEvent(t, e) {
                    var i;
                    return !(null == (i = this.Co) || !i.tryAddCustomEvent(t, e))
                }
            }
        },
        Xa = {
            autocapture: class {
                constructor(t) {
                    this.Do = !1, this.$o = null, this.qo = !1, this.instance = t, this.rageclicks = new oa(t.config.rageclick), this.jo = null
                }
                initialize() {
                    this.startIfEnabled()
                }
                get Dt() {
                    var t, e, i = B(this.instance.config.autocapture) ? this.instance.config.autocapture : {};
                    return i.url_allowlist = null == (t = i.url_allowlist) ? void 0 : t.map((t => new RegExp(t))), i.url_ignorelist = null == (e = i.url_ignorelist) ? void 0 : e.map((t => new RegExp(t))), i
                }
                Bo() {
                    if (this.isBrowserSupported()) {
                        if (t && r) {
                            var e = e => {
                                e = e || (null == t ? void 0 : t.event);
                                try {
                                    this.Ho(e)
                                } catch (t) {
                                    la.error("Failed to capture event", t)
                                }
                            };
                            if (Tr(r, "submit", e, {
                                    capture: !0
                                }), Tr(r, "change", e, {
                                    capture: !0
                                }), Tr(r, "click", e, {
                                    capture: !0
                                }), this.Dt.capture_copied_text) {
                                var i = e => {
                                    e = e || (null == t ? void 0 : t.event);
                                    try {
                                        this.Ho(e, aa)
                                    } catch (t) {
                                        la.error("Failed to capture copy/cut event", t)
                                    }
                                };
                                Tr(r, "copy", i, {
                                    capture: !0
                                }), Tr(r, "cut", i, {
                                    capture: !0
                                })
                            }
                        }
                    } else la.info("Disabling Automatic Event Collection because this browser is not supported")
                }
                startIfEnabled() {
                    this.isEnabled && !this.Do && (this.Bo(), this.Do = !0)
                }
                onRemoteConfig(t) {
                    t.elementsChainAsString && (this.qo = t.elementsChainAsString), this.instance.persistence && this.instance.persistence.register({
                        [fi]: !!t.autocapture_opt_out
                    }), this.$o = !!t.autocapture_opt_out, this.startIfEnabled()
                }
                setElementSelectors(t) {
                    this.jo = t
                }
                getElementSelectors(t) {
                    var e, i = [];
                    return null == (e = this.jo) || e.forEach((e => {
                        var s = null == r ? void 0 : r.querySelectorAll(e);
                        null == s || s.forEach((r => {
                            t === r && i.push(e)
                        }))
                    })), i
                }
                get isEnabled() {
                    var t, e, i = null == (t = this.instance.persistence) ? void 0 : t.props[fi];
                    if (W(this.$o) && !X(i) && !this.instance.Ii()) return !1;
                    var r = null !== (e = this.$o) && void 0 !== e ? e : !!i;
                    return !!this.instance.config.autocapture && !r
                }
                Ho(e, i) {
                    if (void 0 === i && (i = "$autocapture"), this.isEnabled) {
                        var r, s = as(e);
                        ts(s) && (s = s.parentNode || null), "$autocapture" === i && "click" === e.type && e instanceof MouseEvent && this.instance.config.rageclick && null != (r = this.rageclicks) && r.isRageClick(e.clientX, e.clientY, e.timeStamp || (new Date).getTime()) && _s(s, this.instance.config.rageclick) && this.Ho(e, "$rageclick");
                        var n = i === aa;
                        if (s && function(e, i, r, s, n) {
                                var o, a, l, u, h, d;
                                if (void 0 === r && (r = void 0), !t || ms(e)) return !1;
                                if (null != (o = r) && o.url_allowlist && !rs(r.url_allowlist)) return !1;
                                if (null != (a = r) && a.url_ignorelist && rs(r.url_ignorelist)) return !1;
                                if (null != (l = r) && l.dom_event_allowlist) {
                                    var v = r.dom_event_allowlist;
                                    if (v && !v.some((t => i.type === t))) return !1
                                }
                                var {
                                    parentIsUsefulElement: c,
                                    targetElementList: f
                                } = ys(e, s);
                                if (! function(t, e) {
                                        var i = null == e ? void 0 : e.element_allowlist;
                                        if (q(i)) return !0;
                                        var r, s = function(t) {
                                            if (i.some((e => t.tagName.toLowerCase() === e))) return {
                                                v: !0
                                            }
                                        };
                                        for (var n of t)
                                            if (r = s(n)) return r.v;
                                        return !1
                                    }(f, r)) return !1;
                                if (!us(f, null == (u = r) ? void 0 : u.css_selector_allowlist)) return !1;
                                if (us(f, null !== (h = null == (d = r) ? void 0 : d.css_selector_ignorelist) && void 0 !== h ? h : ds)) return !1;
                                var p = t.getComputedStyle(e);
                                if (p && "pointer" === p.getPropertyValue("cursor") && "click" === i.type) return !0;
                                var g = e.tagName.toLowerCase();
                                switch (g) {
                                    case "html":
                                        return !1;
                                    case "form":
                                        return (n || ["submit"]).indexOf(i.type) >= 0;
                                    case "input":
                                    case "select":
                                    case "textarea":
                                        return (n || ["change", "click"]).indexOf(i.type) >= 0;
                                    default:
                                        return c ? (n || ["click"]).indexOf(i.type) >= 0 : (n || ["click"]).indexOf(i.type) >= 0 && (ls.indexOf(g) > -1 || "true" === e.getAttribute("contenteditable"))
                                }
                            }(s, e, this.Dt, n, n ? ["copy", "cut"] : void 0)) {
                            var {
                                props: o,
                                explicitNoCapture: a
                            } = da(s, {
                                e: e,
                                maskAllElementAttributes: this.instance.config.mask_all_element_attributes,
                                maskAllText: this.instance.config.mask_all_text,
                                elementAttributeIgnoreList: this.Dt.element_attribute_ignorelist,
                                elementsChainAsString: this.qo
                            });
                            if (a) return !1;
                            var l = this.getElementSelectors(s);
                            if (l && l.length > 0 && (o.$element_selectors = l), i === aa) {
                                var u, h = ns(null == t || null == (u = t.getSelection()) ? void 0 : u.toString()),
                                    d = e.type || "clipboard";
                                if (!h) return !1;
                                o.$selected_content = h, o.$copy_type = d
                            }
                            return this.instance.capture(i, o), !0
                        }
                    }
                }
                isBrowserSupported() {
                    return U(null == r ? void 0 : r.querySelectorAll)
                }
            },
            historyAutocapture: class {
                constructor(e) {
                    var i;
                    this._instance = e, this.Uo = (null == t || null == (i = t.location) ? void 0 : i.pathname) || ""
                }
                initialize() {
                    this.startIfEnabled()
                }
                get isEnabled() {
                    return "history_change" === this._instance.config.capture_pageview
                }
                startIfEnabled() {
                    this.isEnabled && (oi.info("History API monitoring enabled, starting..."), this.monitorHistoryChanges())
                }
                stop() {
                    this.zo && this.zo(), this.zo = void 0, oi.info("History API monitoring stopped")
                }
                monitorHistoryChanges() {
                    t && t.history && (this.Vo("pushState"), this.Vo("replaceState"), this.Wo())
                }
                Vo(e) {
                    var i;
                    if (t && (null == (i = t.history[e]) || !i.__posthog_wrapped__)) {
                        var r = this;
                        ! function(t, e, i) {
                            try {
                                if (!(e in t)) return () => {};
                                var r = t[e],
                                    s = i(r);
                                return U(s) && (s.prototype = s.prototype || {}, Object.defineProperties(s, {
                                    __posthog_wrapped__: {
                                        enumerable: !1,
                                        value: !0
                                    }
                                })), t[e] = s, () => {
                                    t[e] === s && (t[e] = r)
                                }
                            } catch (t) {
                                return () => {}
                            }
                        }(t.history, e, (t => function(i, s, n) {
                            t.call(this, i, s, n), r.Go(e)
                        }))
                    }
                }
                Go(e) {
                    try {
                        var i, r = null == t || null == (i = t.location) ? void 0 : i.pathname;
                        if (!r) return;
                        r !== this.Uo && this.isEnabled && this._instance.capture(pr, {
                            navigation_type: e
                        }), this.Uo = r
                    } catch (t) {
                        oi.error("Error capturing " + e + " pageview", t)
                    }
                }
                Wo() {
                    if (!this.zo) {
                        var e = () => {
                            this.Go("popstate")
                        };
                        Tr(t, "popstate", e), this.zo = () => {
                            t && t.removeEventListener("popstate", e)
                        }
                    }
                }
            },
            heatmaps: class {
                get Dt() {
                    return this.instance.config
                }
                constructor(t) {
                    var e;
                    this.Zo = !1, this.Do = !1, this.Qo = null, this.instance = t, this.Zo = !(null == (e = this.instance.persistence) || !e.props[pi]), this.rageclicks = new oa(t.config.rageclick)
                }
                initialize() {
                    this.startIfEnabled()
                }
                get flushIntervalMilliseconds() {
                    var t = 5e3;
                    return B(this.Dt.capture_heatmaps) && this.Dt.capture_heatmaps.flush_interval_milliseconds && (t = this.Dt.capture_heatmaps.flush_interval_milliseconds), t
                }
                get isEnabled() {
                    return J(this.Dt.capture_heatmaps) ? J(this.Dt.enable_heatmaps) ? this.Zo : this.Dt.enable_heatmaps : !1 !== this.Dt.capture_heatmaps
                }
                startIfEnabled() {
                    if (this.isEnabled) {
                        if (this.Do) return;
                        xa.info("starting..."), this.Jo(), this.Pt()
                    } else {
                        var t;
                        clearInterval(null !== (t = this.Qo) && void 0 !== t ? t : void 0), this.Ko(), this.getAndClearBuffer()
                    }
                }
                onRemoteConfig(t) {
                    if ("heatmaps" in t) {
                        var e = !!t.heatmaps;
                        this.instance.persistence && this.instance.persistence.register({
                            [pi]: e
                        }), this.Zo = e, this.startIfEnabled()
                    }
                }
                getAndClearBuffer() {
                    var t = this.R;
                    return this.R = void 0, t
                }
                Yo(t) {
                    this._t(t.originalEvent, "deadclick")
                }
                Pt() {
                    this.Qo && clearInterval(this.Qo), this.Qo = function(t) {
                        return "visible" === (null == t ? void 0 : t.visibilityState)
                    }(r) ? setInterval(this.ji.bind(this), this.flushIntervalMilliseconds) : null
                }
                Jo() {
                    t && r && (this.Xo = this.ji.bind(this), Tr(t, fr, this.Xo), this.ea = e => this._t(e || (null == t ? void 0 : t.event)), Tr(r, "click", this.ea, {
                        capture: !0
                    }), this.ta = e => this.ra(e || (null == t ? void 0 : t.event)), Tr(r, "mousemove", this.ta, {
                        capture: !0
                    }), this.ia = new Ds(this.instance, Os, this.Yo.bind(this)), this.ia.startIfEnabledOrStop(), this.na = this.Pt.bind(this), Tr(r, cr, this.na), this.Do = !0)
                }
                Ko() {
                    var e;
                    t && r && (this.Xo && t.removeEventListener(fr, this.Xo), this.ea && r.removeEventListener("click", this.ea, {
                        capture: !0
                    }), this.ta && r.removeEventListener("mousemove", this.ta, {
                        capture: !0
                    }), this.na && r.removeEventListener(cr, this.na), clearTimeout(this.sa), null == (e = this.ia) || e.stop(), this.Do = !1)
                }
                oa(e, i) {
                    var r = this.instance.scrollManager.scrollY(),
                        s = this.instance.scrollManager.scrollX(),
                        n = this.instance.scrollManager.scrollElement(),
                        o = function(e, i, r) {
                            for (var s = e; s && Qr(s) && !Zr(s, "body");) {
                                if (s === r) return !1;
                                if (O(i, null == t ? void 0 : t.getComputedStyle(s).position)) return !0;
                                s = hs(s)
                            }
                            return !1
                        }(as(e), ["fixed", "sticky"], n);
                    return {
                        x: e.clientX + (o ? 0 : s),
                        y: e.clientY + (o ? 0 : r),
                        target_fixed: o,
                        type: i
                    }
                }
                _t(t, e) {
                    var i;
                    if (void 0 === e && (e = "click"), !Xr(t.target) && Ea(t)) {
                        var r = this.oa(t, e);
                        null != (i = this.rageclicks) && i.isRageClick(t.clientX, t.clientY, (new Date).getTime()) && _s(as(t), this.instance.config.rageclick) && this.aa(p({}, r, {
                            type: "rageclick"
                        })), this.aa(r)
                    }
                }
                ra(t) {
                    !Xr(t.target) && Ea(t) && (clearTimeout(this.sa), this.sa = setTimeout((() => {
                        this.aa(this.oa(t, "mousemove"))
                    }), 500))
                }
                aa(e) {
                    if (t) {
                        var i = t.location.href,
                            r = this.Dt.custom_personal_data_properties,
                            s = this.Dt.mask_personal_data_properties ? [...Xs, ...r || []] : [],
                            n = Js(i, s, Zs);
                        this.R = this.R || {}, this.R[n] || (this.R[n] = []), this.R[n].push(e)
                    }
                }
                ji() {
                    this.R && !H(this.R) && this.instance.capture("$$heatmap", {
                        $heatmap_data: this.getAndClearBuffer()
                    })
                }
            },
            deadClicksAutocapture: Ds,
            webVitalsAutocapture: class {
                constructor(t) {
                    var e;
                    this.Zo = !1, this.Do = !1, this.R = {
                        url: void 0,
                        metrics: [],
                        firstMetricTimestamp: void 0
                    }, this.la = () => {
                        clearTimeout(this.ua), 0 !== this.R.metrics.length && (this._instance.capture("$web_vitals", this.R.metrics.reduce(((t, e) => p({}, t, {
                            ["$web_vitals_" + e.name + "_event"]: p({}, e),
                            ["$web_vitals_" + e.name + "_value"]: e.value
                        })), {})), this.R = {
                            url: void 0,
                            metrics: [],
                            firstMetricTimestamp: void 0
                        })
                    }, this.vt = t => {
                        var e;
                        this.R = this.R || {
                            url: void 0,
                            metrics: [],
                            firstMetricTimestamp: void 0
                        };
                        var i = this.ha();
                        if (!q(i))
                            if (J(null == t ? void 0 : t.name) || J(null == t ? void 0 : t.value)) fa.error("Invalid metric received", t);
                            else if (!this.ca || this.ca > t.value) {
                            this.R.url !== i && (this.la(), this.ua = setTimeout(this.la, this.flushToCaptureTimeoutMs)), q(this.R.url) && (this.R.url = i), this.R.firstMetricTimestamp = q(this.R.firstMetricTimestamp) ? Date.now() : this.R.firstMetricTimestamp, t.attribution && t.attribution.interactionTargetElement && (t.attribution.interactionTargetElement = void 0);
                            var r = null == (e = this._instance.sessionManager) ? void 0 : e.checkAndGetSessionAndWindowId(!0),
                                s = p({}, t, {
                                    $current_url: i,
                                    timestamp: Date.now()
                                });
                            q(r) || (s.$session_id = r.sessionId, s.$window_id = r.windowId), this.R.metrics.push(s), this.R.metrics.length === this.allowedMetrics.length && this.la()
                        } else fa.error("Ignoring metric with value >= " + this.ca, t)
                    }, this.da = () => {
                        if (!this.Do) {
                            var t, e, i, r, s = h.__PosthogExtensions__;
                            q(s) || q(s.postHogWebVitalsCallbacks) || ({
                                onLCP: t,
                                onCLS: e,
                                onFCP: i,
                                onINP: r
                            } = s.postHogWebVitalsCallbacks), t && e && i && r ? (this.allowedMetrics.indexOf("LCP") > -1 && t(this.vt.bind(this)), this.allowedMetrics.indexOf("CLS") > -1 && e(this.vt.bind(this)), this.allowedMetrics.indexOf("FCP") > -1 && i(this.vt.bind(this)), this.allowedMetrics.indexOf("INP") > -1 && r(this.vt.bind(this)), this.Do = !0) : fa.error("web vitals callbacks not loaded - not starting")
                        }
                    }, this._instance = t, this.Zo = !(null == (e = this._instance.persistence) || !e.props[yi]), this.startIfEnabled()
                }
                get va() {
                    return this._instance.config.capture_performance
                }
                get allowedMetrics() {
                    var t, e, i = B(this.va) ? null == (t = this.va) ? void 0 : t.web_vitals_allowed_metrics : void 0;
                    return J(i) ? (null == (e = this._instance.persistence) ? void 0 : e.props[xi]) || ["CLS", "FCP", "INP", "LCP"] : i
                }
                get flushToCaptureTimeoutMs() {
                    return (B(this.va) ? this.va.web_vitals_delayed_flush_ms : void 0) || 5e3
                }
                get useAttribution() {
                    var t = B(this.va) ? this.va.web_vitals_attribution : void 0;
                    return null != t && t
                }
                get ca() {
                    var t = B(this.va) && K(this.va.__web_vitals_max_value) ? this.va.__web_vitals_max_value : pa;
                    return t > 0 && 6e4 >= t ? pa : t
                }
                get isEnabled() {
                    var t = null == s ? void 0 : s.protocol;
                    if ("http:" !== t && "https:" !== t) return fa.info("Web Vitals are disabled on non-http/https protocols"), !1;
                    var e = B(this.va) ? this.va.web_vitals : X(this.va) ? this.va : void 0;
                    return X(e) ? e : this.Zo
                }
                startIfEnabled() {
                    this.isEnabled && !this.Do && (fa.info("enabled, starting..."), this.qr(this.da))
                }
                onRemoteConfig(t) {
                    if ("capturePerformance" in t) {
                        var e = B(t.capturePerformance) && !!t.capturePerformance.web_vitals,
                            i = B(t.capturePerformance) ? t.capturePerformance.web_vitals_allowed_metrics : void 0;
                        this._instance.persistence && (this._instance.persistence.register({
                            [yi]: e
                        }), this._instance.persistence.register({
                            [xi]: i
                        })), this.Zo = e, this.startIfEnabled()
                    }
                }
                qr(t) {
                    var e, i;
                    null != (e = h.__PosthogExtensions__) && e.postHogWebVitalsCallbacks ? t() : null == (i = h.__PosthogExtensions__) || null == i.loadExternalDependency || i.loadExternalDependency(this._instance, this.useAttribution ? "web-vitals-with-attribution" : "web-vitals", (e => {
                        e ? fa.error("failed to load script", e) : t()
                    }))
                }
                ha() {
                    var e = t ? t.location.href : void 0;
                    if (e) {
                        var i = this._instance.config.custom_personal_data_properties,
                            r = this._instance.config.mask_personal_data_properties ? [...Xs, ...i || []] : [];
                        return Js(e, r, Zs)
                    }
                    fa.error("Could not determine current URL")
                }
            }
        },
        Qa = {
            exceptionObserver: class {
                constructor(e) {
                    var i, r, s;
                    this.da = () => {
                        var e;
                        if (t && this.isEnabled && null != (e = h.__PosthogExtensions__) && e.errorWrappingFunctions) {
                            var i = h.__PosthogExtensions__.errorWrappingFunctions.wrapOnError,
                                r = h.__PosthogExtensions__.errorWrappingFunctions.wrapUnhandledRejection,
                                s = h.__PosthogExtensions__.errorWrappingFunctions.wrapConsoleError;
                            try {
                                !this.fa && this.Dt.capture_unhandled_errors && (this.fa = i(this.captureException.bind(this))), !this.pa && this.Dt.capture_unhandled_rejections && (this.pa = r(this.captureException.bind(this))), !this.ga && this.Dt.capture_console_errors && (this.ga = s(this.captureException.bind(this)))
                            } catch (t) {
                                va.error("failed to start", t), this.ma()
                            }
                        }
                    }, this._instance = e, this.ya = !(null == (i = this._instance.persistence) || !i.props[gi]), this.ba = new lt({
                        refillRate: null !== (r = this._instance.config.error_tracking.__exceptionRateLimiterRefillRate) && void 0 !== r ? r : 1,
                        bucketSize: null !== (s = this._instance.config.error_tracking.__exceptionRateLimiterBucketSize) && void 0 !== s ? s : 10,
                        refillInterval: 1e4,
                        Qt: va
                    }), this.Dt = this._a(), this.startIfEnabledOrStop()
                }
                _a() {
                    var t = this._instance.config.capture_exceptions,
                        e = {
                            capture_unhandled_errors: !1,
                            capture_unhandled_rejections: !1,
                            capture_console_errors: !1
                        };
                    return B(t) ? e = p({}, e, t) : (q(t) ? this.ya : t) && (e = p({}, e, {
                        capture_unhandled_errors: !0,
                        capture_unhandled_rejections: !0
                    })), e
                }
                get isEnabled() {
                    return this.Dt.capture_console_errors || this.Dt.capture_unhandled_errors || this.Dt.capture_unhandled_rejections
                }
                startIfEnabledOrStop() {
                    this.isEnabled ? (va.info("enabled"), this.ma(), this.qr(this.da)) : this.ma()
                }
                qr(t) {
                    var e, i;
                    null != (e = h.__PosthogExtensions__) && e.errorWrappingFunctions ? t() : null == (i = h.__PosthogExtensions__) || null == i.loadExternalDependency || i.loadExternalDependency(this._instance, "exception-autocapture", (e => {
                        if (e) return va.error("failed to load script", e);
                        t()
                    }))
                }
                ma() {
                    var t, e, i;
                    null == (t = this.fa) || t.call(this), this.fa = void 0, null == (e = this.pa) || e.call(this), this.pa = void 0, null == (i = this.ga) || i.call(this), this.ga = void 0
                }
                onRemoteConfig(t) {
                    "autocaptureExceptions" in t && (this.ya = !!t.autocaptureExceptions || !1, this._instance.persistence && this._instance.persistence.register({
                        [gi]: this.ya
                    }), this.Dt = this._a(), this.startIfEnabledOrStop())
                }
                onConfigChange() {
                    this.Dt = this._a()
                }
                captureException(t) {
                    var e, i, r, s = null !== (e = null == t || null == (i = t.$exception_list) || null == (i = i[0]) ? void 0 : i.type) && void 0 !== e ? e : "Exception";
                    this.ba.consumeRateLimit(s) ? va.info("Skipping exception capture because of client rate limiting.", {
                        exception: s
                    }) : null == (r = this._instance.exceptions) || r.sendExceptionEvent(t)
                }
            },
            exceptions: class {
                constructor(t) {
                    var e, i;
                    this.wa = [], this.xa = new Ie([new Ue, new Xe, new He, new Be, new Ke, new Je, new Ge, new Ye], function(t) {
                        for (var e = arguments.length, i = new Array(e > 1 ? e - 1 : 0), r = 1; e > r; r++) i[r - 1] = arguments[r];
                        return function(e, r) {
                            void 0 === r && (r = 0);
                            for (var s = [], n = e.split("\n"), o = r; n.length > o; o++) {
                                var a = n[o];
                                if (1024 >= a.length) {
                                    var l = Ne.test(a) ? a.replace(Ne, "$1") : a;
                                    if (!l.match(/\S*Error: /)) {
                                        for (var u of i) {
                                            var h = u(l, t);
                                            if (h) {
                                                s.push(h);
                                                break
                                            }
                                        }
                                        if (s.length >= 50) break
                                    }
                                }
                            }
                            return function(t) {
                                if (!t.length) return [];
                                var e = Array.from(t);
                                return e.reverse(), e.slice(0, 50).map((t => {
                                    return p({}, t, {
                                        filename: t.filename || (i = e, i[i.length - 1] || {}).filename,
                                        function: t.function || Re
                                    });
                                    var i
                                }))
                            }(s)
                        }
                    }("web:javascript", De, ze)), this._instance = t, this.wa = null !== (e = null == (i = this._instance.persistence) ? void 0 : i.get_property(_i)) && void 0 !== e ? e : [], this.ka = ii(this.Sa()), this.Ca = new ri(this.ka)
                }
                onConfigChange() {
                    this.ka = ii(this.Sa()), this.Ca.setConfig(this.ka)
                }
                onRemoteConfig(t) {
                    var e, i, r;
                    if ("errorTracking" in t) {
                        var s = null !== (e = null == (i = t.errorTracking) ? void 0 : i.suppressionRules) && void 0 !== e ? e : [],
                            n = null == (r = t.errorTracking) ? void 0 : r.captureExtensionExceptions;
                        this.wa = s, this._instance.persistence && this._instance.persistence.register({
                            [_i]: this.wa,
                            [mi]: n
                        })
                    }
                }
                get Ia() {
                    var t, e = !!this._instance.get_property(mi),
                        i = this._instance.config.error_tracking.captureExtensionExceptions;
                    return null !== (t = null != i ? i : e) && void 0 !== t && t
                }
                buildProperties(t, e) {
                    return this.xa.buildFromUnknown(t, {
                        syntheticException: null == e ? void 0 : e.syntheticException,
                        mechanism: {
                            handled: null == e ? void 0 : e.handled
                        }
                    })
                }
                addExceptionStep(t, e) {
                    if (this.ka.enabled) try {
                        if (!G(t) || 0 === t.trim().length) return void Ha.warn("Ignoring exception step because message must be a non-empty string");
                        var i = this.Ta(e),
                            {
                                sanitizedProperties: r,
                                droppedKeys: s
                            } = function(t) {
                                if (!t) return {
                                    sanitizedProperties: {},
                                    droppedKeys: []
                                };
                                var e = [];
                                return {
                                    sanitizedProperties: Object.keys(t).reduce(((i, r) => ti.has(r) ? (e.push(r), i) : (i[r] = t[r], i)), {}),
                                    droppedKeys: e
                                }
                            }(i);
                        s.length > 0 && Ha.warn("Ignoring reserved exception step fields", {
                            droppedKeys: s
                        }), this.Ca.add(p({
                            [Qe]: t,
                            [Ze]: (new Date).toISOString()
                        }, r))
                    } catch (t) {
                        Ha.error("Failed to add exception step. Ignoring breadcrumb.", t)
                    }
                }
                sendExceptionEvent(t) {
                    try {
                        var e = t.$exception_list;
                        if (this.Ea(e)) {
                            if (this.Ma(e)) return this.Pa("Exception dropped: matched a suppression rule"), void Ha.info("Skipping exception capture because a suppression rule matched");
                            if (!this.Ia && this.Ra(e)) return this.Pa("Exception dropped: thrown by a browser extension"), void Ha.info("Skipping exception capture because it was thrown by an extension");
                            if (!this._instance.config.error_tracking.__capturePostHogExceptions && this.Oa(e)) return this.Pa("Exception dropped: thrown by the PostHog SDK"), void Ha.info("Skipping exception capture because it was thrown by the PostHog SDK")
                        }
                        var i = this.ka.enabled && J(t.$exception_steps) ? this.La(t) : t;
                        try {
                            var r = this._instance.capture("$exception", i, {
                                _noTruncate: !0,
                                _batchKey: "exceptionEvent",
                                rs: !0
                            });
                            return r && this.Ca.clear(), r
                        } catch (t) {
                            return Ha.error("Failed to capture exception event. Dropping this exception.", t), void this.Ca.clear()
                        }
                    } catch (t) {
                        return void Ha.error("Failed to process exception event. Ignoring this exception.", t)
                    }
                }
                La(t) {
                    try {
                        var e = this.Ca.getAttachable();
                        return 0 === e.length ? t : p({}, t, {
                            $exception_steps: e
                        })
                    } catch (e) {
                        return Ha.error("Failed to read buffered exception steps. Capturing exception without steps.", e), t
                    }
                }
                Pa(t) {
                    this.ka.enabled && this.Ca.add({
                        [Qe]: t,
                        [Ze]: (new Date).toISOString()
                    })
                }
                Ta(t) {
                    return B(t) ? p({}, t) : {}
                }
                Sa() {
                    var t, e;
                    return null !== (t = null == (e = this._instance.config.error_tracking) ? void 0 : e.exception_steps) && void 0 !== t ? t : {}
                }
                Ma(t) {
                    if (0 === t.length) return !1;
                    var e = t.reduce(((t, e) => {
                        var {
                            type: i,
                            value: r
                        } = e;
                        return G(i) && i.length > 0 && t.$exception_types.push(i), G(r) && r.length > 0 && t.$exception_values.push(r), t
                    }), {
                        $exception_types: [],
                        $exception_values: []
                    });
                    return this.wa.some((t => {
                        var i = t.values.map((t => {
                            var i, r = Co[t.operator],
                                s = N(t.value) ? t.value : [t.value],
                                n = null !== (i = e[t.key]) && void 0 !== i ? i : [];
                            return s.length > 0 && r(s, n)
                        }));
                        return "OR" === t.type ? i.some(Boolean) : i.every(Boolean)
                    }))
                }
                Ra(t) {
                    return t.flatMap((t => {
                        var e, i;
                        return null !== (e = null == (i = t.stacktrace) ? void 0 : i.frames) && void 0 !== e ? e : []
                    })).some((t => t.filename && t.filename.startsWith("chrome-extension://")))
                }
                Oa(t) {
                    if (t.length > 0) {
                        var e, i, r, s, n = null !== (e = null == (i = t[0].stacktrace) ? void 0 : i.frames) && void 0 !== e ? e : [],
                            o = n[n.length - 1];
                        return null !== (r = null == o || null == (s = o.filename) ? void 0 : s.includes("posthog.com/static")) && void 0 !== r && r
                    }
                    return !1
                }
                Ea(t) {
                    return !J(t) && N(t)
                }
            }
        },
        Za = p({
            productTours: class {
                get Ki() {
                    return this._instance.persistence
                }
                constructor(t) {
                    this.Aa = null, this.Fa = null, this._instance = t
                }
                initialize() {
                    this.loadIfEnabled()
                }
                onRemoteConfig(t) {
                    if ("productTours" in t) {
                        var e, i;
                        if (this.Ki && this.Ki.register({
                                [wi]: !!t.productTours
                            }), !ka(this._instance)) return !this.Aa && J(null == (e = this.Ki) ? void 0 : e.props[qi]) || Sa.info("product tours disabled; stopping and clearing cached tours"), null == (i = this.Aa) || i.stop(), this.Aa = null, void this.clearCache();
                        this.loadIfEnabled()
                    }
                }
                loadIfEnabled() {
                    !this.Aa && ka(this._instance) && this.qr((() => this.Na()))
                }
                qr(t) {
                    var e, i;
                    null != (e = h.__PosthogExtensions__) && e.generateProductTours ? t() : null == (i = h.__PosthogExtensions__) || null == i.loadExternalDependency || i.loadExternalDependency(this._instance, "product-tours", (e => {
                        e ? Sa.error("Could not load product tours script", e) : t()
                    }))
                }
                Na() {
                    var t;
                    !this.Aa && null != (t = h.__PosthogExtensions__) && t.generateProductTours && (this.Aa = h.__PosthogExtensions__.generateProductTours(this._instance, !0))
                }
                getProductTours(t, e) {
                    if (void 0 === e && (e = !1), !N(this.Fa) || e) {
                        var i = this.Ki;
                        if (i) {
                            var r = i.props[qi];
                            if (N(r) && !e) return this.Fa = r, void t(r, {
                                isLoaded: !0
                            })
                        }
                        this._instance._send_request({
                            url: this._instance.requestRouter.endpointFor("api", "/api/product_tours/?token=" + this._instance.config.token),
                            method: "GET",
                            callback: e => {
                                if (ka(this._instance)) {
                                    var r = e.statusCode;
                                    if (200 !== r || !e.json) {
                                        var s = "Product Tours API could not be loaded, status: " + r;
                                        return Sa.error(s), void t([], {
                                            isLoaded: !1,
                                            error: s
                                        })
                                    }
                                    var n = N(e.json.product_tours) ? e.json.product_tours : [];
                                    this.Fa = n, i && i.register({
                                        [qi]: n
                                    }), t(n, {
                                        isLoaded: !0
                                    })
                                } else t([], {
                                    isLoaded: !0
                                })
                            }
                        })
                    } else t(this.Fa, {
                        isLoaded: !0
                    })
                }
                getActiveProductTours(t) {
                    J(this.Aa) ? t([], {
                        isLoaded: !1,
                        error: "Product tours not loaded"
                    }) : this.Aa.getActiveProductTours(t)
                }
                showProductTour(t) {
                    var e;
                    null == (e = this.Aa) || e.showTourById(t)
                }
                previewTour(t) {
                    this.Aa ? this.Aa.previewTour(t) : this.qr((() => {
                        var e;
                        this.Na(), null == (e = this.Aa) || e.previewTour(t)
                    }))
                }
                dismissProductTour() {
                    var t;
                    null == (t = this.Aa) || t.dismissTour("user_clicked_skip")
                }
                nextStep() {
                    var t;
                    null == (t = this.Aa) || t.nextStep()
                }
                previousStep() {
                    var t;
                    null == (t = this.Aa) || t.previousStep()
                }
                clearCache() {
                    var t;
                    this.Fa = null, null == (t = this.Ki) || t.unregister(qi)
                }
                resetTour(t) {
                    var e;
                    null == (e = this.Aa) || e.resetTour(t)
                }
                resetAllTours() {
                    var t;
                    null == (t = this.Aa) || t.resetAllTours()
                }
                cancelPendingTour(t) {
                    var e;
                    null == (e = this.Aa) || e.cancelPendingTour(t)
                }
            }
        }, Ka),
        tl = {
            siteApps: class {
                constructor(t) {
                    this.Da = 0, this._instance = t, this.$a = [], this.apps = {}
                }
                get isEnabled() {
                    return !!this._instance.config.opt_in_site_apps
                }
                qa(t, e) {
                    if (e) {
                        var i = this.globalsForEvent(e);
                        this.$a.push(i), this.$a.length > 1e3 && (this.$a = this.$a.slice(10))
                    }
                }
                get siteAppLoaders() {
                    var t;
                    return null == (t = h._POSTHOG_REMOTE_CONFIG) || null == (t = t[this._instance.config.token]) ? void 0 : t.siteApps
                }
                initialize() {
                    if (this.isEnabled) {
                        var t = this._instance._addCaptureHook(this.qa.bind(this));
                        this.ja = () => {
                            t(), this.$a = [], this.ja = void 0
                        }
                    }
                }
                globalsForEvent(t) {
                    var e, i, r, s, n, o, a;
                    if (!t) throw new Error("Event payload is required");
                    var l = {},
                        u = this._instance.get_property("$groups") || [],
                        h = this._instance.get_property("$stored_group_properties") || {};
                    for (var [d, v] of Object.entries(h)) l[d] = {
                        id: u[d],
                        type: d,
                        properties: v
                    };
                    var {
                        $set_once: c,
                        $set: f
                    } = t;
                    return {
                        event: p({}, g(t, $a), {
                            properties: p({}, t.properties, f ? {
                                $set: p({}, null !== (e = null == (i = t.properties) ? void 0 : i.$set) && void 0 !== e ? e : {}, f)
                            } : {}, c ? {
                                $set_once: p({}, null !== (r = null == (s = t.properties) ? void 0 : s.$set_once) && void 0 !== r ? r : {}, c)
                            } : {}),
                            elements_chain: null !== (n = null == (o = t.properties) ? void 0 : o.$elements_chain) && void 0 !== n ? n : "",
                            distinct_id: null == (a = t.properties) ? void 0 : a.distinct_id
                        }),
                        person: {
                            properties: this._instance.get_property("$stored_person_properties")
                        },
                        groups: l
                    }
                }
                Ba(t) {
                    var e, i = null == (e = t.tagName) ? void 0 : e.toLowerCase();
                    return "style" === i && this._instance.config.prepare_external_dependency_stylesheet ? this._instance.config.prepare_external_dependency_stylesheet(t) || (Pa.error("prepare_external_dependency_stylesheet returned null"), null) : "script" === i && this._instance.config.prepare_external_dependency_script ? this._instance.config.prepare_external_dependency_script(t) || (Pa.error("prepare_external_dependency_script returned null"), null) : t
                }
                Ha() {
                    var t, e, i, s, n, o, a, l;
                    if (!this._instance.config.prepare_external_dependency_stylesheet && !this._instance.config.prepare_external_dependency_script) return () => {};
                    var u = null == r ? void 0 : r.defaultView,
                        h = null == u || null == (t = u.Node) ? void 0 : t.prototype;
                    if (!u || !h) return () => {};
                    if (this.Da++, this.Ua) return this.za();
                    var d = [],
                        v = this,
                        c = new WeakSet,
                        f = (t, e, i) => {
                            if (null != t && t[e]) {
                                var r = t[e];
                                t[e] = i(r), d.push((() => {
                                    t[e] = r
                                }))
                            }
                        },
                        p = t => {
                            if (c.has(t)) return t;
                            var e = v.Ba(t);
                            return e && c.add(e), e
                        },
                        g = t => t.map((t => "string" == typeof t ? t : p(t))).filter((t => !W(t)));
                    return f(h, "appendChild", (t => function(e) {
                        var i = p(e);
                        return i ? t.call(this, i) : e
                    })), f(h, "insertBefore", (t => function(e, i) {
                        var r = p(e);
                        return r ? t.call(this, r, i) : e
                    })), f(h, "replaceChild", (t => function(e, i) {
                        var r = p(e);
                        return r ? t.call(this, r, i) : i
                    })), [null == (e = u.Element) ? void 0 : e.prototype, null == (i = u.Document) ? void 0 : i.prototype, null == (s = u.DocumentFragment) ? void 0 : s.prototype].forEach((t => {
                        f(t, "append", (t => function() {
                            for (var e = arguments.length, i = new Array(e), r = 0; e > r; r++) i[r] = arguments[r];
                            return t.apply(this, g(i))
                        })), f(t, "prepend", (t => function() {
                            for (var e = arguments.length, i = new Array(e), r = 0; e > r; r++) i[r] = arguments[r];
                            return t.apply(this, g(i))
                        }))
                    })), [null == (n = u.Element) ? void 0 : n.prototype, null == (o = u.CharacterData) ? void 0 : o.prototype, null == (a = u.DocumentType) ? void 0 : a.prototype].forEach((t => {
                        f(t, "before", (t => function() {
                            for (var e = arguments.length, i = new Array(e), r = 0; e > r; r++) i[r] = arguments[r];
                            return t.apply(this, g(i))
                        })), f(t, "after", (t => function() {
                            for (var e = arguments.length, i = new Array(e), r = 0; e > r; r++) i[r] = arguments[r];
                            return t.apply(this, g(i))
                        })), f(t, "replaceWith", (t => function() {
                            for (var e = arguments.length, i = new Array(e), r = 0; e > r; r++) i[r] = arguments[r];
                            var s = g(i);
                            return i.length && !s.length ? void 0 : t.apply(this, s)
                        }))
                    })), f(null == (l = u.Element) ? void 0 : l.prototype, "insertAdjacentElement", (t => function(e, i) {
                        var r = p(i);
                        return r ? t.call(this, e, r) : null
                    })), this.Ua = () => {
                        d.forEach((t => t())), this.Ua = void 0
                    }, this.za()
                }
                za() {
                    var t = !1;
                    return () => {
                        var e;
                        t || (t = !0, this.Da--, 0 === this.Da && (null == (e = this.Ua) || e.call(this)))
                    }
                }
                Va(t, e) {
                    void 0 === e && (e = !0);
                    var i = this.Ha();
                    try {
                        var r = t(i);
                        return e && i(), r
                    } catch (t) {
                        throw i(), t
                    }
                }
                setupSiteApp(t) {
                    var e = this.apps[t.id],
                        i = () => {
                            var i;
                            !e.errored && this.$a.length && (Pa.info("Processing " + this.$a.length + " events for site app with id " + t.id), this.$a.forEach((t => this.Va((() => null == e.processEvent ? void 0 : e.processEvent(t))))), e.processedBuffer = !0), Object.values(this.apps).every((t => t.processedBuffer || t.errored)) && (null == (i = this.ja) || i.call(this))
                        },
                        r = !1,
                        s = s => {
                            e.errored = !s, e.loaded = !0, Pa.info("Site app with id " + t.id + " " + (s ? "loaded" : "errored")), r && i()
                        };
                    try {
                        var {
                            processEvent: n
                        } = this.Va((e => t.init({
                            posthog: this._instance,
                            callback(t) {
                                e(), s(t)
                            }
                        })), !1);
                        n && (e.processEvent = n), r = !0
                    } catch (e) {
                        Pa.error(Ta + t.id, e), s(!1)
                    }
                    if (r && e.loaded) try {
                        i()
                    } catch (i) {
                        Pa.error("Error while processing buffered events PostHog app with config id " + t.id, i), e.errored = !0
                    }
                }
                Wa() {
                    var t = this.siteAppLoaders || [];
                    for (var e of t) this.apps[e.id] = {
                        id: e.id,
                        loaded: !1,
                        errored: !1,
                        processedBuffer: !1
                    };
                    for (var i of t) this.setupSiteApp(i)
                }
                Ga(t) {
                    var e = this;
                    if (0 !== Object.keys(this.apps).length) {
                        var i = this.globalsForEvent(t),
                            r = function(r) {
                                try {
                                    e.Va((() => null == r.processEvent ? void 0 : r.processEvent(i)))
                                } catch (e) {
                                    Pa.error("Error while processing event " + t.event + " for site app " + r.id, e)
                                }
                            };
                        for (var s of Object.values(this.apps)) r(s)
                    }
                }
                onRemoteConfig(t) {
                    var e, i, r, s = this;
                    if (null != (e = this.siteAppLoaders) && e.length) return this.isEnabled ? (this.Wa(), void this._instance.on("eventCaptured", (t => this.Ga(t)))) : void Pa.error('PostHog site apps are disabled. Enable the "opt_in_site_apps" config to proceed.');
                    if (null == (i = this.ja) || i.call(this), null != (r = t.siteApps) && r.length)
                        if (this.isEnabled) {
                            var n = function(t) {
                                var e;
                                h["__$$ph_site_app_" + t] = s._instance, null == (e = h.__PosthogExtensions__) || null == e.loadSiteApp || e.loadSiteApp(s._instance, a, (e => {
                                    if (e) return Pa.error(Ta + t, e)
                                }))
                            };
                            for (var {
                                    id: o,
                                    url: a
                                } of t.siteApps) n(o)
                        } else Pa.error('PostHog site apps are disabled. Enable the "opt_in_site_apps" config to proceed.')
                }
            }
        },
        el = {
            tracingHeaders: class {
                constructor(t) {
                    this.Za = void 0, this.Qa = void 0, this.Ja = void 0, this.da = () => {
                        var t, e, i = this.Ka();
                        i ? (q(this.Za) && (this.Za = null == (t = h.__PosthogExtensions__) || null == (t = t.tracingHeadersPatchFns) ? void 0 : t._patchXHR(i, (() => this._instance.get_distinct_id()), this._instance.sessionManager)), q(this.Qa) && (this.Qa = null == (e = h.__PosthogExtensions__) || null == (e = e.tracingHeadersPatchFns) ? void 0 : e._patchFetch(i, (() => this._instance.get_distinct_id()), this._instance.sessionManager))) : this.ma()
                    }, this._instance = t
                }
                initialize() {
                    this.startIfEnabledOrStop()
                }
                qr(t) {
                    var e, i;
                    null != (e = h.__PosthogExtensions__) && e.tracingHeadersPatchFns ? t() : null == (i = h.__PosthogExtensions__) || null == i.loadExternalDependency || i.loadExternalDependency(this._instance, "tracing-headers", (e => {
                        if (e) return ca.error("failed to load script", e);
                        t()
                    }))
                }
                Ya() {
                    var t, e;
                    return null !== (t = null !== (e = this._instance.config.tracing_headers) && void 0 !== e ? e : this._instance.config.addTracingHeaders) && void 0 !== t ? t : this._instance.config.__add_tracing_headers
                }
                Ka() {
                    var t = this.Ya();
                    return N(t) ? (N(this.Ja) ? this.Ja.splice(0, this.Ja.length, ...t) : this.Ja = [...t], t.length > 0 ? this.Ja : void 0) : (N(this.Ja) && this.Ja.splice(0), this.Ja = t || void 0, this.Ja)
                }
                ma() {
                    var t, e;
                    null == (t = this.Za) || t.call(this), null == (e = this.Qa) || e.call(this), this.Za = void 0, this.Qa = void 0
                }
                startIfEnabledOrStop() {
                    this.Ka() ? this.qr(this.da) : this.ma()
                }
            }
        },
        il = p({
            surveys: class {
                get Dt() {
                    return this._instance.config
                }
                constructor(t) {
                    this.Xa = void 0, this._surveyManager = null, this.el = !1, this.tl = [], this.rl = null, this._instance = t, this._surveyEventReceiver = null
                }
                initialize() {
                    this.loadIfEnabled()
                }
                onRemoteConfig(t) {
                    if (!this.Dt.disable_surveys) {
                        var e = t.surveys;
                        if (J(e)) return jo.warn("Flags not loaded yet. Not loading surveys.");
                        var i = N(e);
                        this.Xa = i ? e.length > 0 : e, jo.info("flags response received, isSurveysEnabled: " + this.Xa), this.loadIfEnabled()
                    }
                }
                reset() {
                    try {
                        var t;
                        null == (t = this._surveyEventReceiver) || t.reset(), localStorage.removeItem("lastSeenSurveyDate");
                        for (var e = [], i = 0; i < localStorage.length; i++) {
                            var r = localStorage.key(i);
                            (null != r && r.startsWith(zo) || null != r && r.startsWith("inProgressSurvey_")) && e.push(r)
                        }
                        e.forEach((t => localStorage.removeItem(t)))
                    } catch (t) {}
                }
                loadIfEnabled() {
                    if (!this._surveyManager)
                        if (this.el) jo.info("Already initializing surveys, skipping...");
                        else if (this.Dt.disable_surveys) jo.info(Oa);
                    else if (this.Dt.cookieless_mode && this._instance.consent.isOptedOut()) jo.info("Not loading surveys in cookieless mode without consent.");
                    else {
                        var t = null == h ? void 0 : h.__PosthogExtensions__;
                        if (t) {
                            if (!q(this.Xa) || this.Dt.advanced_enable_surveys) {
                                var e = this.Xa || this.Dt.advanced_enable_surveys;
                                this.el = !0;
                                try {
                                    var i = t.generateSurveys;
                                    if (i) return void this.il(i, e);
                                    var r = t.loadExternalDependency;
                                    if (!r) return void this.nl(ar);
                                    r(this._instance, "surveys", (i => {
                                        i || !t.generateSurveys ? this.nl("Could not load surveys script", i) : this.il(t.generateSurveys, e)
                                    }))
                                } catch (t) {
                                    throw this.nl("Error initializing surveys", t), t
                                } finally {
                                    this.el = !1
                                }
                            }
                        } else jo.error("PostHog Extensions not found.")
                    }
                }
                il(t, e) {
                    this._surveyManager = t(this._instance, e), this._surveyEventReceiver = new Fa(this._instance), jo.info("Surveys loaded successfully"), this.sl({
                        isLoaded: !0
                    })
                }
                nl(t, e) {
                    jo.error(t, e), this.sl({
                        isLoaded: !1,
                        error: t
                    })
                }
                onSurveysLoaded(t) {
                    return this.tl.push(t), this._surveyManager && this.sl({
                        isLoaded: !0
                    }), () => {
                        this.tl = this.tl.filter((e => e !== t))
                    }
                }
                getSurveys(t, e) {
                    if (void 0 === e && (e = !1), this.Dt.disable_surveys) return jo.info(Oa), t([]);
                    var i, r = this._instance.get_property(Ui);
                    if (r && !e) return t(r, {
                        isLoaded: !0
                    });
                    "undefined" != typeof Promise && this.rl ? this.rl.then((e => {
                        var {
                            surveys: i,
                            context: r
                        } = e;
                        return t(i, r)
                    })) : ("undefined" != typeof Promise && (this.rl = new Promise((t => {
                        i = t
                    }))), this._instance._send_request({
                        url: this._instance.requestRouter.endpointFor("api", "/api/surveys/?token=" + this.Dt.token),
                        method: "GET",
                        timeout: this.Dt.surveys_request_timeout_ms,
                        callback: e => {
                            var r;
                            this.rl = null;
                            var s = e.statusCode;
                            if (200 !== s || !e.json) {
                                var n = "Surveys API could not be loaded, status: " + s;
                                jo.error(n);
                                var o = {
                                    isLoaded: !1,
                                    error: n
                                };
                                return t([], o), void(null == i || i({
                                    surveys: [],
                                    context: o
                                }))
                            }
                            var a, l = e.json.surveys || [],
                                u = l.filter((t => function(t) {
                                    return !(!t.start_date || t.end_date)
                                }(t) && (function(t) {
                                    var e;
                                    return !(null == (e = t.conditions) || null == (e = e.events) || null == (e = e.values) || !e.length)
                                }(t) || function(t) {
                                    var e;
                                    return !(null == (e = t.conditions) || null == (e = e.actions) || null == (e = e.values) || !e.length)
                                }(t))));
                            u.length > 0 && (null == (a = this._surveyEventReceiver) || a.register(u)), null == (r = this._instance.persistence) || r.register({
                                [Ui]: l,
                                [Bi]: Date.now()
                            });
                            var h = {
                                isLoaded: !0
                            };
                            t(l, h), null == i || i({
                                surveys: l,
                                context: h
                            })
                        }
                    }))
                }
                sl(t) {
                    for (var e of this.tl) try {
                        if (!t.isLoaded) return e([], t);
                        this.getSurveys(e)
                    } catch (t) {
                        jo.error("Error in survey callback", t)
                    }
                }
                getActiveMatchingSurveys(t, e) {
                    if (void 0 === e && (e = !1), !J(this._surveyManager)) return this._surveyManager.getActiveMatchingSurveys(t, e);
                    jo.warn("init was not called")
                }
                ol(t) {
                    var e = null;
                    return this.getSurveys((i => {
                        var r;
                        e = null !== (r = i.find((e => e.id === t))) && void 0 !== r ? r : null
                    })), e
                }
                al(t) {
                    if (J(this._surveyManager)) return {
                        eligible: !1,
                        reason: Ma
                    };
                    var e = "string" == typeof t ? this.ol(t) : t;
                    return e ? this._surveyManager.checkSurveyEligibility(e) : {
                        eligible: !1,
                        reason: "Survey not found"
                    }
                }
                canRenderSurvey(t) {
                    if (J(this._surveyManager)) return jo.warn("init was not called"), {
                        visible: !1,
                        disabledReason: Ma
                    };
                    var e = this.al(t);
                    return {
                        visible: e.eligible,
                        disabledReason: e.reason
                    }
                }
                canRenderSurveyAsync(t, e) {
                    return J(this._surveyManager) ? (jo.warn("init was not called"), Promise.resolve({
                        visible: !1,
                        disabledReason: Ma
                    })) : new Promise((i => {
                        this.getSurveys((e => {
                            var r, s = null !== (r = e.find((e => e.id === t))) && void 0 !== r ? r : null;
                            if (s) {
                                var n = this.al(s);
                                i({
                                    visible: n.eligible,
                                    disabledReason: n.reason
                                })
                            } else i({
                                visible: !1,
                                disabledReason: "Survey not found"
                            })
                        }), e)
                    }))
                }
                renderSurvey(t, e, i) {
                    var s;
                    if (J(this._surveyManager)) jo.warn("init was not called");
                    else {
                        var n = "string" == typeof t ? this.ol(t) : t;
                        if (null != n && n.id)
                            if (No.includes(n.type)) {
                                var o = null == r ? void 0 : r.querySelector(e);
                                if (o) return null != (s = n.appearance) && s.surveyPopupDelaySeconds ? (jo.info("Rendering survey " + n.id + " with delay of " + n.appearance.surveyPopupDelaySeconds + " seconds"), void setTimeout((() => {
                                    var t, e;
                                    jo.info("Rendering survey " + n.id + " with delay of " + (null == (t = n.appearance) ? void 0 : t.surveyPopupDelaySeconds) + " seconds"), null == (e = this._surveyManager) || e.renderSurvey(n, o, i), jo.info("Survey " + n.id + " rendered")
                                }), 1e3 * n.appearance.surveyPopupDelaySeconds)) : void this._surveyManager.renderSurvey(n, o, i);
                                jo.warn("Survey element not found")
                            } else jo.warn("Surveys of type " + n.type + " cannot be rendered in the app");
                        else jo.warn("Survey not found")
                    }
                }
                displaySurvey(t, e) {
                    var i;
                    if (J(this._surveyManager)) jo.warn("init was not called");
                    else {
                        var r = this.ol(t);
                        if (r) {
                            var s = r;
                            if (null != (i = r.appearance) && i.surveyPopupDelaySeconds && e.ignoreDelay && (s = p({}, r, {
                                    appearance: p({}, r.appearance, {
                                        surveyPopupDelaySeconds: 0
                                    })
                                })), e.displayType !== wn && e.initialResponses && jo.warn("initialResponses is only supported for popover surveys. prefill will not be applied."), !1 === e.ignoreConditions) {
                                var n = this.canRenderSurvey(r);
                                if (!n.visible) return void jo.warn("Survey is not eligible to be displayed: ", n.disabledReason)
                            }
                            "inline" !== e.displayType ? this._surveyManager.handlePopoverSurvey(s, e) : this.renderSurvey(s, e.selector, e.properties)
                        } else jo.warn("Survey not found")
                    }
                }
                cancelPendingSurvey(t) {
                    J(this._surveyManager) ? jo.warn("init was not called") : this._surveyManager.cancelSurvey(t)
                }
                handlePageUnload() {
                    var t;
                    null == (t = this._surveyManager) || t.handlePageUnload()
                }
            }
        }, Ka),
        rl = {
            toolbar: class {
                constructor(t) {
                    this.instance = t
                }
                ll(t) {
                    h.ph_toolbar_state = t
                }
                ul() {
                    var t;
                    return null !== (t = h.ph_toolbar_state) && void 0 !== t ? t : 0
                }
                initialize() {
                    return this.maybeLoadToolbar()
                }
                maybeLoadToolbar(e, i, s) {
                    if (void 0 === e && (e = void 0), void 0 === i && (i = void 0), void 0 === s && (s = void 0), Ir(this.instance.config)) return !1;
                    if (!t || !r) return !1;
                    e = null != e ? e : t.location, s = null != s ? s : t.history;
                    try {
                        if (!i) {
                            try {
                                t.localStorage.setItem("test", "test"), t.localStorage.removeItem("test")
                            } catch (t) {
                                return !1
                            }
                            i = null == t ? void 0 : t.localStorage
                        }
                        var n, o = Aa || Ks(e.hash, "__posthog") || Ks(e.hash, "state"),
                            a = o ? Er((() => JSON.parse(atob(decodeURIComponent(o))))) || Er((() => JSON.parse(decodeURIComponent(o)))) : null;
                        return a && "ph_authorize" === a.action ? ((n = a).source = "url", n && Object.keys(n).length > 0 && (a.desiredHash ? e.hash = a.desiredHash : s ? s.replaceState(s.state, "", e.pathname + e.search) : e.hash = "")) : ((n = JSON.parse(i.getItem(Da) || "{}")).source = "localstorage", delete n.userIntent), !(!n.token || this.instance.config.token !== n.token || (this.loadToolbar(n), 0))
                    } catch (t) {
                        return !1
                    }
                }
                hl(t) {
                    var e = h.ph_load_toolbar || h.ph_load_editor;
                    !J(e) && U(e) ? e(t, this.instance) : La.warn("No toolbar load function found")
                }
                loadToolbar(e) {
                    var i = !(null == r || !r.getElementById(ir));
                    if (!t || i) return !1;
                    var s = "custom" === this.instance.requestRouter.region && this.instance.config.advanced_disable_toolbar_metrics,
                        n = p({
                            token: this.instance.config.token
                        }, e, {
                            apiURL: this.instance.requestRouter.endpointFor("ui")
                        }, s ? {
                            instrument: !1
                        } : {});
                    if (t.localStorage.setItem(Da, JSON.stringify(p({}, n, {
                            source: void 0
                        }))), 2 === this.ul()) this.hl(n);
                    else if (0 === this.ul()) {
                        var o;
                        this.ll(1), null == (o = h.__PosthogExtensions__) || null == o.loadExternalDependency || o.loadExternalDependency(this.instance, "toolbar", (t => {
                            if (t) return La.error("[Toolbar] Failed to load", t), void this.ll(0);
                            this.ll(2), this.hl(n)
                        })), Tr(t, "turbolinks:load", (() => {
                            this.ll(0), this.loadToolbar(n)
                        }))
                    }
                    return !0
                }
                cl(t) {
                    return this.loadToolbar(t)
                }
                maybeLoadEditor(t, e, i) {
                    return void 0 === t && (t = void 0), void 0 === e && (e = void 0), void 0 === i && (i = void 0), this.maybeLoadToolbar(t, e, i)
                }
            }
        },
        sl = p({
            experiments: Va
        }, Ka),
        nl = p({}, Ka, Ya, Xa, Qa, Za, tl, il, el, rl, sl, {
            conversations: class {
                constructor(t) {
                    this.dl = void 0, this._conversationsManager = null, this.vl = !1, this.fl = null, this._instance = t
                }
                initialize() {
                    this.loadIfEnabled()
                }
                onRemoteConfig(t) {
                    if (!this._instance.config.disable_conversations) {
                        var e = t.conversations;
                        J(e) || (X(e) ? this.dl = e : (this.dl = e.enabled, this.fl = e), this.loadIfEnabled())
                    }
                }
                reset() {
                    var t;
                    null == (t = this._conversationsManager) || t.reset(), this._conversationsManager = null, this.dl = void 0, this.fl = null
                }
                loadIfEnabled() {
                    if (!(this._conversationsManager || this.vl || this._instance.config.disable_conversations || Ir(this._instance.config) || this._instance.config.cookieless_mode && this._instance.consent.isOptedOut())) {
                        var t = null == h ? void 0 : h.__PosthogExtensions__;
                        if (t && !q(this.dl) && this.dl)
                            if (this.fl && this.fl.token) {
                                this.vl = !0;
                                try {
                                    var e = t.initConversations;
                                    if (e) return this.pl(e), void(this.vl = !1);
                                    var i = t.loadExternalDependency;
                                    if (!i) return void this.gl(ar);
                                    i(this._instance, "conversations", (e => {
                                        e || !t.initConversations ? this.gl("Could not load conversations script", e) : this.pl(t.initConversations), this.vl = !1
                                    }))
                                } catch (t) {
                                    this.gl("Error initializing conversations", t), this.vl = !1
                                }
                            } else Wa.error("Conversations enabled but missing token in remote config.")
                    }
                }
                pl(t) {
                    if (this.fl) try {
                        this._conversationsManager = t(this.fl, this._instance), Wa.info("Conversations loaded successfully")
                    } catch (t) {
                        this.gl("Error completing conversations initialization", t)
                    } else Wa.error("Cannot complete initialization: remote config is null")
                }
                gl(t, e) {
                    Wa.error(t, e), this._conversationsManager = null, this.vl = !1
                }
                show() {
                    this._conversationsManager ? this._conversationsManager.show() : Wa.warn("Conversations not loaded yet.")
                }
                hide() {
                    this._conversationsManager && this._conversationsManager.hide()
                }
                isAvailable() {
                    return !0 === this.dl && !W(this._conversationsManager)
                }
                isVisible() {
                    var t, e;
                    return null !== (t = null == (e = this._conversationsManager) ? void 0 : e.isVisible()) && void 0 !== t && t
                }
                sendMessage(t, e, i) {
                    var r = this;
                    return f((function*() {
                        return r._conversationsManager ? r._conversationsManager.sendMessage(t, e, i) : (Wa.warn(Ja), null)
                    }))()
                }
                getMessages(t, e) {
                    var i = this;
                    return f((function*() {
                        return i._conversationsManager ? i._conversationsManager.getMessages(t, e) : (Wa.warn(Ja), null)
                    }))()
                }
                markAsRead(t) {
                    var e = this;
                    return f((function*() {
                        return e._conversationsManager ? e._conversationsManager.markAsRead(t) : (Wa.warn(Ja), null)
                    }))()
                }
                getTickets(t) {
                    var e = this;
                    return f((function*() {
                        return e._conversationsManager ? e._conversationsManager.getTickets(t) : (Wa.warn(Ja), null)
                    }))()
                }
                requestRestoreLink(t) {
                    var e = this;
                    return f((function*() {
                        return e._conversationsManager ? e._conversationsManager.requestRestoreLink(t) : (Wa.warn(Ja), null)
                    }))()
                }
                restoreFromToken(t) {
                    var e = this;
                    return f((function*() {
                        return e._conversationsManager ? e._conversationsManager.restoreFromToken(t) : (Wa.warn(Ja), null)
                    }))()
                }
                restoreFromUrlToken() {
                    var t = this;
                    return f((function*() {
                        return t._conversationsManager ? t._conversationsManager.restoreFromUrlToken() : (Wa.warn(Ja), null)
                    }))()
                }
                getCurrentTicketId() {
                    var t, e;
                    return null !== (t = null == (e = this._conversationsManager) ? void 0 : e.getCurrentTicketId()) && void 0 !== t ? t : null
                }
                getWidgetSessionId() {
                    var t, e;
                    return null !== (t = null == (e = this._conversationsManager) ? void 0 : e.getWidgetSessionId()) && void 0 !== t ? t : null
                }
                hs() {
                    var t;
                    null == (t = this._conversationsManager) || t.setIdentity()
                }
                cs() {
                    var t;
                    null == (t = this._conversationsManager) || t.clearIdentity()
                }
            }
        }, {
            logs: class {
                constructor(e) {
                    var i;
                    this.ml = !1, this.yl = !1, this.Qt = ai("[logs]"), this.Mi = [], this.bl = () => {
                        var t;
                        null == (t = this._l) || t.onReconnect()
                    }, this._instance = e, this._instance && null != (i = this._instance.config.logs) && i.captureConsoleLogs && (this.ml = !0), t && Tr(t, "online", this.bl)
                }
                wl() {
                    var t, e, i, r, s, n, o, a, l, u, h, d, v, c, f = null == (t = this._instance) || null == (t = t.config) ? void 0 : t.logs;
                    return this._l && this.xl === f || (null == (e = this._l) || e.reset(), this.xl = f, this.kl = (u = null !== (r = null == (i = f) ? void 0 : i.flushIntervalMs) && void 0 !== r ? r : 3e3, h = null !== (s = null == i ? void 0 : i.maxBufferSize) && void 0 !== s ? s : 100, d = null !== (n = null == i ? void 0 : i.maxLogsPerInterval) && void 0 !== n ? n : 1e3, v = Math.max(h, d), {
                        serviceName: null !== (o = null == (c = null == i ? void 0 : i.resourceAttributes) ? void 0 : c["service.name"]) && void 0 !== o ? o : null == i ? void 0 : i.serviceName,
                        serviceVersion: null !== (a = null == c ? void 0 : c["service.version"]) && void 0 !== a ? a : null == i ? void 0 : i.serviceVersion,
                        environment: null !== (l = null == c ? void 0 : c["deployment.environment"]) && void 0 !== l ? l : null == i ? void 0 : i.environment,
                        resourceAttributes: c,
                        beforeSend: null == i ? void 0 : i.beforeSend,
                        flushIntervalMs: u,
                        maxBufferSize: h,
                        maxQueueSize: v,
                        maxBatchRecordsPerPost: 100,
                        rateCapWindowMs: u,
                        maxLogsPerInterval: d,
                        backgroundFlushBudgetMs: 0,
                        terminationFlushBudgetMs: 0
                    }), this._l = new Se(this.Sl(), this.kl, this.Qt, (() => this.Cl()), (t => t()))), this._l
                }
                Il() {
                    return this.wl(), this.kl
                }
                initialize() {
                    this.loadIfEnabled()
                }
                onRemoteConfig(t) {
                    var e, i = null == (e = t.logs) ? void 0 : e.captureConsoleLogs;
                    !J(i) && i && (this.ml = !0, this.loadIfEnabled())
                }
                reset() {
                    var t;
                    this.Mi = [], null == (t = this._l) || t.reset()
                }
                captureLog(t) {
                    this.wl().captureLog(t)
                }
                get logger() {
                    return this.Tl || (this.Tl = {
                        trace: (t, e) => this.captureLog({
                            body: t,
                            level: "trace",
                            attributes: e
                        }),
                        debug: (t, e) => this.captureLog({
                            body: t,
                            level: "debug",
                            attributes: e
                        }),
                        info: (t, e) => this.captureLog({
                            body: t,
                            level: "info",
                            attributes: e
                        }),
                        warn: (t, e) => this.captureLog({
                            body: t,
                            level: "warn",
                            attributes: e
                        }),
                        error: (t, e) => this.captureLog({
                            body: t,
                            level: "error",
                            attributes: e
                        }),
                        fatal: (t, e) => this.captureLog({
                            body: t,
                            level: "fatal",
                            attributes: e
                        })
                    }), this.Tl
                }
                flushLogs(t) {
                    t ? this.El(t) : this.wl().flush().catch((t => this.Qt.error("PostHog logs flush failed:", t)))
                }
                loadIfEnabled() {
                    if (this.ml && !this.yl) {
                        var t = null == h ? void 0 : h.__PosthogExtensions__;
                        if (t) {
                            var e = t.loadExternalDependency;
                            e ? e(this._instance, "logs", (e => {
                                var i;
                                e || null == (i = t.logs) || !i.initializeLogs ? this.Qt.error("Could not load logs script", e) : (t.logs.initializeLogs(this._instance), this.yl = !0)
                            })) : this.Qt.error(ar)
                        } else this.Qt.error("PostHog Extensions not found.")
                    }
                }
                Sl() {
                    var t = this._instance;
                    return {
                        get isDisabled() {
                            return !1
                        },
                        get optedOut() {
                            return !t.is_capturing()
                        },
                        getPersistedProperty: t => t === w.LogsQueue ? this.Mi : void 0,
                        setPersistedProperty: (t, e) => {
                            var i;
                            t === w.LogsQueue && (this.Mi = null !== (i = e) && void 0 !== i ? i : [])
                        },
                        kr: t => this.kr(t),
                        getLibraryId: () => v.LIB_NAME,
                        getLibraryVersion: () => v.LIB_VERSION
                    }
                }
                kr(t) {
                    return new Promise((e => {
                        var i = !1,
                            r = t => {
                                i || (i = !0, clearTimeout(s), e(t))
                            },
                            s = setTimeout((() => r({
                                kind: "retry-later",
                                error: new Error("logs request timed out")
                            })), 9e4);
                        this._instance._send_request({
                            method: "POST",
                            url: this.Ml(),
                            data: t,
                            compression: "best-available",
                            batchKey: "logs",
                            fireCallbackOnDrop: !0,
                            callback(t) {
                                var e = t.statusCode;
                                if (e >= 200 && 300 > e) r({
                                    kind: "ok"
                                });
                                else if (413 === e) r({
                                    kind: "too-large"
                                });
                                else if (0 !== e && 429 !== e && 500 > e) r({
                                    kind: "fatal",
                                    error: new Error("logs request failed with status " + e)
                                });
                                else {
                                    var i;
                                    r({
                                        kind: "retry-later",
                                        error: null !== (i = t.error) && void 0 !== i ? i : new Error("logs request failed with status " + e)
                                    })
                                }
                            }
                        })
                    }))
                }
                El(t) {
                    var e = this.Il();
                    if (0 !== this.Mi.length) {
                        var i = this.Mi.map((t => t.record));
                        this.Mi = [];
                        var r = Ee(i, xe(e, v.LIB_NAME, v.LIB_VERSION), v.LIB_NAME, v.LIB_VERSION);
                        this._instance._send_request({
                            method: "POST",
                            url: this.Ml(),
                            data: r,
                            compression: "best-available",
                            batchKey: "logs",
                            transport: t
                        })
                    }
                }
                Ml() {
                    return this._instance.requestRouter.endpointFor("api", "/i/v1/logs") + "?token=" + encodeURIComponent(this._instance.config.token)
                }
                Cl() {
                    var t, e = {};
                    if (e.distinctId = this._instance.get_distinct_id(), this._instance.sessionManager) {
                        var {
                            sessionId: i
                        } = this._instance.sessionManager.checkAndGetSessionAndWindowId(!0);
                        e.sessionId = i
                    }
                    if (null != h && null != (t = h.location) && t.href && (e.currentUrl = h.location.href), this._instance.featureFlags) {
                        var r = this._instance.featureFlags.getFlags();
                        r && r.length > 0 && (e.activeFeatureFlags = r)
                    }
                    return e
                }
            }
        });
    na.__defaultExtensionClasses = p({}, nl),
        function() {
            v.SDK_DIST_CHANNEL = "cdn";
            var e = Vo[Zo] = new na,
                i = h.posthog;
            i && br(i._i, (function(t) {
                    if (t && N(t)) {
                        var r = e.init(t[0], t[1], t[2]),
                            s = i[t[2]] || i;
                        r && (r._execute_array.call(r.people, s.people), r._execute_array(s))
                    }
                })), h.posthog = e,
                function() {
                    function e() {
                        e.done || (e.done = !0, ta = !1, br(Vo, (function(t) {
                            t._dom_loaded()
                        })))
                    }
                    null != r && r.addEventListener ? "complete" === r.readyState ? e() : Tr(r, "DOMContentLoaded", e, {
                        capture: !1
                    }) : t && oi.error("Browser doesn't support `document.addEventListener` so PostHog couldn't be initialized")
                }()
        }()
}();
//# sourceMappingURL=array.js.map