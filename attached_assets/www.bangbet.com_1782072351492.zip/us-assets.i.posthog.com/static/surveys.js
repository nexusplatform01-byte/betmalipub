! function() {
    "use strict";

    function e() {
        return e = Object.assign ? Object.assign.bind() : function(e) {
            for (var r = 1; arguments.length > r; r++) {
                var t = arguments[r];
                for (var n in t)({}).hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            return e
        }, e.apply(null, arguments)
    }
    var r, t, n, i, o, a, s, u, l, c, d, v, p, f, h, y = {},
        m = [],
        g = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
        b = Array.isArray;

    function w(e, r) {
        for (var t in r) e[t] = r[t];
        return e
    }

    function x(e) {
        e && e.parentNode && e.parentNode.removeChild(e)
    }

    function k(e, t, n) {
        var i, o, a, s = {};
        for (a in t) "key" == a ? i = t[a] : "ref" == a ? o = t[a] : s[a] = t[a];
        if (arguments.length > 2 && (s.children = arguments.length > 3 ? r.call(arguments, 2) : n), "function" == typeof e && null != e.defaultProps)
            for (a in e.defaultProps) void 0 === s[a] && (s[a] = e.defaultProps[a]);
        return S(e, s, i, o, null)
    }

    function S(e, r, i, o, a) {
        var s = {
            type: e,
            props: r,
            key: i,
            ref: o,
            __k: null,
            __: null,
            __b: 0,
            __e: null,
            __c: null,
            constructor: void 0,
            __v: null == a ? ++n : a,
            __i: -1,
            __u: 0
        };
        return null == a && null != t.vnode && t.vnode(s), s
    }

    function C(e) {
        return e.children
    }

    function q(e, r) {
        this.props = e, this.context = r
    }

    function $(e, r) {
        if (null == r) return e.__ ? $(e.__, e.__i + 1) : null;
        for (var t; e.__k.length > r; r++)
            if (null != (t = e.__k[r]) && null != t.__e) return t.__e;
        return "function" == typeof e.type ? $(e) : null
    }

    function _(e) {
        if (e.__P && e.__d) {
            var r = e.__v,
                n = r.__e,
                i = [],
                o = [],
                a = w({}, r);
            a.__v = r.__v + 1, t.vnode && t.vnode(a), D(e.__P, a, r, e.__n, e.__P.namespaceURI, 32 & r.__u ? [n] : null, i, null == n ? $(r) : n, !!(32 & r.__u), o), a.__v = r.__v, a.__.__k[a.__i] = a, Z(i, a, o), r.__e = r.__ = null, a.__e != n && T(a)
        }
    }

    function T(e) {
        if (null != (e = e.__) && null != e.__c) return e.__e = e.__c.base = null, e.__k.some((function(r) {
            if (null != r && null != r.__e) return e.__e = e.__c.base = r.__e
        })), T(e)
    }

    function P(e) {
        (!e.__d && (e.__d = !0) && i.push(e) && !I.__r++ || o != t.debounceRendering) && ((o = t.debounceRendering) || a)(I)
    }

    function I() {
        try {
            for (var e, r = 1; i.length;) i.length > r && i.sort(s), e = i.shift(), r = i.length, _(e)
        } finally {
            i.length = I.__r = 0
        }
    }

    function M(e, r, t, n, i, o, a, s, u, l, c) {
        var d, v, p, f, h, g, b, w = n && n.__k || m,
            x = r.length;
        for (u = L(t, r, w, u, x), d = 0; x > d; d++) null != (p = t.__k[d]) && (v = -1 != p.__i && w[p.__i] || y, p.__i = d, g = D(e, p, v, i, o, a, s, u, l, c), f = p.__e, p.ref && v.ref != p.ref && (v.ref && j(v.ref, null, p), c.push(p.ref, p.__c || f, p)), null == h && null != f && (h = f), (b = !!(4 & p.__u)) || v.__k === p.__k ? (u = N(p, u, e, b), b && v.__e && (v.__e = null)) : "function" == typeof p.type && void 0 !== g ? u = g : f && (u = f.nextSibling), p.__u &= -7);
        return t.__e = h, u
    }

    function L(e, r, t, n, i) {
        var o, a, s, u, l, c = t.length,
            d = c,
            v = 0;
        for (e.__k = new Array(i), o = 0; i > o; o++) null != (a = r[o]) && "boolean" != typeof a && "function" != typeof a ? ("string" == typeof a || "number" == typeof a || "bigint" == typeof a || a.constructor == String ? a = e.__k[o] = S(null, a, null, null, null) : b(a) ? a = e.__k[o] = S(C, {
            children: a
        }, null, null, null) : void 0 === a.constructor && a.__b > 0 ? a = e.__k[o] = S(a.type, a.props, a.key, a.ref ? a.ref : null, a.__v) : e.__k[o] = a, u = o + v, a.__ = e, a.__b = e.__b + 1, s = null, -1 != (l = a.__i = H(a, t, u, d)) && (d--, (s = t[l]) && (s.__u |= 2)), null == s || null == s.__v ? (-1 == l && (i > c ? v-- : c > i && v++), "function" != typeof a.type && (a.__u |= 4)) : l != u && (l == u - 1 ? v-- : l == u + 1 ? v++ : (l > u ? v-- : v++, a.__u |= 4))) : e.__k[o] = null;
        if (d)
            for (o = 0; c > o; o++) null != (s = t[o]) && 0 == (2 & s.__u) && (s.__e == n && (n = $(s)), Q(s, s));
        return n
    }

    function N(e, r, t, n) {
        var i, o;
        if ("function" == typeof e.type) {
            for (i = e.__k, o = 0; i && i.length > o; o++) i[o] && (i[o].__ = e, r = N(i[o], r, t, n));
            return r
        }
        e.__e != r && (n && (r && e.type && !r.parentNode && (r = $(e)), t.insertBefore(e.__e, r || null)), r = e.__e);
        do {
            r = r && r.nextSibling
        } while (null != r && 8 == r.nodeType);
        return r
    }

    function H(e, r, t, n) {
        var i, o, a, s = e.key,
            u = e.type,
            l = r[t],
            c = null != l && 0 == (2 & l.__u);
        if (null === l && null == s || c && s == l.key && u == l.type) return t;
        if (n > (c ? 1 : 0))
            for (i = t - 1, o = t + 1; i >= 0 || r.length > o;)
                if (null != (l = r[a = 0 > i ? o++ : i--]) && 0 == (2 & l.__u) && s == l.key && u == l.type) return a;
        return -1
    }

    function E(e, r, t) {
        "-" == r[0] ? e.setProperty(r, null == t ? "" : t) : e[r] = null == t ? "" : "number" != typeof t || g.test(r) ? t : t + "px"
    }

    function V(e, r, t, n, i) {
        var o, a;
        e: if ("style" == r)
            if ("string" == typeof t) e.style.cssText = t;
            else {
                if ("string" == typeof n && (e.style.cssText = n = ""), n)
                    for (r in n) t && r in t || E(e.style, r, "");
                if (t)
                    for (r in t) n && t[r] == n[r] || E(e.style, r, t[r])
            }
        else if ("o" == r[0] && "n" == r[1]) o = r != (r = r.replace(d, "$1")), a = r.toLowerCase(), r = a in e || "onFocusOut" == r || "onFocusIn" == r ? a.slice(2) : r.slice(2), e.l || (e.l = {}), e.l[r + o] = t, t ? n ? t[c] = n[c] : (t[c] = v, e.addEventListener(r, o ? f : p, o)) : e.removeEventListener(r, o ? f : p, o);
        else {
            if ("http://www.w3.org/2000/svg" == i) r = r.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
            else if ("width" != r && "height" != r && "href" != r && "list" != r && "form" != r && "tabIndex" != r && "download" != r && "rowSpan" != r && "colSpan" != r && "role" != r && "popover" != r && r in e) try {
                e[r] = null == t ? "" : t;
                break e
            } catch (e) {}
            "function" == typeof t || (null == t || !1 === t && "-" != r[4] ? e.removeAttribute(r) : e.setAttribute(r, "popover" == r && 1 == t ? "" : t))
        }
    }

    function B(e) {
        return function(r) {
            if (this.l) {
                var n = this.l[r.type + e];
                if (null == r[l]) r[l] = v++;
                else if (n[c] > r[l]) return;
                return n(t.event ? t.event(r) : r)
            }
        }
    }

    function D(e, r, n, i, o, a, s, u, l, c) {
        var d, v, p, f, h, y, g, k, S, _, $, T, P, I, L, N = r.type;
        if (void 0 !== r.constructor) return null;
        128 & n.__u && (l = !!(32 & n.__u), a = [u = r.__e = n.__e]), (d = t.__b) && d(r);
        e: if ("function" == typeof N) try {
            if (k = r.props, S = N.prototype && N.prototype.render, _ = (d = N.contextType) && i[d.__c], $ = d ? _ ? _.props.value : d.__ : i, n.__c ? g = (v = r.__c = n.__c).__ = v.__E : (S ? r.__c = v = new N(k, $) : (r.__c = v = new q(k, $), v.constructor = N, v.render = U), _ && _.sub(v), v.state || (v.state = {}), v.__n = i, p = v.__d = !0, v.__h = [], v._sb = []), S && null == v.__s && (v.__s = v.state), S && null != N.getDerivedStateFromProps && (v.__s == v.state && (v.__s = w({}, v.__s)), w(v.__s, N.getDerivedStateFromProps(k, v.__s))), f = v.props, h = v.state, v.__v = r, p) S && null == N.getDerivedStateFromProps && null != v.componentWillMount && v.componentWillMount(), S && null != v.componentDidMount && v.__h.push(v.componentDidMount);
            else {
                if (S && null == N.getDerivedStateFromProps && k !== f && null != v.componentWillReceiveProps && v.componentWillReceiveProps(k, $), r.__v == n.__v || !v.__e && null != v.shouldComponentUpdate && !1 === v.shouldComponentUpdate(k, v.__s, $)) {
                    r.__v != n.__v && (v.props = k, v.state = v.__s, v.__d = !1), r.__e = n.__e, r.__k = n.__k, r.__k.some((function(e) {
                        e && (e.__ = r)
                    })), m.push.apply(v.__h, v._sb), v._sb = [], v.__h.length && s.push(v);
                    break e
                }
                null != v.componentWillUpdate && v.componentWillUpdate(k, v.__s, $), S && null != v.componentDidUpdate && v.__h.push((function() {
                    v.componentDidUpdate(f, h, y)
                }))
            }
            if (v.context = $, v.props = k, v.__P = e, v.__e = !1, T = t.__r, P = 0, S) v.state = v.__s, v.__d = !1, T && T(r), d = v.render(v.props, v.state, v.context), m.push.apply(v.__h, v._sb), v._sb = [];
            else
                do {
                    v.__d = !1, T && T(r), d = v.render(v.props, v.state, v.context), v.state = v.__s
                } while (v.__d && 25 > ++P);
            v.state = v.__s, null != v.getChildContext && (i = w(w({}, i), v.getChildContext())), S && !p && null != v.getSnapshotBeforeUpdate && (y = v.getSnapshotBeforeUpdate(f, h)), I = null != d && d.type === C && null == d.key ? R(d.props.children) : d, u = M(e, b(I) ? I : [I], r, n, i, o, a, s, u, l, c), v.base = r.__e, r.__u &= -161, v.__h.length && s.push(v), g && (v.__E = v.__ = null)
        } catch (e) {
            if (r.__v = null, l || null != a)
                if (e.then) {
                    for (r.__u |= l ? 160 : 128; u && 8 == u.nodeType && u.nextSibling;) u = u.nextSibling;
                    a[a.indexOf(u)] = null, r.__e = u
                } else {
                    for (L = a.length; L--;) x(a[L]);
                    A(r)
                }
            else r.__e = n.__e, r.__k = n.__k, e.then || A(r);
            t.__e(e, r, n)
        } else null == a && r.__v == n.__v ? (r.__k = n.__k, r.__e = n.__e) : u = r.__e = F(n.__e, r, n, i, o, a, s, l, c);
        return (d = t.diffed) && d(r), 128 & r.__u ? void 0 : u
    }

    function A(e) {
        e && (e.__c && (e.__c.__e = !0), e.__k && e.__k.some(A))
    }

    function Z(e, r, n) {
        for (var i = 0; n.length > i; i++) j(n[i], n[++i], n[++i]);
        t.__c && t.__c(r, e), e.some((function(r) {
            try {
                e = r.__h, r.__h = [], e.some((function(e) {
                    e.call(r)
                }))
            } catch (e) {
                t.__e(e, r.__v)
            }
        }))
    }

    function R(e) {
        return "object" != typeof e || null == e || e.__b > 0 ? e : b(e) ? e.map(R) : void 0 !== e.constructor ? null : w({}, e)
    }

    function F(e, n, i, o, a, s, u, l, c) {
        var d, v, p, f, h, m, g, w = i.props || y,
            k = n.props,
            S = n.type;
        if ("svg" == S ? a = "http://www.w3.org/2000/svg" : "math" == S ? a = "http://www.w3.org/1998/Math/MathML" : a || (a = "http://www.w3.org/1999/xhtml"), null != s)
            for (d = 0; s.length > d; d++)
                if ((h = s[d]) && "setAttribute" in h == !!S && (S ? h.localName == S : 3 == h.nodeType)) {
                    e = h, s[d] = null;
                    break
                }
        if (null == e) {
            if (null == S) return document.createTextNode(k);
            e = document.createElementNS(a, S, k.is && k), l && (t.__m && t.__m(n, s), l = !1), s = null
        }
        if (null == S) w === k || l && e.data == k || (e.data = k);
        else {
            if (s = "textarea" == S && null != k.defaultValue ? null : s && r.call(e.childNodes), !l && null != s)
                for (w = {}, d = 0; e.attributes.length > d; d++) w[(h = e.attributes[d]).name] = h.value;
            for (d in w) h = w[d], "dangerouslySetInnerHTML" == d ? p = h : "children" == d || d in k || "value" == d && "defaultValue" in k || "checked" == d && "defaultChecked" in k || V(e, d, null, h, a);
            for (d in k) h = k[d], "children" == d ? f = h : "dangerouslySetInnerHTML" == d ? v = h : "value" == d ? m = h : "checked" == d ? g = h : l && "function" != typeof h || w[d] === h || V(e, d, h, w[d], a);
            if (v) l || p && (v.__html == p.__html || v.__html == e.innerHTML) || (e.innerHTML = v.__html), n.__k = [];
            else if (p && (e.innerHTML = ""), M("template" == n.type ? e.content : e, b(f) ? f : [f], n, i, o, "foreignObject" == S ? "http://www.w3.org/1999/xhtml" : a, s, u, s ? s[0] : i.__k && $(i, 0), l, c), null != s)
                for (d = s.length; d--;) x(s[d]);
            l && "textarea" != S || (d = "value", "progress" == S && null == m ? e.removeAttribute("value") : null != m && (m !== e[d] || "progress" == S && !m || "option" == S && m != w[d]) && V(e, d, m, w[d], a), d = "checked", null != g && g != e[d] && V(e, d, g, w[d], a))
        }
        return e
    }

    function j(e, r, n) {
        try {
            if ("function" == typeof e) {
                var i = "function" == typeof e.__u;
                i && e.__u(), i && null == r || (e.__u = e(r))
            } else e.current = r
        } catch (e) {
            t.__e(e, n)
        }
    }

    function Q(e, r, n) {
        var i, o;
        if (t.unmount && t.unmount(e), (i = e.ref) && (i.current && i.current != e.__e || j(i, null, r)), null != (i = e.__c)) {
            if (i.componentWillUnmount) try {
                i.componentWillUnmount()
            } catch (e) {
                t.__e(e, r)
            }
            i.base = i.__P = null
        }
        if (i = e.__k)
            for (o = 0; i.length > o; o++) i[o] && Q(i[o], r, n || "function" != typeof e.type);
        n || x(e.__e), e.__c = e.__ = e.__e = void 0
    }

    function U(e, r, t) {
        return this.constructor(e, t)
    }

    function z(e, n, i) {
        var o, a, s;
        n == document && (n = document.documentElement), t.__ && t.__(e, n), o = n.__k, a = [], s = [], D(n, e = n.__k = k(C, null, [e]), o || y, y, n.namespaceURI, o ? null : n.firstChild ? r.call(n.childNodes) : null, a, o ? o.__e : n.firstChild, !1, s), Z(a, e, s)
    }
    r = m.slice, t = {
        __e(e, r, t, n) {
            for (var i, o, a; r = r.__;)
                if ((i = r.__c) && !i.__) try {
                    if ((o = i.constructor) && null != o.getDerivedStateFromError && (i.setState(o.getDerivedStateFromError(e)), a = i.__d), null != i.componentDidCatch && (i.componentDidCatch(e, n || {}), a = i.__d), a) return i.__E = i
                } catch (r) {
                    e = r
                }
            throw e
        }
    }, n = 0, q.prototype.setState = function(e, r) {
        var t;
        t = null != this.__s && this.__s != this.state ? this.__s : this.__s = w({}, this.state), "function" == typeof e && (e = e(w({}, t), this.props)), e && w(t, e), null != e && this.__v && (r && this._sb.push(r), P(this))
    }, q.prototype.forceUpdate = function(e) {
        this.__v && (this.__e = !0, e && this.__h.push(e), P(this))
    }, q.prototype.render = C, i = [], a = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, s = function(e, r) {
        return e.__v.__b - r.__v.__b
    }, I.__r = 0, u = Math.random().toString(8), l = "__d" + u, c = "__a" + u, d = /(PointerCapture)$|Capture$/i, v = 0, p = B(!1), f = B(!0), h = 0;
    var O, G, W, Y, K = 0,
        J = [],
        X = t,
        ee = X.__b,
        re = X.__r,
        te = X.diffed,
        ne = X.__c,
        ie = X.unmount,
        oe = X.__;

    function ae(e, r) {
        X.__h && X.__h(G, e, K || r), K = 0;
        var t = G.__H || (G.__H = {
            __: [],
            __h: []
        });
        return e >= t.__.length && t.__.push({}), t.__[e]
    }

    function se(e) {
        return K = 1,
            function(e, r, t) {
                var n = ae(O++, 2);
                if (n.t = e, !n.__c && (n.__ = [ge(void 0, r), function(e) {
                        var r = n.__N ? n.__N[0] : n.__[0],
                            t = n.t(r, e);
                        r !== t && (n.__N = [t, n.__[1]], n.__c.setState({}))
                    }], n.__c = G, !G.__f)) {
                    var i = function(e, r, t) {
                        if (!n.__c.__H) return !0;
                        var i = n.__c.__H.__.filter((function(e) {
                            return e.__c
                        }));
                        if (i.every((function(e) {
                                return !e.__N
                            }))) return !o || o.call(this, e, r, t);
                        var a = n.__c.props !== e;
                        return i.some((function(e) {
                            if (e.__N) {
                                var r = e.__[0];
                                e.__ = e.__N, e.__N = void 0, r !== e.__[0] && (a = !0)
                            }
                        })), o && o.call(this, e, r, t) || a
                    };
                    G.__f = !0;
                    var o = G.shouldComponentUpdate,
                        a = G.componentWillUpdate;
                    G.componentWillUpdate = function(e, r, t) {
                        if (this.__e) {
                            var n = o;
                            o = void 0, i(e, r, t), o = n
                        }
                        a && a.call(this, e, r, t)
                    }, G.shouldComponentUpdate = i
                }
                return n.__N || n.__
            }(ge, e)
    }

    function ue(e, r) {
        var t = ae(O++, 3);
        !X.__s && me(t.__H, r) && (t.__ = e, t.u = r, G.__H.__h.push(t))
    }

    function le(e) {
        return K = 5, ce((function() {
            return {
                current: e
            }
        }), [])
    }

    function ce(e, r) {
        var t = ae(O++, 7);
        return me(t.__H, r) && (t.__ = e(), t.__H = r, t.__h = e), t.__
    }

    function de(e) {
        var r = G.context[e.__c],
            t = ae(O++, 9);
        return t.c = e, r ? (null == t.__ && (t.__ = !0, r.sub(G)), r.props.value) : e.__
    }

    function ve() {
        for (var e; e = J.shift();) {
            var r = e.__H;
            if (e.__P && r) try {
                r.__h.some(he), r.__h.some(ye), r.__h = []
            } catch (t) {
                r.__h = [], X.__e(t, e.__v)
            }
        }
    }
    X.__b = function(e) {
        G = null, ee && ee(e)
    }, X.__ = function(e, r) {
        e && r.__k && r.__k.__m && (e.__m = r.__k.__m), oe && oe(e, r)
    }, X.__r = function(e) {
        re && re(e), O = 0;
        var r = (G = e.__c).__H;
        r && (W === G ? (r.__h = [], G.__h = [], r.__.some((function(e) {
            e.__N && (e.__ = e.__N), e.u = e.__N = void 0
        }))) : (r.__h.some(he), r.__h.some(ye), r.__h = [], O = 0)), W = G
    }, X.diffed = function(e) {
        te && te(e);
        var r = e.__c;
        r && r.__H && (r.__H.__h.length && (1 !== J.push(r) && Y === X.requestAnimationFrame || ((Y = X.requestAnimationFrame) || fe)(ve)), r.__H.__.some((function(e) {
            e.u && (e.__H = e.u), e.u = void 0
        }))), W = G = null
    }, X.__c = function(e, r) {
        r.some((function(e) {
            try {
                e.__h.some(he), e.__h = e.__h.filter((function(e) {
                    return !e.__ || ye(e)
                }))
            } catch (t) {
                r.some((function(e) {
                    e.__h && (e.__h = [])
                })), r = [], X.__e(t, e.__v)
            }
        })), ne && ne(e, r)
    }, X.unmount = function(e) {
        ie && ie(e);
        var r, t = e.__c;
        t && t.__H && (t.__H.__.some((function(e) {
            try {
                he(e)
            } catch (e) {
                r = e
            }
        })), t.__H = void 0, r && X.__e(r, t.__v))
    };
    var pe = "function" == typeof requestAnimationFrame;

    function fe(e) {
        var r, t = function() {
                clearTimeout(n), pe && cancelAnimationFrame(r), setTimeout(e)
            },
            n = setTimeout(t, 35);
        pe && (r = requestAnimationFrame(t))
    }

    function he(e) {
        var r = G,
            t = e.__c;
        "function" == typeof t && (e.__c = void 0, t()), G = r
    }

    function ye(e) {
        var r = G;
        e.__c = e.__(), G = r
    }

    function me(e, r) {
        return !e || e.length !== r.length || r.some((function(r, t) {
            return r !== e[t]
        }))
    }

    function ge(e, r) {
        return "function" == typeof r ? r(e) : r
    }
    var be = {
            Tab: "tab",
            Selector: "selector"
        },
        we = {
            TopLeft: "top_left",
            TopRight: "top_right",
            TopCenter: "top_center",
            MiddleLeft: "middle_left",
            MiddleRight: "middle_right",
            MiddleCenter: "middle_center",
            Left: "left",
            Center: "center",
            Right: "right",
            NextToTrigger: "next_to_trigger"
        },
        xe = {
            Top: "top",
            Left: "left",
            Right: "right",
            Bottom: "bottom"
        },
        ke = {
            Popover: "popover",
            API: "api",
            Widget: "widget",
            ExternalSurvey: "external_survey"
        },
        Se = {
            Open: "open",
            MultipleChoice: "multiple_choice",
            SingleChoice: "single_choice",
            Rating: "rating",
            Link: "link"
        },
        Ce = {
            End: "end",
            ResponseBased: "response_based",
            SpecificQuestion: "specific_question"
        },
        qe = "always",
        _e = {
            SHOWN: "survey shown",
            DISMISSED: "survey dismissed",
            SENT: "survey sent",
            ABANDONED: "survey abandoned"
        },
        Te = {
            SURVEY_ID: "$survey_id",
            SURVEY_NAME: "$survey_name",
            SURVEY_ITERATION: "$survey_iteration",
            SURVEY_ITERATION_START_DATE: "$survey_iteration_start_date",
            SURVEY_PARTIALLY_COMPLETED: "$survey_partially_completed",
            SURVEY_SUBMISSION_ID: "$survey_submission_id",
            SURVEY_COMPLETED: "$survey_completed",
            SURVEY_LANGUAGE: "$survey_language"
        },
        Pe = function(e) {
            return e.MinLength = "min_length", e.MaxLength = "max_length", e
        }({}),
        Ie = {}.toString,
        Me = Array.isArray || function(e) {
            return "[object Array]" === Ie.call(e)
        },
        Le = e => "function" == typeof e,
        Ne = e => void 0 === e,
        He = e => "[object String]" == Ie.call(e),
        Ee = e => null === e,
        Ve = e => Ne(e) || Ee(e),
        Be = e => "[object Number]" == Ie.call(e) && e == e,
        De = "Mobile",
        Ae = "Android",
        Ze = "Tablet",
        Re = Ae + " " + Ze,
        Fe = "iPad",
        je = "Apple Watch",
        Qe = "BlackBerry",
        Ue = "Nintendo",
        ze = "PlayStation",
        Oe = "Xbox",
        $e = "Windows Phone",
        Ge = "Nokia",
        We = "Ouya",
        Ye = "Generic",
        Ke = Ye + " " + De.toLowerCase(),
        Je = Ye + " " + Ze.toLowerCase(),
        Xe = new RegExp(Oe, "i"),
        er = new RegExp(ze + " \\w+", "i"),
        rr = new RegExp(Ue + " \\w+", "i"),
        tr = new RegExp(Qe + "|PlayBook|BB10", "i");

    function nr(e, r) {
        if (e) {
            var t = e.find((e => e.type === r));
            return null == t ? void 0 : t.value
        }
    }
    var ir = "undefined" != typeof window ? window : void 0,
        or = "undefined" != typeof globalThis ? globalThis : ir;
    "undefined" == typeof self && (or.self = or), "undefined" == typeof File && (or.File = function() {});
    var ar = null == or ? void 0 : or.navigator,
        sr = null == or ? void 0 : or.document;
    null != or && or.XMLHttpRequest && new or.XMLHttpRequest;
    var ur = null == ar ? void 0 : ar.userAgent,
        lr = null != ir ? ir : {},
        cr = function(e, r) {
            var {
                debugEnabled: t
            } = void 0 === r ? {} : r, n = {
                k(r) {
                    if (ir && (lr.POSTHOG_DEBUG || t) && !Ne(ir.console) && ir.console) {
                        for (var n = ("__rrweb_original__" in ir.console[r] ? ir.console[r].__rrweb_original__ : ir.console[r]), i = arguments.length, o = new Array(i > 1 ? i - 1 : 0), a = 1; i > a; a++) o[a - 1] = arguments[a];
                        n(e, ...o)
                    }
                },
                debug() {
                    for (var e = arguments.length, r = new Array(e), t = 0; e > t; t++) r[t] = arguments[t];
                    n.k("debug", ...r)
                },
                info() {
                    for (var e = arguments.length, r = new Array(e), t = 0; e > t; t++) r[t] = arguments[t];
                    n.k("log", ...r)
                },
                warn() {
                    for (var e = arguments.length, r = new Array(e), t = 0; e > t; t++) r[t] = arguments[t];
                    n.k("warn", ...r)
                },
                error() {
                    for (var e = arguments.length, r = new Array(e), t = 0; e > t; t++) r[t] = arguments[t];
                    n.k("error", ...r)
                },
                critical() {
                    for (var r = arguments.length, t = new Array(r), n = 0; r > n; n++) t[n] = arguments[n];
                    console.error(e, ...t)
                },
                uninitializedWarning(e) {
                    n.error("You must initialize PostHog before calling " + e)
                },
                createLogger: (r, t) => cr(e + " " + r, t)
            };
            return n
        },
        dr = cr("[PostHog.js]"),
        vr = dr.createLogger;

    function pr(e, r, t, n) {
        var {
            capture: i = !1,
            passive: o = !0
        } = {};
        null == e || e.addEventListener(r, t, {
            capture: i,
            passive: o
        })
    }

    function fr(e) {
        return "$survey_response_" + e
    }

    function hr(e, r) {
        if (!r) return null;
        var t = e[fr(r)];
        return Me(t) ? [...t] : t
    }

    function yr(r, t) {
        void 0 === r && (r = {});
        var n = {};
        return t.questions.forEach((e => {
            if (!Ne(e.originalQuestionIndex)) {
                var t, i = 0 === (t = e.originalQuestionIndex) ? "$survey_response" : "$survey_response_" + t,
                    o = hr(r, e.id);
                Ne(o) || (n[i] = o)
            }
        })), e({
            $survey_questions: t.questions.map((e => ({
                id: e.id,
                question: e.question,
                response: hr(r, e.id)
            })))
        }, r, n)
    }

    function mr(e, r) {
        var t = "$survey_" + r + "/" + e.id;
        return e.current_iteration && e.current_iteration > 0 && (t = "$survey_" + r + "/" + e.id + "/" + e.current_iteration), t
    }

    function gr(e) {
        return "string" == typeof e && e.trim() ? e.trim() : null
    }

    function br(e) {
        return e.toLowerCase()
    }

    function wr(e, r, t) {
        if (!e || !r) return null;
        var n = br(r),
            i = Object.keys(e).find((e => br(e) === n));
        if (i) return null == t || t.debug("Found exact translation match: " + i), i;
        if (n.includes("-")) {
            var o = n.split("-")[0],
                a = Object.keys(e).find((e => br(e) === o));
            if (a) return null == t || t.debug("Found base language translation match: " + a + " (from " + r + ")"), a
        }
        return null
    }

    function xr(r, t, n) {
        var i, o = wr(r.translations, t, n),
            a = e({}, r),
            s = !1;
        if (o) {
            var u, l = null == (u = r.translations) ? void 0 : u[o];
            l && (null == n || n.info("Applying survey-level translation for language: " + o), Ne(l.name) || (a.name = l.name, s = !0), a.appearance ? (a.appearance = e({}, a.appearance), Ne(l.thankYouMessageHeader) || (a.appearance.thankYouMessageHeader = l.thankYouMessageHeader, s = !0), Ne(l.thankYouMessageDescription) || (a.appearance.thankYouMessageDescription = l.thankYouMessageDescription, s = !0), Ne(l.thankYouMessageCloseButtonText) || (a.appearance.thankYouMessageCloseButtonText = l.thankYouMessageCloseButtonText, s = !0), Ne(l.submitButtonText) || (a.appearance.submitButtonText = l.submitButtonText, s = !0), Ne(l.backButtonText) || (a.appearance.backButtonText = l.backButtonText, s = !0)) : function(e) {
                return !(Ne(e.thankYouMessageHeader) && Ne(e.thankYouMessageDescription) && Ne(e.thankYouMessageCloseButtonText) && Ne(e.submitButtonText) && Ne(e.backButtonText))
            }(l) && (s = !0))
        }
        var c = r.questions.map((r => function(r, t, n) {
                var i, o = wr(r.translations, t, n);
                if (!o) return {
                    question: r,
                    matchedKey: null,
                    hasChanges: !1
                };
                var a = null == (i = r.translations) ? void 0 : i[o];
                if (!a) return {
                    question: r,
                    matchedKey: null,
                    hasChanges: !1
                };
                var s = e({}, r),
                    u = !1;
                return Ne(a.question) || (s.question = a.question, u = !0), Ne(a.description) || (s.description = a.description, u = !0), Ne(a.buttonText) || (s.buttonText = a.buttonText, u = !0), "link" in s && !Ne(a.link) && (s.link = a.link, u = !0), "lowerBoundLabel" in s && !Ne(a.lowerBoundLabel) && (s.lowerBoundLabel = a.lowerBoundLabel, u = !0), "upperBoundLabel" in s && !Ne(a.upperBoundLabel) && (s.upperBoundLabel = a.upperBoundLabel, u = !0), "choices" in s && function(e) {
                    return Me(e.choices)
                }(a) && (s.choices = a.choices, u = !0), {
                    question: u ? s : r,
                    matchedKey: u ? o : null,
                    hasChanges: u
                }
            }(r, t, n))),
            d = c.map((e => e.question)),
            v = c.some((e => e.hasChanges)),
            p = null;
        return o || (p = (null == (i = c.find((e => e.matchedKey))) ? void 0 : i.matchedKey) || null), v && (a.questions = d, s = !0, null == n || n.info("Applied question-level translations for language: " + t)), {
            survey: a,
            matchedKey: s ? o || p : null
        }
    }
    var kr = vr("[Surveys]"),
        Sr = "inProgressSurvey_",
        Cr = (e, r) => {
            var t = "" + e + r.id;
            return r.current_iteration && r.current_iteration > 0 && (t = "" + e + r.id + "_" + r.current_iteration), t
        },
        qr = e => Cr("seenSurvey_", e),
        _r = e => {
            try {
                var r = qr(e);
                if (localStorage.getItem(r)) return;
                localStorage.setItem(r, "true")
            } catch (e) {
                kr.error("Failed to persist survey seen state", e)
            }
        },
        Tr = [ke.Popover, ke.Widget, ke.API];
    Math.trunc || (Math.trunc = function(e) {
        return 0 > e ? Math.ceil(e) : Math.floor(e)
    }), Number.isInteger || (Number.isInteger = function(e) {
        return Be(e) && isFinite(e) && Math.floor(e) === e
    });
    class Pr {
        constructor(e) {
            if (this.bytes = e, 16 !== e.length) throw new TypeError("not 128-bit length")
        }
        static fromFieldsV7(e, r, t, n) {
            if (!Number.isInteger(e) || !Number.isInteger(r) || !Number.isInteger(t) || !Number.isInteger(n) || 0 > e || 0 > r || 0 > t || 0 > n || e > 0xffffffffffff || r > 4095 || t > 1073741823 || n > 4294967295) throw new RangeError("invalid field value");
            var i = new Uint8Array(16);
            return i[0] = e / Math.pow(2, 40), i[1] = e / Math.pow(2, 32), i[2] = e / Math.pow(2, 24), i[3] = e / Math.pow(2, 16), i[4] = e / Math.pow(2, 8), i[5] = e, i[6] = 112 | r >>> 8, i[7] = r, i[8] = 128 | t >>> 24, i[9] = t >>> 16, i[10] = t >>> 8, i[11] = t, i[12] = n >>> 24, i[13] = n >>> 16, i[14] = n >>> 8, i[15] = n, new Pr(i)
        }
        toString() {
            for (var e = "", r = 0; this.bytes.length > r; r++) e = e + (this.bytes[r] >>> 4).toString(16) + (15 & this.bytes[r]).toString(16), 3 !== r && 5 !== r && 7 !== r && 9 !== r || (e += "-");
            if (36 !== e.length) throw new Error("Invalid UUIDv7 was generated");
            return e
        }
        clone() {
            return new Pr(this.bytes.slice(0))
        }
        equals(e) {
            return 0 === this.compareTo(e)
        }
        compareTo(e) {
            for (var r = 0; 16 > r; r++) {
                var t = this.bytes[r] - e.bytes[r];
                if (0 !== t) return Math.sign(t)
            }
            return 0
        }
    }
    class Ir {
        constructor() {
            this.S = 0, this.C = 0, this.I = new Nr
        }
        generate() {
            var e = this.generateOrAbort();
            if (Ne(e)) {
                this.S = 0;
                var r = this.generateOrAbort();
                if (Ne(r)) throw new Error("Could not generate UUID after timestamp reset");
                return r
            }
            return e
        }
        generateOrAbort() {
            var e = Date.now();
            if (e > this.S) this.S = e, this.M();
            else {
                if (this.S >= e + 1e4) return;
                this.C++, this.C > 4398046511103 && (this.S++, this.M())
            }
            return Pr.fromFieldsV7(this.S, Math.trunc(this.C / Math.pow(2, 30)), this.C & Math.pow(2, 30) - 1, this.I.nextUint32())
        }
        M() {
            this.C = 1024 * this.I.nextUint32() + (1023 & this.I.nextUint32())
        }
    }
    var Mr, Lr = e => {
        if ("undefined" != typeof UUIDV7_DENY_WEAK_RNG && UUIDV7_DENY_WEAK_RNG) throw new Error("no cryptographically strong RNG available");
        for (var r = 0; e.length > r; r++) e[r] = 65536 * Math.trunc(65536 * Math.random()) + Math.trunc(65536 * Math.random());
        return e
    };
    ir && !Ne(ir.crypto) && crypto.getRandomValues && (Lr = e => crypto.getRandomValues(e));
    class Nr {
        constructor() {
            this.R = new Uint32Array(8), this.O = 1 / 0
        }
        nextUint32() {
            return this.R.length > this.O || (Lr(this.R), this.O = 0), this.R[this.O++]
        }
    }
    var Hr = () => Er().toString(),
        Er = () => (Mr || (Mr = new Ir)).generate(),
        Vr = function(e, r) {
            if (! function(e) {
                    try {
                        new RegExp(e)
                    } catch (e) {
                        return !1
                    }
                    return !0
                }(r)) return !1;
            try {
                return new RegExp(r).test(e)
            } catch (e) {
                return !1
            }
        },
        Br = {
            exact: (e, r) => r.some((r => e.some((e => r === e)))),
            is_not: (e, r) => r.every((r => e.every((e => r !== e)))),
            regex: (e, r) => r.some((r => e.some((e => Vr(r, e))))),
            not_regex: (e, r) => r.every((r => e.every((e => !Vr(r, e))))),
            icontains: (e, r) => r.map(Dr).some((r => e.map(Dr).some((e => r.includes(e))))),
            not_icontains: (e, r) => r.map(Dr).every((r => e.map(Dr).every((e => !r.includes(e))))),
            gt: (e, r) => r.some((r => {
                var t = parseFloat(r);
                return !isNaN(t) && e.some((e => t > parseFloat(e)))
            })),
            lt: (e, r) => r.some((r => {
                var t = parseFloat(r);
                return !isNaN(t) && e.some((e => t < parseFloat(e)))
            }))
        },
        Dr = e => e.toLowerCase(),
        Ar = null,
        Zr = {
            N() {
                if (!Ee(Ar)) return Ar;
                var e = !0;
                if (Ne(ir)) e = !1;
                else try {
                    var r = "__mplssupport__";
                    Zr.A(r, "xyz"), '"xyz"' !== Zr.P(r) && (e = !1), Zr.q(r)
                } catch (r) {
                    e = !1
                }
                return e || dr.error("localStorage unsupported; falling back to cookie store"), Ar = e, e
            },
            D(e) {
                dr.error("localStorage error: " + e)
            },
            P(e) {
                try {
                    return null == ir ? void 0 : ir.localStorage.getItem(e)
                } catch (e) {
                    Zr.D(e)
                }
                return null
            },
            F(e) {
                try {
                    return JSON.parse(Zr.P(e)) || {}
                } catch (e) {}
                return null
            },
            A(e, r) {
                try {
                    return null == ir || ir.localStorage.setItem(e, JSON.stringify(r)), !0
                } catch (e) {
                    Zr.D(e)
                }
                return !1
            },
            q(e) {
                try {
                    null == ir || ir.localStorage.removeItem(e)
                } catch (e) {
                    Zr.D(e)
                }
            }
        },
        Rr = vr("[Stylesheet Loader]"),
        Fr = ir,
        jr = sr,
        Qr = "#020617",
        Ur = {
            fontFamily: "inherit",
            backgroundColor: "#eeeded",
            submitButtonColor: "black",
            submitButtonTextColor: "white",
            ratingButtonColor: "white",
            ratingButtonActiveColor: "black",
            borderColor: "#c9c6c6",
            placeholder: "Start typing...",
            whiteLabel: !1,
            displayThankYouMessage: !0,
            thankYouMessageHeader: "Thank you for your feedback!",
            position: we.Right,
            widgetType: be.Tab,
            widgetLabel: "Feedback",
            widgetColor: "black",
            zIndex: String(2147483645),
            disabledButtonOpacity: "0.6",
            maxWidth: "300px",
            textSubtleColor: "#939393",
            boxPadding: "20px 24px",
            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.15)",
            borderRadius: "10px",
            shuffleQuestions: !1,
            surveyPopupDelaySeconds: void 0,
            outlineColor: "rgba(59, 130, 246, 0.8)",
            inputBackground: "white",
            inputTextColor: Qr,
            scrollbarThumbColor: "var(--ph-survey-border-color)",
            scrollbarTrackColor: "var(--ph-survey-background-color)"
        },
        zr = [we.Center, we.Left, we.Right];

    function Or(e) {
        if (e.startsWith("#")) {
            var r = e.replace(/^#/, "");
            return /^[0-9A-Fa-f]{3}$/.test(r) && (r = r[0] + r[0] + r[1] + r[1] + r[2] + r[2]), /^[0-9A-Fa-f]{6}$/.test(r) ? "rgb(" + parseInt(r.slice(0, 2), 16) + "," + parseInt(r.slice(2, 4), 16) + "," + parseInt(r.slice(4, 6), 16) + ")" : "rgb(255, 255, 255)"
        }
        return "rgb(255, 255, 255)"
    }

    function $r(e) {
        var r;
        void 0 === e && (e = Ur.backgroundColor), "#" === e[0] && (r = Or(e)), e.startsWith("rgb") && (r = e);
        var t = {
            aliceblue: "#f0f8ff",
            antiquewhite: "#faebd7",
            aqua: "#00ffff",
            aquamarine: "#7fffd4",
            azure: "#f0ffff",
            beige: "#f5f5dc",
            bisque: "#ffe4c4",
            black: "#000000",
            blanchedalmond: "#ffebcd",
            blue: "#0000ff",
            blueviolet: "#8a2be2",
            brown: "#a52a2a",
            burlywood: "#deb887",
            cadetblue: "#5f9ea0",
            chartreuse: "#7fff00",
            chocolate: "#d2691e",
            coral: "#ff7f50",
            cornflowerblue: "#6495ed",
            cornsilk: "#fff8dc",
            crimson: "#dc143c",
            cyan: "#00ffff",
            darkblue: "#00008b",
            darkcyan: "#008b8b",
            darkgoldenrod: "#b8860b",
            darkgray: "#a9a9a9",
            darkgreen: "#006400",
            darkkhaki: "#bdb76b",
            darkmagenta: "#8b008b",
            darkolivegreen: "#556b2f",
            darkorange: "#ff8c00",
            darkorchid: "#9932cc",
            darkred: "#8b0000",
            darksalmon: "#e9967a",
            darkseagreen: "#8fbc8f",
            darkslateblue: "#483d8b",
            darkslategray: "#2f4f4f",
            darkturquoise: "#00ced1",
            darkviolet: "#9400d3",
            deeppink: "#ff1493",
            deepskyblue: "#00bfff",
            dimgray: "#696969",
            dodgerblue: "#1e90ff",
            firebrick: "#b22222",
            floralwhite: "#fffaf0",
            forestgreen: "#228b22",
            fuchsia: "#ff00ff",
            gainsboro: "#dcdcdc",
            ghostwhite: "#f8f8ff",
            gold: "#ffd700",
            goldenrod: "#daa520",
            gray: "#808080",
            green: "#008000",
            greenyellow: "#adff2f",
            honeydew: "#f0fff0",
            hotpink: "#ff69b4",
            "indianred ": "#cd5c5c",
            indigo: "#4b0082",
            ivory: "#fffff0",
            khaki: "#f0e68c",
            lavender: "#e6e6fa",
            lavenderblush: "#fff0f5",
            lawngreen: "#7cfc00",
            lemonchiffon: "#fffacd",
            lightblue: "#add8e6",
            lightcoral: "#f08080",
            lightcyan: "#e0ffff",
            lightgoldenrodyellow: "#fafad2",
            lightgrey: "#d3d3d3",
            lightgreen: "#90ee90",
            lightpink: "#ffb6c1",
            lightsalmon: "#ffa07a",
            lightseagreen: "#20b2aa",
            lightskyblue: "#87cefa",
            lightslategray: "#778899",
            lightsteelblue: "#b0c4de",
            lightyellow: "#ffffe0",
            lime: "#00ff00",
            limegreen: "#32cd32",
            linen: "#faf0e6",
            magenta: "#ff00ff",
            maroon: "#800000",
            mediumaquamarine: "#66cdaa",
            mediumblue: "#0000cd",
            mediumorchid: "#ba55d3",
            mediumpurple: "#9370d8",
            mediumseagreen: "#3cb371",
            mediumslateblue: "#7b68ee",
            mediumspringgreen: "#00fa9a",
            mediumturquoise: "#48d1cc",
            mediumvioletred: "#c71585",
            midnightblue: "#191970",
            mintcream: "#f5fffa",
            mistyrose: "#ffe4e1",
            moccasin: "#ffe4b5",
            navajowhite: "#ffdead",
            navy: "#000080",
            oldlace: "#fdf5e6",
            olive: "#808000",
            olivedrab: "#6b8e23",
            orange: "#ffa500",
            orangered: "#ff4500",
            orchid: "#da70d6",
            palegoldenrod: "#eee8aa",
            palegreen: "#98fb98",
            paleturquoise: "#afeeee",
            palevioletred: "#d87093",
            papayawhip: "#ffefd5",
            peachpuff: "#ffdab9",
            peru: "#cd853f",
            pink: "#ffc0cb",
            plum: "#dda0dd",
            powderblue: "#b0e0e6",
            purple: "#800080",
            red: "#ff0000",
            rosybrown: "#bc8f8f",
            royalblue: "#4169e1",
            saddlebrown: "#8b4513",
            salmon: "#fa8072",
            sandybrown: "#f4a460",
            seagreen: "#2e8b57",
            seashell: "#fff5ee",
            sienna: "#a0522d",
            silver: "#c0c0c0",
            skyblue: "#87ceeb",
            slateblue: "#6a5acd",
            slategray: "#708090",
            snow: "#fffafa",
            springgreen: "#00ff7f",
            steelblue: "#4682b4",
            tan: "#d2b48c",
            teal: "#008080",
            thistle: "#d8bfd8",
            tomato: "#ff6347",
            turquoise: "#40e0d0",
            violet: "#ee82ee",
            wheat: "#f5deb3",
            white: "#ffffff",
            whitesmoke: "#f5f5f5",
            yellow: "#ffff00",
            yellowgreen: "#9acd32"
        }[e.toLowerCase()];
        if (t && (r = Or(t)), !r) return Qr;
        var n = r.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d+(?:\.\d+)?))?\)$/);
        if (n) {
            var i = parseInt(n[1]),
                o = parseInt(n[2]),
                a = parseInt(n[3]);
            return Math.sqrt(i * i * .299 + o * o * .587 + a * a * .114) > 127.5 ? Qr : "white"
        }
        return Qr
    }
    var Gr = (r, t, n) => {
            var i = pt(r),
                o = jr.querySelector("." + i);
            if (o && o.shadowRoot) return {
                shadow: o.shadowRoot,
                isNewlyCreated: !1
            };
            var a = jr.createElement("div");
            ((r, t, n) => {
                var i = e({}, Ur, n),
                    o = r.style,
                    a = !zr.includes(i.position) || t === ke.Widget && (null == n ? void 0 : n.widgetType) === be.Tab;
                o.setProperty("--ph-survey-font-family", function(e) {
                    if ("inherit" === e) return "inherit";
                    var r = 'BlinkMacSystemFont, "Inter", "Segoe UI", "Roboto", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"';
                    return e ? e + ", " + r : "-apple-system, " + r
                }(i.fontFamily)), o.setProperty("--ph-survey-box-padding", i.boxPadding), o.setProperty("--ph-survey-max-width", i.maxWidth), o.setProperty("--ph-survey-z-index", i.zIndex), o.setProperty("--ph-survey-border-color", i.borderColor), a ? (o.setProperty("--ph-survey-border-radius", i.borderRadius), o.setProperty("--ph-survey-border-bottom", "1.5px solid var(--ph-survey-border-color)")) : (o.setProperty("--ph-survey-border-bottom", "none"), o.setProperty("--ph-survey-border-radius", i.borderRadius + " " + i.borderRadius + " 0 0")), o.setProperty("--ph-survey-background-color", i.backgroundColor), o.setProperty("--ph-survey-box-shadow", i.boxShadow), o.setProperty("--ph-survey-disabled-button-opacity", i.disabledButtonOpacity), o.setProperty("--ph-survey-submit-button-color", i.submitButtonColor), o.setProperty("--ph-survey-submit-button-text-color", (null == n ? void 0 : n.submitButtonTextColor) || $r(i.submitButtonColor)), o.setProperty("--ph-survey-rating-bg-color", i.ratingButtonColor), o.setProperty("--ph-survey-rating-active-bg-color", i.ratingButtonActiveColor), o.setProperty("--ph-survey-rating-active-text-color", $r(i.ratingButtonActiveColor)), o.setProperty("--ph-survey-text-primary-color", (null == n ? void 0 : n.textColor) || $r(i.backgroundColor)), o.setProperty("--ph-survey-text-subtle-color", i.textSubtleColor), o.setProperty("--ph-widget-color", i.widgetColor), o.setProperty("--ph-widget-text-color", $r(i.widgetColor)), o.setProperty("--ph-widget-z-index", i.zIndex);
                var s = (null == n ? void 0 : n.inputBackground) || (null == n ? void 0 : n.inputBackgroundColor),
                    u = s || i.inputBackground;
                s || "white" !== i.backgroundColor || (u = "#f8f8f8"), o.setProperty("--ph-survey-input-background", u);
                var l = (null == n ? void 0 : n.inputTextColor) || $r(u);
                o.setProperty("--ph-survey-input-text-color", l), o.setProperty("--ph-survey-rating-text-color", l), o.setProperty("--ph-survey-scrollbar-thumb-color", i.scrollbarThumbColor), o.setProperty("--ph-survey-scrollbar-track-color", i.scrollbarTrackColor), o.setProperty("--ph-survey-outline-color", i.outlineColor)
            })(a, r.type, r.appearance), a.className = i;
            var s = a.attachShadow({
                    mode: "open"
                }),
                u = function(e) {
                    var r = ((e, r, t) => {
                        var n, i = e.createElement("style");
                        return i.innerText = ':host{--ph-survey-font-family:-apple-system,BlinkMacSystemFont,"Inter","Segoe UI","Roboto",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";--ph-survey-box-padding:20px 24px;--ph-survey-max-width:300px;--ph-survey-z-index:2147483645;--ph-survey-border-color:#dcdcdc;--ph-survey-border-bottom:1.5px solid var(--ph-survey-border-color);--ph-survey-border-radius:10px;--ph-survey-background-color:#eeeded;--ph-survey-box-shadow:0 4px 12px rgba(0,0,0,.15);--ph-survey-submit-button-color:#000;--ph-survey-submit-button-text-color:#fff;--ph-survey-rating-bg-color:#fff;--ph-survey-rating-text-color:#020617;--ph-survey-rating-active-bg-color:#000;--ph-survey-rating-active-text-color:#fff;--ph-survey-text-primary-color:#020617;--ph-survey-text-subtle-color:#939393;--ph-widget-color:#e0a045;--ph-widget-text-color:#fff;--ph-survey-scrollbar-thumb-color:var(--ph-survey-border-color);--ph-survey-scrollbar-track-color:var(--ph-survey-background-color);--ph-survey-outline-color:rgba(59,130,246,.8);--ph-survey-input-background:#fff;--ph-survey-input-text-color:#020617;--ph-survey-disabled-button-opacity:0.6}.ph-survey{bottom:0;height:fit-content;margin:0;max-width:85%;min-width:300px;position:fixed;width:var(--ph-survey-max-width);z-index:var(--ph-survey-z-index)}.ph-survey h3,.ph-survey p{margin:0}.ph-survey *{box-sizing:border-box;color:var(--ph-survey-text-primary-color);font-family:var(--ph-survey-font-family)}.ph-survey .multiple-choice-options label,.ph-survey input[type=text],.ph-survey textarea{background:var(--ph-survey-input-background);border:1.5px solid var(--ph-survey-border-color);border-radius:4px;color:var(--ph-survey-input-text-color);padding:10px;transition:border-color .2s ease-out,box-shadow .2s ease-out,transform .15s ease-out}.ph-survey input[type=text],.ph-survey textarea{transition:border-color .2s ease-out,box-shadow .2s ease-out,transform .15s ease-out}.ph-survey input{margin:0}.ph-survey .form-submit:focus,.ph-survey .form-submit:focus-visible,.ph-survey input[type=checkbox]:focus,.ph-survey input[type=checkbox]:focus-visible,.ph-survey input[type=radio]:focus,.ph-survey input[type=radio]:focus-visible,.ph-survey input[type=text]:focus,.ph-survey input[type=text]:focus-visible,.ph-survey textarea:focus,.ph-survey textarea:focus-visible{border-color:var(--ph-survey-rating-active-bg-color);outline:1.5px solid var(--ph-survey-outline-color);outline-offset:2px}.ph-survey button:focus:not(:focus-visible),.ph-survey input[type=checkbox]:focus:not(:focus-visible),.ph-survey input[type=radio]:focus:not(:focus-visible),.ph-survey input[type=text]:focus:not(:focus-visible),.ph-survey textarea:focus:not(:focus-visible){outline:none}.ph-survey input[type=text]:hover:not(:focus),.ph-survey textarea:hover:not(:focus){border-color:var(--ph-survey-rating-active-bg-color)}@media (max-width:768px){.ph-survey input[type=text],.ph-survey textarea{font-size:1rem}}.ph-survey .form-cancel,.ph-survey .multiple-choice-options label,.ph-survey .rating-options-number,.ph-survey input[type=checkbox],.ph-survey input[type=radio]{border:1.5px solid var(--ph-survey-border-color)}.ph-survey .footer-branding,.ph-survey .form-cancel,.ph-survey .form-submit,.ph-survey .ratings-emoji,.ph-survey .ratings-number,.ph-survey input[type=checkbox],.ph-survey input[type=radio],.ph-survey label{transition:all .2s ease-out}@media (prefers-reduced-motion:no-preference){.ph-survey button:active,.ph-survey input[type=checkbox]:active,.ph-survey input[type=radio]:active,.ph-survey label:active{transition-duration:.1s}}.ph-survey-widget-tab{background:var(--ph-widget-color);border:none;border-radius:3px 3px 0 0;color:var(--ph-widget-text-color);cursor:pointer;padding:10px 12px;position:fixed;text-align:center;transition:padding .2s ease-out;z-index:var(--ph-survey-z-index)}.ph-survey-widget-tab:hover:not(.widget-tab-top){padding-bottom:16px}.ph-survey-widget-tab.widget-tab-top{border-radius:0 0 3px 3px}.ph-survey-widget-tab.widget-tab-top:hover{padding-top:16px}@keyframes ph-survey-fade-in{0%{opacity:0}to{opacity:1}}.survey-box{gap:16px}.bottom-section,.survey-box{display:flex;flex-direction:column}.bottom-section{gap:8px}.thank-you-message-header~.bottom-section{padding-top:16px}.question-container,.thank-you-message{display:flex;flex-direction:column;gap:8px}.survey-question{font-size:14px;font-weight:500}.survey-question-description{font-size:13px;opacity:.8;padding-top:4px}.survey-question-description,.thank-you-message-body{word-wrap:break-word;overflow-wrap:break-word}:is(.survey-question-description,.thank-you-message-body) embed,:is(.survey-question-description,.thank-you-message-body) iframe,:is(.survey-question-description,.thank-you-message-body) img,:is(.survey-question-description,.thank-you-message-body) object,:is(.survey-question-description,.thank-you-message-body) video{height:auto;max-width:100%}:is(.survey-question-description,.thank-you-message-body) svg{height:auto;max-width:100%}.question-textarea-wrapper{display:flex;flex-direction:column}.survey-form{animation:ph-survey-fade-in .3s ease-out forwards}.survey-form,.thank-you-message{background:var(--ph-survey-background-color);border:1.5px solid var(--ph-survey-border-color);border-bottom:var(--ph-survey-border-bottom);border-radius:var(--ph-survey-border-radius);box-shadow:var(--ph-survey-box-shadow);margin:0;padding:var(--ph-survey-box-padding);position:relative;text-align:left;width:100%;z-index:var(--ph-survey-z-index)}.survey-form input[type=text],.survey-form textarea{min-width:100%}:is(.survey-form textarea):focus,:is(.survey-form textarea):focus-visible{box-shadow:0 4px 12px rgba(0,0,0,.08)}:is(.survey-form textarea):focus:not(:focus-visible){box-shadow:none}:is(.survey-box .question-header--empty)~.multiple-choice-options,:is(.survey-box .question-header--empty)~textarea{margin-top:0}.multiple-choice-options{border:none;display:flex;flex-direction:column;font-size:14px;gap:8px;margin:0;padding:1px 0}.multiple-choice-options .response-choice,.multiple-choice-options label{align-items:center;color:inherit;display:flex;gap:8px}.multiple-choice-options label{cursor:pointer;font-size:13px}:is(.multiple-choice-options label):hover:not(:has(input:checked)){border-color:var(--ph-survey-text-subtle-color);box-shadow:0 2px 8px rgba(0,0,0,.08)}:is(.multiple-choice-options label):has(input:checked){border-color:var(--ph-survey-rating-active-bg-color);box-shadow:0 1px 4px rgba(0,0,0,.05)}.choice-option-open:is(.multiple-choice-options label){flex-wrap:wrap}:is(.multiple-choice-options label) span{color:inherit}.multiple-choice-options input[type=checkbox],.multiple-choice-options input[type=radio]{appearance:none;-webkit-appearance:none;-moz-appearance:none;background:var(--ph-survey-input-background);border-radius:3px;cursor:pointer;flex-shrink:0;height:1rem;position:relative;transition:all .2s cubic-bezier(.4,0,.2,1),transform .15s ease-out;width:1rem;z-index:1}:is(.multiple-choice-options input[type=checkbox],.multiple-choice-options input[type=radio]):focus{transform:scale(1.05)}:is(.multiple-choice-options input[type=checkbox],.multiple-choice-options input[type=radio]):hover{border-color:var(--ph-survey-rating-active-bg-color);transform:scale(1.05)}:is(.multiple-choice-options input[type=checkbox],.multiple-choice-options input[type=radio]):active{transform:scale(.95)}:is(.multiple-choice-options input[type=checkbox],.multiple-choice-options input[type=radio]):checked{background:var(--ph-survey-rating-active-bg-color);border-color:var(--ph-survey-rating-active-bg-color);transform:scale(1)}:is(.multiple-choice-options input[type=checkbox],.multiple-choice-options input[type=radio]):checked:hover{transform:scale(1.05)}.multiple-choice-options input[type=checkbox]:checked:after{animation:ph-survey-checkmark-reveal .2s ease-out .1s forwards;border:solid var(--ph-survey-rating-active-text-color);border-width:0 2px 2px 0;height:8px;left:4px;transform:rotate(45deg) scale(0);width:4px}.multiple-choice-options input[type=radio]:checked:after{animation:ph-survey-radio-reveal .15s ease-out .05s forwards;background:var(--ph-survey-rating-active-text-color);border-radius:50%;height:6px;left:5px;top:5px;transform:scale(0);width:6px}.multiple-choice-options input[type=checkbox]:checked:after,.multiple-choice-options input[type=radio]:checked:after{box-sizing:content-box;content:"";position:absolute}.multiple-choice-options input[type=radio]{border-radius:50%}.multiple-choice-options input[type=radio]:checked{border:none}:is(.multiple-choice-options input[type=checkbox]:checked,.multiple-choice-options input[type=radio]:checked)~*{font-weight:700}:is(:is(.multiple-choice-options .choice-option-open) input[type=text])::placeholder{color:var(--ph-survey-text-subtle-color);font-weight:400}.rating-options-emoji{display:flex;justify-content:space-between}.rating-options-emoji-2{justify-content:space-around}.ratings-emoji{background-color:transparent;border:none;font-size:16px;opacity:.5;padding:0}.ratings-emoji:hover{cursor:pointer;opacity:1;transform:scale(1.15)}.ratings-emoji.rating-active{opacity:1}.ratings-emoji svg{fill:var(--ph-survey-text-primary-color);transition:fill .2s ease-out}.rating-options-number{border-radius:6px;display:grid;grid-auto-columns:1fr;grid-auto-flow:column;overflow:hidden}.rating-options-number .ratings-number{border:none;border-right:1px solid var(--ph-survey-border-color);color:var(--ph-survey-rating-text-color);cursor:pointer;font-weight:700;text-align:center}:is(.rating-options-number .ratings-number):last-of-type{border-right:0}.rating-active:is(.rating-options-number .ratings-number){background:var(--ph-survey-rating-active-bg-color);color:var(--ph-survey-rating-active-text-color)}.ratings-number{background-color:var(--ph-survey-rating-bg-color);border:none;padding:8px 0}.ratings-number .rating-active{background-color:var(--ph-survey-rating-active-bg-color)}.ratings-number{cursor:pointer}@media (hover:hover) and (pointer:fine){.ratings-number:hover:not(.rating-active){background-color:color-mix(in srgb,var(--ph-survey-rating-active-bg-color) 14%,var(--ph-survey-rating-bg-color))}}.rating-text{font-size:11px;justify-content:space-between;opacity:.7}.form-buttons,.rating-text{display:flex;flex-direction:row}.form-buttons{gap:8px;width:100%}.form-buttons-with-back>.form-submit{flex:1 1 auto;min-width:0}.form-submit{background:var(--ph-survey-submit-button-color);border:none;border-radius:6px;box-shadow:0 2px 0 rgba(0,0,0,.045);color:var(--ph-survey-submit-button-text-color);cursor:pointer;font-weight:700;min-width:100%;padding:12px;text-align:center;user-select:none}.form-submit:not([disabled]):hover{box-shadow:0 4px 8px rgba(0,0,0,.1);transform:scale(1.02)}.form-submit:not([disabled]):active{box-shadow:0 1px 2px rgba(0,0,0,.05);transform:scale(.98)}.form-submit[disabled]{cursor:not-allowed;opacity:var(--ph-survey-disabled-button-opacity)}.form-back{background:transparent;border:1.5px solid var(--ph-survey-border-color);border-radius:6px;color:var(--ph-survey-text-primary-color);cursor:pointer;flex:0 0 auto;font-weight:600;padding:12px 16px;text-align:center;user-select:none}.form-back:hover{transform:scale(1.02)}.form-back:active{transform:scale(.98)}.validation-hint{font-size:12px;margin-top:4px;opacity:.7}.form-cancel{background:#fff;border-radius:100%;cursor:pointer;line-height:0;padding:12px;position:absolute;right:0;top:0;transform:translate(50%,-50%)}.form-cancel:hover{opacity:.7;transform:translate(50%,-50%) scale(1.1)}.footer-branding{align-items:center;display:flex;font-size:11px;font-weight:500;gap:4px;justify-content:center;opacity:.6;text-decoration:none}.footer-branding:hover{opacity:1}.footer-branding a{text-decoration:none}.thank-you-message{text-align:center}.thank-you-message-header{margin:10px 0 0}.thank-you-message-body{font-size:14px;opacity:.8}.limit-height{max-height:256px;overflow-x:hidden;overflow-y:auto;scrollbar-color:var(--ph-survey-scrollbar-thumb-color) var(--ph-survey-scrollbar-track-color);scrollbar-width:thin}.limit-height::-webkit-scrollbar{width:8px}.limit-height::-webkit-scrollbar-track{background:var(--ph-survey-scrollbar-track-color);border-radius:4px}.limit-height::-webkit-scrollbar-thumb{background-color:var(--ph-survey-scrollbar-thumb-color);border:2px solid var(--ph-survey-scrollbar-track-color);border-radius:4px}:is(.limit-height::-webkit-scrollbar-thumb):hover{background-color:var(--ph-survey-text-subtle-color)}.sr-only{clip:rect(0,0,0,0);border:0;height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;white-space:nowrap;width:1px}@media (prefers-reduced-motion:reduce){.ph-survey *{animation-duration:.01ms!important;animation-iteration-count:1!important;scroll-behavior:auto!important;transition-duration:.01ms!important}}@keyframes ph-survey-checkmark-reveal{0%{opacity:0;transform:rotate(45deg) scale(0)}50%{opacity:1;transform:rotate(45deg) scale(1.2)}to{opacity:1;transform:rotate(45deg) scale(1)}}@keyframes ph-survey-radio-reveal{0%{opacity:0;transform:scale(0)}50%{opacity:1;transform:scale(1.3)}to{opacity:1;transform:scale(1)}}', null != t && null != (n = t.config) && n.prepare_external_dependency_stylesheet && (i = t.config.prepare_external_dependency_stylesheet(i)), i || (Rr.error("prepare_external_dependency_stylesheet returned null"), null)
                    })(jr, 0, e);
                    return null == r || r.setAttribute("data-ph-survey-style", "true"), r
                }(t);
            if (u) {
                var l = s.querySelector("style");
                l && s.removeChild(l), s.appendChild(u)
            }
            return jr.body.appendChild(a), {
                shadow: s,
                isNewlyCreated: !0
            }
        },
        Wr = r => {
            var {
                responses: t,
                survey: n,
                surveySubmissionId: i,
                posthog: o,
                isSurveyCompleted: a,
                properties: s,
                surveyLanguage: u
            } = r;
            o ? (_r(n), o.capture(_e.SENT, e({
                [Te.SURVEY_NAME]: n.name,
                [Te.SURVEY_ID]: n.id,
                [Te.SURVEY_ITERATION]: n.current_iteration,
                [Te.SURVEY_ITERATION_START_DATE]: n.current_iteration_start_date,
                [Te.SURVEY_SUBMISSION_ID]: i,
                [Te.SURVEY_COMPLETED]: a
            }, u && {
                [Te.SURVEY_LANGUAGE]: u
            }, {
                sessionRecordingUrl: null == o.get_session_replay_url ? void 0 : o.get_session_replay_url()
            }, yr(t, n), s, {
                $set: {
                    [mr(n, "responded")]: !0
                }
            })), a && (Fr.dispatchEvent(new CustomEvent("PHSurveySent", {
                detail: {
                    surveyId: n.id
                }
            })), vt(n))) : kr.error("[survey sent] event not captured, PostHog instance not found.")
        },
        Yr = (r, t, n) => {
            return e({
                [Te.SURVEY_NAME]: r.name,
                [Te.SURVEY_ID]: r.id,
                [Te.SURVEY_ITERATION]: r.current_iteration,
                [Te.SURVEY_ITERATION_START_DATE]: r.current_iteration_start_date,
                [Te.SURVEY_PARTIALLY_COMPLETED]: (i = null == t ? void 0 : t.responses, void 0 === i && (i = {}), Object.values(i).some((e => !Ve(e))))
            }, (null == t ? void 0 : t.surveyLanguage) && {
                [Te.SURVEY_LANGUAGE]: t.surveyLanguage
            }, {
                sessionRecordingUrl: null == n.get_session_replay_url ? void 0 : n.get_session_replay_url(),
                [Te.SURVEY_SUBMISSION_ID]: null == t ? void 0 : t.surveySubmissionId
            }, yr(null == t ? void 0 : t.responses, r));
            var i
        },
        Kr = (r, t, n, i) => {
            if (t) {
                if (!n) {
                    var o = ct(r);
                    t.capture(_e.DISMISSED, e({}, Yr(r, o, t), i && {
                        [Te.SURVEY_LANGUAGE]: i
                    }, {
                        $set: {
                            [mr(r, "dismissed")]: !0
                        }
                    })), vt(r), _r(r), Fr.dispatchEvent(new CustomEvent("PHSurveyClosed", {
                        detail: {
                            surveyId: r.id
                        }
                    }))
                }
            } else kr.error("[survey dismissed] event not captured, PostHog instance not found.")
        },
        Jr = (e, r) => {
            if (r) {
                var t = (e => Cr("abandonedSurvey_", e))(e);
                try {
                    if ("true" === localStorage.getItem(t)) return
                } catch (e) {
                    return
                }
                var n = ct(e);
                if (n) {
                    try {
                        localStorage.setItem(t, "true")
                    } catch (e) {}
                    r.capture(_e.ABANDONED, Yr(e, n, r), {
                        transport: "sendBeacon"
                    })
                }
            } else kr.error("[survey abandoned] event not captured, PostHog instance not found.")
        },
        Xr = e => e.map((e => ({
            sort: Math.floor(10 * Math.random()),
            value: e
        }))).sort(((e, r) => e.sort - r.sort)).map((e => e.value)),
        et = (e, r) => e.length === r.length && e.every(((e, t) => e === r[t])) ? r.reverse() : r,
        rt = e => e.appearance && e.appearance.shuffleQuestions && !e.enable_partial_responses ? et(e.questions, Xr(e.questions)) : e.questions,
        tt = e => {
            var r;
            return !(null == (r = e.conditions) || null == (r = r.events) || !r.repeatedActivation || !(e => {
                var r, t;
                return null != (null == (r = e.conditions) || null == (r = r.events) || null == (r = r.values) ? void 0 : r.length) && (null == (t = e.conditions) || null == (t = t.events) || null == (t = t.values) ? void 0 : t.length) > 0
            })(e)) || e.schedule === qe || dt(e)
        },
        nt = function(e) {
            function r(e) {
                var t, n;
                return this.getChildContext || (t = new Set, (n = {})[r.__c] = this, this.getChildContext = function() {
                    return n
                }, this.componentWillUnmount = function() {
                    t = null
                }, this.shouldComponentUpdate = function(e) {
                    this.props.value != e.value && t.forEach((function(e) {
                        e.__e = !0, P(e)
                    }))
                }, this.sub = function(e) {
                    t.add(e);
                    var r = e.componentWillUnmount;
                    e.componentWillUnmount = function() {
                        t && t.delete(e), r && r.call(e)
                    }
                }), e.children
            }
            return r.__c = "__cC" + h++, r.__ = e, r.Provider = r.__l = (r.Consumer = function(e, r) {
                return e.children(r)
            }).contextType = r, r
        }({
            isPreviewMode: !1,
            previewPageIndex: 0,
            onPopupSurveyDismissed() {},
            isPopup: !0,
            onPreviewSubmit() {},
            onPreviewBack() {},
            surveySubmissionId: "",
            properties: void 0,
            surveyLanguage: null
        }),
        it = () => de(nt),
        ot = e => {
            var {
                component: t,
                children: n,
                renderAsHtml: i,
                style: o
            } = e;
            return function(e, t, n) {
                var i, o, a, s, u = w({}, e.props);
                for (a in e.type && e.type.defaultProps && (s = e.type.defaultProps), t) "key" == a ? i = t[a] : "ref" == a ? o = t[a] : u[a] = void 0 === t[a] && null != s ? s[a] : t[a];
                return arguments.length > 2 && (u.children = arguments.length > 3 ? r.call(arguments, 2) : n), S(e.type, u, i || e.key, o || e.ref, null)
            }(t, i ? {
                dangerouslySetInnerHTML: {
                    __html: n
                },
                style: o
            } : {
                children: n,
                style: o
            })
        };

    function at(e) {
        var r, t, n;
        if (null == (r = e.conditions) || !r.url) return !0;
        var i = null == Fr || null == (t = Fr.location) ? void 0 : t.href;
        if (!i) return !1;
        var o = [e.conditions.url],
            a = function(e) {
                return null != e ? e : "icontains"
            }(null == (n = e.conditions) ? void 0 : n.urlMatchType);
        return Br[a](o, [i])
    }

    function st(e) {
        var r, t;
        return function(e, r) {
            var t, n, i;
            if (!e || 0 === e.length) return !0;
            if (!ur) return !1;
            var o, a, s, u, l, c, d = (o = {
                userAgentDataPlatform: null == ar || null == (t = ar.userAgentData) ? void 0 : t.platform,
                maxTouchPoints: null == ar ? void 0 : ar.maxTouchPoints,
                screenWidth: null == ir || null == (n = ir.screen) ? void 0 : n.width,
                screenHeight: null == ir || null == (i = ir.screen) ? void 0 : i.height,
                devicePixelRatio: null == ir ? void 0 : ir.devicePixelRatio
            }, (c = function(e) {
                return rr.test(e) ? Ue : er.test(e) ? ze : Xe.test(e) ? Oe : new RegExp(We, "i").test(e) ? We : new RegExp("(" + $e + "|WPDesktop)", "i").test(e) ? $e : /iPad/.test(e) ? Fe : /iPod/.test(e) ? "iPod Touch" : /iPhone/.test(e) ? "iPhone" : /(watch)(?: ?os[,/]|\d,\d\/)[\d.]+/i.test(e) ? je : tr.test(e) ? Qe : /(kobo)\s(ereader|touch)/i.test(e) ? "Kobo" : new RegExp(Ge, "i").test(e) ? Ge : /(kf[a-z]{2}wi|aeo[c-r]{2})( bui|\))/i.test(e) || /(kf[a-z]+)( bui|\)).+silk\//i.test(e) ? "Kindle Fire" : /(Android|ZTE)/i.test(e) ? new RegExp(De).test(e) && !/(9138B|TB782B|Nexus [97]|pixel c|HUAWEISHT|BTV|noble nook|smart ultra 6)/i.test(e) || /pixel[\daxl ]{1,6}/i.test(e) && !/pixel c/i.test(e) || /(huaweimed-al00|tah-|APA|SM-G92|i980|zte|U304AA)/i.test(e) || /lmy47v/i.test(e) && !/QTAQZ3/i.test(e) ? Ae : Re : new RegExp("(pda|" + De + ")", "i").test(e) ? Ke : new RegExp(Ze, "i").test(e) && !new RegExp(Ze + " pc", "i").test(e) ? Je : ""
            }(ur)) === Fe || c === Re || "Kobo" === c || "Kindle Fire" === c || c === Je ? Ze : c === Ue || c === Oe || c === ze || c === We ? "Console" : c === je ? "Wearable" : c ? De : "Android" === (null == o ? void 0 : o.userAgentDataPlatform) && (null !== (a = null == o ? void 0 : o.maxTouchPoints) && void 0 !== a ? a : 0) > 0 ? 600 > Math.min(null !== (s = null == o ? void 0 : o.screenWidth) && void 0 !== s ? s : 0, null !== (u = null == o ? void 0 : o.screenHeight) && void 0 !== u ? u : 0) / (null !== (l = null == o ? void 0 : o.devicePixelRatio) && void 0 !== l ? l : 1) ? De : Ze : "Desktop");
            return Br[null != r ? r : "icontains"](e, [d])
        }(null == (r = e.conditions) ? void 0 : r.deviceTypes, null == (t = e.conditions) ? void 0 : t.deviceTypesMatchType)
    }
    var ut = e => {
            var r = "" + Sr + e.id;
            return e.current_iteration && e.current_iteration > 0 && (r = "" + Sr + e.id + "_" + e.current_iteration), r
        },
        lt = (e, r) => {
            try {
                localStorage.setItem(ut(e), JSON.stringify(r))
            } catch (e) {
                kr.error("Error setting in-progress survey state in localStorage", e)
            }
        },
        ct = e => {
            try {
                var r = localStorage.getItem(ut(e));
                if (r) return JSON.parse(r)
            } catch (e) {
                kr.error("Error getting in-progress survey state from localStorage", e)
            }
            return null
        },
        dt = e => {
            var r = ct(e);
            return !Ve(null == r ? void 0 : r.surveySubmissionId)
        },
        vt = e => {
            try {
                localStorage.removeItem(ut(e))
            } catch (e) {
                kr.error("Error clearing in-progress survey state from localStorage", e)
            }
        };

    function pt(e, r) {
        void 0 === r && (r = !1);
        var t = "PostHogSurvey-" + e.id;
        return r ? "." + t : t
    }

    function ft(e, r, t) {
        if (void 0 === r && (r = we.Right), e === ke.ExternalSurvey) return {};
        switch (r) {
            case we.TopLeft:
                return {
                    top: "0",
                    left: "0",
                    transform: "translate(30px, 30px)"
                };
            case we.TopRight:
                return {
                    top: "0",
                    right: "0",
                    transform: "translate(-30px, 30px)"
                };
            case we.TopCenter:
                return {
                    top: "0",
                    left: "50%",
                    transform: "translate(-50%, 30px)"
                };
            case we.MiddleLeft:
                return {
                    top: "50%",
                    left: "0",
                    transform: "translate(30px, -50%)"
                };
            case we.MiddleRight:
                return {
                    top: "50%",
                    right: "0",
                    transform: "translate(-30px, -50%)"
                };
            case we.MiddleCenter:
                return {
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)"
                };
            case we.Left:
                return {
                    left: "30px"
                };
            case we.Center:
                return {
                    left: "50%",
                    transform: "translateX(-50%)"
                };
            default:
                return {
                    right: e === ke.Widget && t === be.Tab ? "60px" : "30px"
                }
        }
    }
    var ht = 0;

    function yt(e, r, n, i, o, a) {
        r || (r = {});
        var s, u, l = r;
        if ("ref" in l)
            for (u in l = {}, r) "ref" == u ? s = r[u] : l[u] = r[u];
        var c = {
            type: e,
            props: l,
            key: n,
            ref: s,
            __k: null,
            __: null,
            __b: 0,
            __e: null,
            __c: null,
            constructor: void 0,
            __v: --ht,
            __i: -1,
            __u: 0,
            __source: o,
            __self: a
        };
        if ("function" == typeof e && (s = e.defaultProps))
            for (u in s) void 0 === l[u] && (l[u] = s[u]);
        return t.vnode && t.vnode(c), c
    }
    var mt = yt("svg", {
            className: "emoji-svg",
            xmlns: "http://www.w3.org/2000/svg",
            height: "48",
            viewBox: "0 -960 960 960",
            width: "48",
            children: yt("path", {
                d: "M626-533q22.5 0 38.25-15.75T680-587q0-22.5-15.75-38.25T626-641q-22.5 0-38.25 15.75T572-587q0 22.5 15.75 38.25T626-533Zm-292 0q22.5 0 38.25-15.75T388-587q0-22.5-15.75-38.25T334-641q-22.5 0-38.25 15.75T280-587q0 22.5 15.75 38.25T334-533Zm146 272q66 0 121.5-35.5T682-393h-52q-23 40-63 61.5T480.5-310q-46.5 0-87-21T331-393h-53q26 61 81 96.5T480-261Zm0 181q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-400Zm0 340q142.375 0 241.188-98.812Q820-337.625 820-480t-98.812-241.188Q622.375-820 480-820t-241.188 98.812Q140-622.375 140-480t98.812 241.188Q337.625-140 480-140Z"
            })
        }),
        gt = yt("svg", {
            className: "emoji-svg",
            xmlns: "http://www.w3.org/2000/svg",
            height: "48",
            viewBox: "0 -960 960 960",
            width: "48",
            children: yt("path", {
                d: "M626-533q22.5 0 38.25-15.75T680-587q0-22.5-15.75-38.25T626-641q-22.5 0-38.25 15.75T572-587q0 22.5 15.75 38.25T626-533Zm-292 0q22.5 0 38.25-15.75T388-587q0-22.5-15.75-38.25T334-641q-22.5 0-38.25 15.75T280-587q0 22.5 15.75 38.25T334-533Zm20 194h253v-49H354v49ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-400Zm0 340q142.375 0 241.188-98.812Q820-337.625 820-480t-98.812-241.188Q622.375-820 480-820t-241.188 98.812Q140-622.375 140-480t98.812 241.188Q337.625-140 480-140Z"
            })
        }),
        bt = yt("svg", {
            className: "emoji-svg",
            xmlns: "http://www.w3.org/2000/svg",
            height: "48",
            viewBox: "0 -960 960 960",
            width: "48",
            children: yt("path", {
                d: "M626-533q22.5 0 38.25-15.75T680-587q0-22.5-15.75-38.25T626-641q-22.5 0-38.25 15.75T572-587q0 22.5 15.75 38.25T626-533Zm-292 0q22.5 0 38.25-15.75T388-587q0-22.5-15.75-38.25T334-641q-22.5 0-38.25 15.75T280-587q0 22.5 15.75 38.25T334-533Zm146.174 116Q413-417 358.5-379.5T278-280h53q22-42 62.173-65t87.5-23Q528-368 567.5-344.5T630-280h52q-25-63-79.826-100-54.826-37-122-37ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-400Zm0 340q142.375 0 241.188-98.812Q820-337.625 820-480t-98.812-241.188Q622.375-820 480-820t-241.188 98.812Q140-622.375 140-480t98.812 241.188Q337.625-140 480-140Z"
            })
        }),
        wt = yt("svg", {
            className: "emoji-svg",
            xmlns: "http://www.w3.org/2000/svg",
            height: "48",
            viewBox: "0 -960 960 960",
            width: "48",
            children: yt("path", {
                d: "M480-417q-67 0-121.5 37.5T278-280h404q-25-63-80-100t-122-37Zm-183-72 50-45 45 45 31-36-45-45 45-45-31-36-45 45-50-45-31 36 45 45-45 45 31 36Zm272 0 44-45 51 45 31-36-45-45 45-45-31-36-51 45-44-45-31 36 44 45-44 45 31 36ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-400Zm0 340q142 0 241-99t99-241q0-142-99-241t-241-99q-142 0-241 99t-99 241q0 142 99 241t241 99Z"
            })
        }),
        xt = yt("svg", {
            className: "emoji-svg",
            xmlns: "http://www.w3.org/2000/svg",
            height: "48",
            viewBox: "0 -960 960 960",
            width: "48",
            children: yt("path", {
                d: "M479.504-261Q537-261 585.5-287q48.5-26 78.5-72.4 6-11.6-.75-22.6-6.75-11-20.25-11H316.918Q303-393 296.5-382t-.5 22.6q30 46.4 78.5 72.4 48.5 26 105.004 26ZM347-578l27 27q7.636 8 17.818 8Q402-543 410-551q8-8 8-18t-8-18l-42-42q-8.8-9-20.9-9-12.1 0-21.1 9l-42 42q-8 7.636-8 17.818Q276-559 284-551q8 8 18 8t18-8l27-27Zm267 0 27 27q7.714 8 18 8t18-8q8-7.636 8-17.818Q685-579 677-587l-42-42q-8.8-9-20.9-9-12.1 0-21.1 9l-42 42q-8 7.714-8 18t8 18q7.636 8 17.818 8Q579-543 587-551l27-27ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-400Zm0 340q142.375 0 241.188-98.812Q820-337.625 820-480t-98.812-241.188Q622.375-820 480-820t-241.188 98.812Q140-622.375 140-480t98.812 241.188Q337.625-140 480-140Z"
            })
        }),
        kt = yt("svg", {
            className: "emoji-svg",
            xmlns: "http://www.w3.org/2000/svg",
            height: "48",
            viewBox: "0 0 24 24",
            width: "48",
            children: yt("path", {
                d: "M2 20h2c.55 0 1-.45 1-1v-9c0-.55-.45-1-1-1H2v11zm19.83-7.12c.11-.25.17-.52.17-.8V11c0-1.1-.9-2-2-2h-5.5l.92-4.65c.05-.22.02-.46-.08-.66-.23-.45-.52-.86-.88-1.22L14 2 7.59 8.41C7.21 8.79 7 9.3 7 9.83v7.84C7 18.95 8.05 20 9.34 20h8.11c.7 0 1.36-.37 1.72-.97l2.66-6.15z"
            })
        }),
        St = yt("svg", {
            className: "emoji-svg",
            xmlns: "http://www.w3.org/2000/svg",
            height: "48",
            viewBox: "0 0 24 24",
            width: "48",
            children: yt("path", {
                d: "M22 4h-2c-.55 0-1 .45-1 1v9c0 .55.45 1 1 1h2V4zM2.17 11.12c-.11.25-.17.52-.17.8V13c0 1.1.9 2 2 2h5.5l-.92 4.65c-.05.22-.02.46.08.66.23.45.52.86.88 1.22L10 22l6.41-6.41c.38-.38.59-.89.59-1.42V6.34C17 5.05 15.95 4 14.66 4H6.55c-.7 0-1.36.37-1.72.97l-2.66 6.15z"
            })
        }),
        Ct = function(e) {
            var {
                fill: r = "currentColor"
            } = void 0 === e ? {} : e;
            return yt("svg", {
                width: "12",
                height: "12",
                viewBox: "0 0 12 12",
                fill: r,
                xmlns: "http://www.w3.org/2000/svg",
                "aria-labelledby": "close-survey-title-adam",
                children: [yt("title", {
                    id: "close-survey-title",
                    className: "adam-testing",
                    children: "Close survey"
                }), yt("path", {
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "M0.164752 0.164752C0.384422 -0.0549175 0.740578 -0.0549175 0.960248 0.164752L6 5.20451L11.0398 0.164752C11.2594 -0.0549175 11.6156 -0.0549175 11.8352 0.164752C12.0549 0.384422 12.0549 0.740578 11.8352 0.960248L6.79549 6L11.8352 11.0398C12.0549 11.2594 12.0549 11.6156 11.8352 11.8352C11.6156 12.0549 11.2594 12.0549 11.0398 11.8352L6 6.79549L0.960248 11.8352C0.740578 12.0549 0.384422 12.0549 0.164752 11.8352C-0.0549175 11.6156 -0.0549175 11.2594 0.164752 11.0398L5.20451 6L0.164752 0.960248C-0.0549175 0.740578 -0.0549175 0.384422 0.164752 0.164752Z",
                    fill: r
                })]
            })
        },
        qt = yt("svg", {
            width: "77",
            height: "14",
            viewBox: "0 0 77 14",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [yt("g", {
                "clip-path": "url(#clip0_2415_6911)",
                children: [yt("mask", {
                    id: "mask0_2415_6911",
                    style: {
                        maskType: "luminance"
                    },
                    maskUnits: "userSpaceOnUse",
                    x: "0",
                    y: "0",
                    width: "77",
                    height: "14",
                    children: yt("path", {
                        d: "M0.5 0H76.5V14H0.5V0Z",
                        fill: "white"
                    })
                }), yt("g", {
                    mask: "url(#mask0_2415_6911)",
                    children: [yt("path", {
                        d: "M5.77226 8.02931C5.59388 8.37329 5.08474 8.37329 4.90634 8.02931L4.4797 7.20672C4.41155 7.07535 4.41155 6.9207 4.4797 6.78933L4.90634 5.96669C5.08474 5.62276 5.59388 5.62276 5.77226 5.96669L6.19893 6.78933C6.26709 6.9207 6.26709 7.07535 6.19893 7.20672L5.77226 8.02931ZM5.77226 12.6946C5.59388 13.0386 5.08474 13.0386 4.90634 12.6946L4.4797 11.872C4.41155 11.7406 4.41155 11.586 4.4797 11.4546L4.90634 10.632C5.08474 10.288 5.59388 10.288 5.77226 10.632L6.19893 11.4546C6.26709 11.586 6.26709 11.7406 6.19893 11.872L5.77226 12.6946Z",
                        fill: "#1D4AFF"
                    }), yt("path", {
                        d: "M0.5 10.9238C0.5 10.508 1.02142 10.2998 1.32637 10.5938L3.54508 12.7327C3.85003 13.0267 3.63405 13.5294 3.20279 13.5294H0.984076C0.716728 13.5294 0.5 13.3205 0.5 13.0627V10.9238ZM0.5 8.67083C0.5 8.79459 0.551001 8.91331 0.641783 9.00081L5.19753 13.3927C5.28831 13.4802 5.41144 13.5294 5.53982 13.5294H8.0421C8.47337 13.5294 8.68936 13.0267 8.3844 12.7327L1.32637 5.92856C1.02142 5.63456 0.5 5.84278 0.5 6.25854V8.67083ZM0.5 4.00556C0.5 4.12932 0.551001 4.24802 0.641783 4.33554L10.0368 13.3927C10.1276 13.4802 10.2508 13.5294 10.3791 13.5294H12.8814C13.3127 13.5294 13.5287 13.0267 13.2237 12.7327L1.32637 1.26329C1.02142 0.969312 0.5 1.17752 0.5 1.59327V4.00556ZM5.33931 4.00556C5.33931 4.12932 5.39033 4.24802 5.4811 4.33554L14.1916 12.7327C14.4965 13.0267 15.0179 12.8185 15.0179 12.4028V9.99047C15.0179 9.86671 14.9669 9.74799 14.8762 9.66049L6.16568 1.26329C5.86071 0.969307 5.33931 1.17752 5.33931 1.59327V4.00556ZM11.005 1.26329C10.7 0.969307 10.1786 1.17752 10.1786 1.59327V4.00556C10.1786 4.12932 10.2296 4.24802 10.3204 4.33554L14.1916 8.06748C14.4965 8.36148 15.0179 8.15325 15.0179 7.7375V5.3252C15.0179 5.20144 14.9669 5.08272 14.8762 4.99522L11.005 1.26329Z",
                        fill: "#F9BD2B"
                    }), yt("path", {
                        d: "M21.0852 10.981L16.5288 6.58843C16.2238 6.29443 15.7024 6.50266 15.7024 6.91841V13.0627C15.7024 13.3205 15.9191 13.5294 16.1865 13.5294H23.2446C23.5119 13.5294 23.7287 13.3205 23.7287 13.0627V12.5032C23.7287 12.2455 23.511 12.0396 23.2459 12.0063C22.4323 11.9042 21.6713 11.546 21.0852 10.981ZM18.0252 12.0365C17.5978 12.0365 17.251 11.7021 17.251 11.2901C17.251 10.878 17.5978 10.5436 18.0252 10.5436C18.4527 10.5436 18.7996 10.878 18.7996 11.2901C18.7996 11.7021 18.4527 12.0365 18.0252 12.0365Z",
                        fill: "currentColor"
                    }), yt("path", {
                        d: "M0.5 13.0627C0.5 13.3205 0.716728 13.5294 0.984076 13.5294H3.20279C3.63405 13.5294 3.85003 13.0267 3.54508 12.7327L1.32637 10.5938C1.02142 10.2998 0.5 10.508 0.5 10.9238V13.0627ZM5.33931 5.13191L1.32637 1.26329C1.02142 0.969306 0.5 1.17752 0.5 1.59327V4.00556C0.5 4.12932 0.551001 4.24802 0.641783 4.33554L5.33931 8.86412V5.13191ZM1.32637 5.92855C1.02142 5.63455 0.5 5.84278 0.5 6.25853V8.67083C0.5 8.79459 0.551001 8.91331 0.641783 9.00081L5.33931 13.5294V9.79717L1.32637 5.92855Z",
                        fill: "#1D4AFF"
                    }), yt("path", {
                        d: "M10.1787 5.3252C10.1787 5.20144 10.1277 5.08272 10.0369 4.99522L6.16572 1.26329C5.8608 0.969306 5.33936 1.17752 5.33936 1.59327V4.00556C5.33936 4.12932 5.39037 4.24802 5.48114 4.33554L10.1787 8.86412V5.3252ZM5.33936 13.5294H8.04214C8.47341 13.5294 8.6894 13.0267 8.38443 12.7327L5.33936 9.79717V13.5294ZM5.33936 5.13191V8.67083C5.33936 8.79459 5.39037 8.91331 5.48114 9.00081L10.1787 13.5294V9.99047C10.1787 9.86671 10.1277 9.74803 10.0369 9.66049L5.33936 5.13191Z",
                        fill: "#F54E00"
                    }), yt("path", {
                        d: "M29.375 11.6667H31.3636V8.48772H33.0249C34.8499 8.48772 36.0204 7.4443 36.0204 5.83052C36.0204 4.21681 34.8499 3.17334 33.0249 3.17334H29.375V11.6667ZM31.3636 6.84972V4.81136H32.8236C33.5787 4.81136 34.0318 5.19958 34.0318 5.83052C34.0318 6.4615 33.5787 6.84972 32.8236 6.84972H31.3636ZM39.618 11.7637C41.5563 11.7637 42.9659 10.429 42.9659 8.60905C42.9659 6.78905 41.5563 5.45438 39.618 5.45438C37.6546 5.45438 36.2701 6.78905 36.2701 8.60905C36.2701 10.429 37.6546 11.7637 39.618 11.7637ZM38.1077 8.60905C38.1077 7.63838 38.7118 6.97105 39.618 6.97105C40.5116 6.97105 41.1157 7.63838 41.1157 8.60905C41.1157 9.57972 40.5116 10.2471 39.618 10.2471C38.7118 10.2471 38.1077 9.57972 38.1077 8.60905ZM46.1482 11.7637C47.6333 11.7637 48.6402 10.8658 48.6402 9.81025C48.6402 7.33505 45.2294 8.13585 45.2294 7.16518C45.2294 6.8983 45.5189 6.72843 45.9342 6.72843C46.3622 6.72843 46.8782 6.98318 47.0418 7.54132L48.527 6.94678C48.2375 6.06105 47.1677 5.45438 45.8713 5.45438C44.4743 5.45438 43.6058 6.25518 43.6058 7.21372C43.6058 9.53118 46.9663 8.88812 46.9663 9.84665C46.9663 10.1864 46.6391 10.417 46.1482 10.417C45.4434 10.417 44.9525 9.94376 44.8015 9.3735L43.3164 9.93158C43.6436 10.8537 44.6001 11.7637 46.1482 11.7637ZM53.4241 11.606L53.2982 10.0651C53.0843 10.1743 52.8074 10.2106 52.5808 10.2106C52.1278 10.2106 51.8257 9.89523 51.8257 9.34918V7.03172H53.3612V5.55145H51.8257V3.78001H49.9755V5.55145H48.9687V7.03172H49.9755V9.57972C49.9755 11.06 51.0202 11.7637 52.3921 11.7637C52.7696 11.7637 53.122 11.7031 53.4241 11.606ZM59.8749 3.17334V6.47358H56.376V3.17334H54.3874V11.6667H56.376V8.11158H59.8749V11.6667H61.8761V3.17334H59.8749ZM66.2899 11.7637C68.2281 11.7637 69.6378 10.429 69.6378 8.60905C69.6378 6.78905 68.2281 5.45438 66.2899 5.45438C64.3265 5.45438 62.942 6.78905 62.942 8.60905C62.942 10.429 64.3265 11.7637 66.2899 11.7637ZM64.7796 8.60905C64.7796 7.63838 65.3837 6.97105 66.2899 6.97105C67.1835 6.97105 67.7876 7.63838 67.7876 8.60905C67.7876 9.57972 67.1835 10.2471 66.2899 10.2471C65.3837 10.2471 64.7796 9.57972 64.7796 8.60905ZM73.2088 11.4725C73.901 11.4725 74.5177 11.242 74.845 10.8416V11.424C74.845 12.1034 74.2786 12.5767 73.4102 12.5767C72.7935 12.5767 72.2523 12.2854 72.1642 11.788L70.4776 12.0428C70.7042 13.1955 71.925 13.972 73.4102 13.972C75.361 13.972 76.6574 12.8679 76.6574 11.2298V5.55145H74.8324V6.07318C74.4926 5.69705 73.9136 5.45438 73.171 5.45438C71.409 5.45438 70.3014 6.61918 70.3014 8.46345C70.3014 10.3077 71.409 11.4725 73.2088 11.4725ZM72.1012 8.46345C72.1012 7.55345 72.655 6.97105 73.5109 6.97105C74.3793 6.97105 74.9331 7.55345 74.9331 8.46345C74.9331 9.37345 74.3793 9.95585 73.5109 9.95585C72.655 9.95585 72.1012 9.37345 72.1012 8.46345Z",
                        fill: "currentColor"
                    })]
                })]
            }), yt("defs", {
                children: yt("clipPath", {
                    id: "clip0_2415_6911",
                    children: yt("rect", {
                        width: "76",
                        height: "14",
                        fill: "white",
                        transform: "translate(0.5)"
                    })
                })
            })]
        });

    function _t(e) {
        var {
            urlParams: r
        } = e, t = r ? Object.entries(r).map((e => {
            var [r, t] = e;
            return encodeURIComponent(r) + "=" + encodeURIComponent(t)
        })).join("&") : "";
        return yt("a", {
            href: "https://posthog.com/surveys" + (t ? "?" + t : ""),
            target: "_blank",
            rel: "noopener",
            className: "footer-branding",
            children: ["Survey by ", qt]
        })
    }

    function Tt(e) {
        var {
            text: r,
            submitDisabled: t,
            appearance: n,
            onSubmit: i,
            link: o,
            onPreviewSubmit: a,
            skipSubmitButton: s,
            canGoBack: u,
            onBack: l
        } = e, {
            isPreviewMode: c
        } = de(nt), d = !!u && !!l, v = !s && yt("button", {
            className: "form-submit",
            disabled: t,
            "aria-label": "Submit survey",
            type: "button",
            onClick() {
                o && (null == ir || ir.open(o)), c ? null == a || a() : i()
            },
            children: r
        });
        return yt("div", {
            className: "bottom-section",
            children: [d ? yt("div", {
                className: "form-buttons form-buttons-with-back",
                children: [yt("button", {
                    className: "form-back",
                    type: "button",
                    "aria-label": "Go to previous question",
                    onClick: l,
                    children: n.backButtonText || "Back"
                }), v]
            }) : v, !n.whiteLabel && yt(_t, {
                urlParams: {
                    utm_source: "survey-footer"
                }
            })]
        })
    }

    function Pt(e) {
        var {
            question: r,
            forceDisableHtml: t,
            htmlFor: n
        } = e;
        return yt("div", {
            class: r.question || r.description ? "question-header" : "question-header question-header--empty",
            children: [yt(r.type === Se.Open ? "label" : "h3", {
                className: "survey-question",
                htmlFor: n,
                children: r.question
            }), r.description && ot({
                component: k("p", {
                    className: "survey-question-description"
                }),
                children: r.description,
                renderAsHtml: !t && "text" !== r.descriptionContentType
            })]
        })
    }

    function It(e) {
        var {
            onClick: r
        } = e, {
            isPreviewMode: t
        } = de(nt);
        return yt("button", {
            className: "form-cancel",
            onClick: r,
            disabled: t,
            "aria-label": "Close survey",
            type: "button",
            children: Ct({
                fill: "black"
            })
        })
    }
    yt("svg", {
        width: "16",
        height: "12",
        viewBox: "0 0 16 12",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: yt("path", {
            d: "M5.30769 10.6923L4.77736 11.2226C4.91801 11.3633 5.10878 11.4423 5.30769 11.4423C5.5066 11.4423 5.69737 11.3633 5.83802 11.2226L5.30769 10.6923ZM15.5303 1.53033C15.8232 1.23744 15.8232 0.762563 15.5303 0.46967C15.2374 0.176777 14.7626 0.176777 14.4697 0.46967L15.5303 1.53033ZM1.53033 5.85429C1.23744 5.56139 0.762563 5.56139 0.46967 5.85429C0.176777 6.14718 0.176777 6.62205 0.46967 6.91495L1.53033 5.85429ZM5.83802 11.2226L15.5303 1.53033L14.4697 0.46967L4.77736 10.162L5.83802 11.2226ZM0.46967 6.91495L4.77736 11.2226L5.83802 10.162L1.53033 5.85429L0.46967 6.91495Z",
            fill: "currentColor"
        })
    });
    var Mt = ir;

    function Lt(e) {
        var {
            header: r,
            description: t,
            contentType: n,
            forceDisableHtml: i,
            appearance: o,
            onClose: a
        } = e, {
            isPopup: s
        } = de(nt);
        return ue((() => {
            var e = e => {
                "Enter" !== e.key && "Escape" !== e.key || (e.preventDefault(), a())
            };
            return pr(Mt, "keydown", e), () => {
                Mt.removeEventListener("keydown", e)
            }
        }), [a]), yt("div", {
            className: "thank-you-message",
            role: "status",
            tabIndex: 0,
            "aria-atomic": "true",
            children: [s && !0 !== o.hideCancelButton && yt(It, {
                onClick: () => a()
            }), yt("h3", {
                className: "thank-you-message-header",
                children: r
            }), t && ot({
                component: k("p", {
                    className: "thank-you-message-body"
                }),
                children: t,
                renderAsHtml: !i && "text" !== n
            }), s && yt(Tt, {
                text: o.thankYouMessageCloseButtonText || "Close",
                submitDisabled: !1,
                appearance: o,
                onSubmit: () => a()
            })]
        })
    }
    var Nt = e => Me(e) && e.every((e => He(e)));

    function Ht(e) {
        var {
            question: r,
            forceDisableHtml: t,
            appearance: n,
            onSubmit: i,
            onPreviewSubmit: o,
            displayQuestionIndex: a,
            initialValue: s,
            canGoBack: u,
            onBack: l
        } = e, {
            isPreviewMode: c
        } = it(), d = le(null), [v, p] = se((() => He(s) ? s : ""));
        ue((() => {
            setTimeout((() => {
                var e;
                c || null == (e = d.current) || e.focus()
            }), 100)
        }), [c]);
        var f = "surveyQuestion" + a,
            h = ce((() => function(e, r, t) {
                var n, i, o = e.trim();
                if (!t && "" === o) return "This field is required";
                if ("" === o) return !1;
                if (r && r.length > 0)
                    for (var a of r) switch (a.type) {
                        case Pe.MinLength:
                            if (void 0 !== a.value && a.value > o.length) return null !== (n = a.errorMessage) && void 0 !== n ? n : "Please enter at least " + a.value + " characters";
                            break;
                        case Pe.MaxLength:
                            if (void 0 !== a.value && o.length > a.value) return null !== (i = a.errorMessage) && void 0 !== i ? i : "Please enter no more than " + a.value + " characters"
                    }
                return !1
            }(v, r.validation, r.optional)), [v, r.validation, r.optional]),
            y = nr(r.validation, Pe.MinLength),
            m = nr(r.validation, Pe.MaxLength),
            g = ce((() => function(e, r) {
                var t = 1 === e ? void 0 : e;
                return t && r ? "Enter " + t + "-" + r + " characters" : t ? "Enter at least " + t + " " + (1 === t ? "character" : "characters") : r ? "Maximum " + r + " " + (1 === r ? "character" : "characters") : void 0
            }(y, m)), [y, m]),
            b = () => {
                h || i(v.trim())
            },
            w = () => {
                h || o(v.trim())
            };
        return yt(C, {
            children: [yt("div", {
                className: "question-container",
                children: [yt(Pt, {
                    question: r,
                    forceDisableHtml: t,
                    htmlFor: f
                }), yt("textarea", {
                    ref: d,
                    id: f,
                    rows: 4,
                    placeholder: null == n ? void 0 : n.placeholder,
                    minLength: y,
                    maxLength: m,
                    onInput(e) {
                        p(e.currentTarget.value), e.stopPropagation()
                    },
                    onKeyDown(e) {
                        e.stopPropagation(), "Enter" !== e.key || !e.metaKey && !e.ctrlKey || h || (e.preventDefault(), c ? w() : b())
                    },
                    value: v
                }), g && yt("div", {
                    className: "validation-hint",
                    children: g
                })]
            }), yt(Tt, {
                text: r.buttonText || "Submit",
                submitDisabled: !!h,
                appearance: n,
                onSubmit: b,
                onPreviewSubmit: w,
                canGoBack: u,
                onBack: l
            })]
        })
    }

    function Et(e) {
        var {
            question: r,
            forceDisableHtml: t,
            appearance: n,
            onSubmit: i,
            onPreviewSubmit: o,
            canGoBack: a,
            onBack: s
        } = e;
        return yt(C, {
            children: [yt("div", {
                className: "question-container",
                children: yt(Pt, {
                    question: r,
                    forceDisableHtml: t
                })
            }), yt(Tt, {
                text: r.buttonText || "Submit",
                submitDisabled: !1,
                link: r.link,
                appearance: n,
                onSubmit: () => i("link clicked"),
                onPreviewSubmit: () => o("link clicked"),
                canGoBack: a,
                onBack: s
            })]
        })
    }

    function Vt(e) {
        var r, {
                question: t,
                forceDisableHtml: n,
                displayQuestionIndex: i,
                appearance: o,
                onSubmit: a,
                onPreviewSubmit: s,
                initialValue: u,
                canGoBack: l,
                onBack: c
            } = e,
            d = t.scale,
            v = 10 === t.scale ? 0 : 1,
            [p, f] = se((() => Be(u) ? u : Me(u) && u.length > 0 && Be(parseInt(u[0])) ? parseInt(u[0]) : He(u) && Be(parseInt(u)) ? parseInt(u) : null)),
            h = "emoji" === t.display && 2 === t.scale,
            {
                isPreviewMode: y
            } = it(),
            m = e => y ? s(e) : a(e);
        return yt(C, {
            children: [yt("div", {
                className: "question-container",
                children: [yt(Pt, {
                    question: t,
                    forceDisableHtml: n
                }), yt("div", {
                    className: "rating-section",
                    children: [yt("div", {
                        className: "rating-options",
                        children: ["emoji" === t.display && yt("div", {
                            className: "rating-options-emoji" + (h ? " rating-options-emoji-2" : ""),
                            children: null == (r = Ft[t.scale]) ? void 0 : r.map(((e, r) => yt("button", {
                                "aria-label": "Rate " + (r + 1),
                                className: "ratings-emoji question-" + i + "-rating-" + r + " " + (r + 1 === p ? "rating-active" : ""),
                                value: r + 1,
                                type: "button",
                                onClick() {
                                    var e = r + 1;
                                    f(e), t.skipSubmitButton && m(e)
                                },
                                children: e
                            }, r)))
                        }), "number" === t.display && yt("div", {
                            className: "rating-options-number",
                            style: {
                                gridTemplateColumns: "repeat(" + (d - v + 1) + ", minmax(0, 1fr))"
                            },
                            children: jt(t.scale).map(((e, r) => yt(Bt, {
                                displayQuestionIndex: i,
                                active: p === e,
                                appearance: o,
                                num: e,
                                setActiveNumber(e) {
                                    f(e), t.skipSubmitButton && m(e)
                                }
                            }, r)))
                        })]
                    }), !h && yt("div", {
                        className: "rating-text",
                        children: [yt("div", {
                            children: t.lowerBoundLabel
                        }), yt("div", {
                            children: t.upperBoundLabel
                        })]
                    })]
                })]
            }), yt(Tt, {
                text: t.buttonText || (null == o ? void 0 : o.submitButtonText) || "Submit",
                submitDisabled: Ee(p) && !t.optional,
                appearance: o,
                onSubmit: () => a(p),
                onPreviewSubmit: () => s(p),
                skipSubmitButton: t.skipSubmitButton,
                canGoBack: l,
                onBack: c
            })]
        })
    }

    function Bt(e) {
        var {
            num: r,
            active: t,
            displayQuestionIndex: n,
            setActiveNumber: i
        } = e;
        return yt("button", {
            "aria-label": "Rate " + r,
            className: "ratings-number question-" + n + "-rating-" + r + " " + (t ? "rating-active" : ""),
            type: "button",
            onClick() {
                i(r)
            },
            children: r
        })
    }

    function Dt(r) {
        var {
            question: t,
            forceDisableHtml: n,
            displayQuestionIndex: i,
            appearance: o,
            onSubmit: a,
            onPreviewSubmit: s,
            initialValue: u,
            canGoBack: l,
            onBack: c
        } = r, d = le(null), v = ce((() => (e => {
            if (!e.shuffleOptions) return e.choices;
            var r = e.choices,
                t = "";
            e.hasOpenChoice && (t = r.pop());
            var n = et(r, Xr(r));
            return e.hasOpenChoice && (e.choices.push(t), n.push(t)), n
        })(t)), [t]), [p, f] = se((() => ((e, r) => He(e) || Nt(e) ? e : r === Se.SingleChoice ? null : [])(u, t.type))), [h, y] = se((() => ((e, r) => {
            if (He(e) && !r.includes(e)) return {
                isSelected: !0,
                inputValue: e
            };
            if (Nt(e)) {
                var t = e.find((e => !r.includes(e)));
                if (t) return {
                    isSelected: !0,
                    inputValue: t
                }
            }
            return {
                isSelected: !1,
                inputValue: ""
            }
        })(u, v))), {
            isPreviewMode: m
        } = it(), g = t.type === Se.SingleChoice, b = t.type === Se.MultipleChoice, w = t.skipSubmitButton && g && !t.hasOpenChoice, x = (r, t) => {
            if (t) {
                var n = !h.isSelected;
                return y((r => e({}, r, {
                    isSelected: n,
                    inputValue: n ? r.inputValue : ""
                }))), g && f(""), void(n && setTimeout((() => {
                    var e;
                    return null == (e = d.current) ? void 0 : e.focus()
                }), 75))
            }
            if (g) return f(r), y((r => e({}, r, {
                isSelected: !1,
                inputValue: ""
            }))), void(w && (a(r), m && s(r)));
            b && Me(p) && (p.includes(r) ? f(p.filter((e => e !== r))) : f([...p, r]))
        }, k = r => {
            r.stopPropagation();
            var t = r.currentTarget.value;
            y((r => e({}, r, {
                inputValue: t
            }))), g && f(t)
        }, S = r => {
            r.stopPropagation(), "Enter" !== r.key || q() || (r.preventDefault(), _()), "Escape" === r.key && (r.preventDefault(), y((r => e({}, r, {
                isSelected: !1,
                inputValue: ""
            }))), g && f(null))
        }, q = () => !(t.optional || !Ee(p) && (!Me(p) || h.isSelected || 0 !== p.length) && (!h.isSelected || "" !== h.inputValue.trim())), _ = () => {
            h.isSelected && b ? Me(p) && (m ? s([...p, h.inputValue]) : a([...p, h.inputValue])) : m ? s(p) : a(p)
        };
        return yt(C, {
            children: [yt("div", {
                className: "question-container",
                children: [yt(Pt, {
                    question: t,
                    forceDisableHtml: n
                }), yt("fieldset", {
                    className: "multiple-choice-options limit-height",
                    children: [yt("legend", {
                        className: "sr-only",
                        children: b ? " Select all that apply" : " Select one"
                    }), v.map(((e, r) => {
                        var n = !!t.hasOpenChoice && r === t.choices.length - 1,
                            o = "surveyQuestion" + i + "Choice" + r,
                            a = o + "Open",
                            s = n ? h.isSelected : g ? p === e : Me(p) && p.includes(e);
                        return yt("label", {
                            className: n ? "choice-option-open" : "",
                            children: [yt("div", {
                                className: "response-choice",
                                children: [yt("input", {
                                    type: g ? "radio" : "checkbox",
                                    name: o,
                                    checked: s,
                                    onChange: () => x(e, n),
                                    id: o,
                                    "aria-controls": a
                                }), yt("span", {
                                    children: n ? e + ":" : e
                                })]
                            }), n && yt("input", {
                                type: "text",
                                ref: d,
                                id: a,
                                name: "question" + i + "Open",
                                value: h.inputValue,
                                onKeyDown: S,
                                onInput: k,
                                onClick(r) {
                                    h.isSelected || x(e, !0), r.stopPropagation()
                                },
                                "aria-label": e + " - please specify"
                            })]
                        }, r)
                    }))]
                })]
            }), yt(Tt, {
                text: t.buttonText || "Submit",
                submitDisabled: q(),
                appearance: o,
                onSubmit: _,
                onPreviewSubmit: _,
                skipSubmitButton: w,
                canGoBack: l,
                onBack: c
            })]
        })
    }
    var At = [1, 2, 3, 4, 5],
        Zt = [1, 2, 3, 4, 5, 6, 7],
        Rt = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        Ft = {
            2: [kt, St],
            3: [bt, gt, mt],
            5: [wt, bt, gt, mt, xt]
        };

    function jt(e) {
        switch (e) {
            case 5:
            default:
                return At;
            case 7:
                return Zt;
            case 10:
                return Rt
        }
    }
    var Qt = vr("[Surveys]");

    function Ut(e, r, t) {
        var n, i = e.questions[r],
            o = r + 1;
        if (null == (n = i.branching) || !n.type) return r === e.questions.length - 1 ? Ce.End : o;
        if (i.branching.type === Ce.End) return Ce.End;
        if (i.branching.type === Ce.SpecificQuestion) {
            if (Number.isInteger(i.branching.index)) return i.branching.index
        } else if (i.branching.type === Ce.ResponseBased) {
            if (i.type === Se.SingleChoice) {
                var a, s = i.choices.indexOf("" + t);
                if (-1 === s && i.hasOpenChoice && (s = i.choices.length - 1), null != (a = i.branching) && null != (a = a.responseValues) && a.hasOwnProperty(s)) {
                    var u = i.branching.responseValues[s];
                    return Number.isInteger(u) ? u : u === Ce.End ? Ce.End : o
                }
            } else if (i.type === Se.Rating) {
                var l;
                if ("number" != typeof t || !Number.isInteger(t)) throw new Error("The response type must be an integer");
                var c = function(e, r) {
                    if (2 === r) {
                        if (1 > e || e > 2) throw new Error("The response must be in range 1-2");
                        return 1 === e ? "positive" : "negative"
                    }
                    if (3 === r) {
                        if (1 > e || e > 3) throw new Error("The response must be in range 1-3");
                        return 1 === e ? "negative" : 2 === e ? "neutral" : "positive"
                    }
                    if (5 === r) {
                        if (1 > e || e > 5) throw new Error("The response must be in range 1-5");
                        return e > 2 ? 3 === e ? "neutral" : "positive" : "negative"
                    }
                    if (7 === r) {
                        if (1 > e || e > 7) throw new Error("The response must be in range 1-7");
                        return e > 3 ? 4 === e ? "neutral" : "positive" : "negative"
                    }
                    if (10 === r) {
                        if (0 > e || e > 10) throw new Error("The response must be in range 0-10");
                        return e > 6 ? e > 8 ? "promoters" : "passives" : "detractors"
                    }
                    throw new Error("The scale must be one of: 2, 3, 5, 7, 10")
                }(t, i.scale);
                if (null != (l = i.branching) && null != (l = l.responseValues) && l.hasOwnProperty(c)) {
                    var d = i.branching.responseValues[c];
                    return Number.isInteger(d) ? d : d === Ce.End ? Ce.End : o
                }
            }
            return o
        }
        return Qt.warn("Falling back to next question index due to unexpected branching type"), o
    }
    var zt = vr("[SurveyTranslations]");

    function Ot(e, r) {
        var t = function(e) {
            return function(e, r) {
                var {
                    overrideLanguage: t,
                    storedPersonProperties: n,
                    locale: i
                } = e, o = gr(t);
                if (o) return null == r || r.info("Using override display language: " + o), o;
                var a = function(e) {
                    return e && "object" == typeof e && "language" in e ? gr(e.language) : null
                }(n);
                if (a) return null == r || r.info("Using person property language: " + a), a;
                var s = gr(i);
                return s ? (null == r || r.info("Using detected locale: " + s), s) : (null == r || r.info("No user language detected"), null)
            }({
                overrideLanguage: e.config.override_display_language,
                storedPersonProperties: Le(e.get_property) ? e.get_property("$stored_person_properties") : void 0,
                locale: navigator.language || navigator.userLanguage
            }, zt)
        }(r);
        if (!t) return zt.info("No user language detected"), {
            survey: e,
            language: null
        };
        var n = xr(e, t, zt);
        return {
            survey: n.survey,
            language: n.matchedKey
        }
    }
    var $t = ir,
        Gt = sr,
        Wt = "ph:show_survey_widget",
        Yt = "PHWidgetSurveyClickListener";

    function Kt(e, r) {
        try {
            var t = e.getBoundingClientRect(),
                n = $t.innerHeight,
                i = $t.innerWidth,
                o = t.left + t.width / 2 - r / 2;
            o + r > i - 20 && (o = i - r - 20), 20 > o && (o = 20);
            var a = n - t.bottom,
                s = 250 > a && t.top > a;
            return {
                position: "fixed",
                top: s ? "auto" : t.bottom + 12 + "px",
                left: o + "px",
                right: "auto",
                bottom: s ? n - t.top + 12 + "px" : "auto",
                zIndex: Ur.zIndex
            }
        } catch (e) {
            return kr.warn("Failed to calculate trigger position:", e), null
        }
    }
    class Jt {
        constructor(r) {
            var t = this;
            this.j = new Map, this.B = new Map, this.H = new Set, this.handlePageUnload = () => {
                var e = this._posthog.get_property("$surveys");
                if (e)
                    for (var r of e) dt(r) && Jr(r, this._posthog)
            }, this.handlePopoverSurvey = (r, t) => {
                var n, i, o, a, {
                        survey: s,
                        language: u
                    } = this.U(r),
                    l = null != t && t.position || null != t && t.selector ? e({}, s, {
                        appearance: e({}, s.appearance, t.position && {
                            position: t.position
                        }, t.selector && {
                            widgetSelector: t.selector
                        })
                    }) : s;
                this.V(l.id);
                var {
                    properties: c,
                    initialResponses: d
                } = null != t ? t : {}, v = !(!d || 0 >= Object.keys(d).length) && this.W(l, d, c, u);
                if (!v || null != (n = l.appearance) && n.displayThankYouMessage) {
                    this.Z(l);
                    var p = {};
                    if ((null == (i = l.appearance) ? void 0 : i.position) === we.NextToTrigger && null != (o = l.appearance) && o.widgetSelector) {
                        var f, h = Gt.querySelector(l.appearance.widgetSelector);
                        h && (p = Kt(h, parseInt((null == (f = l.appearance) ? void 0 : f.maxWidth) || Ur.maxWidth)) || {})
                    }
                    var y = (null == (a = l.appearance) ? void 0 : a.surveyPopupDelaySeconds) || 0,
                        {
                            shadow: m
                        } = Gr(l, this._posthog),
                        g = {
                            posthog: this._posthog,
                            survey: l,
                            removeSurveyFromFocus: this.$,
                            properties: c,
                            style: p,
                            isSurveyCompleted: v,
                            skipShownEvent: null == t ? void 0 : t.skipShownEvent,
                            surveyLanguage: u
                        };
                    if (0 >= y) return z(yt(tn, e({}, g)), m);
                    var b = setTimeout((() => {
                        if (this.j.delete(l.id), !this.G(l)) return kr.info("Survey " + l.id + " no longer eligible when its display delay elapsed; not displaying"), this.$(l);
                        z(yt(tn, e({}, g, {
                            survey: e({}, l, {
                                appearance: e({}, l.appearance, {
                                    surveyPopupDelaySeconds: 0
                                })
                            })
                        })), m)
                    }), 1e3 * y);
                    this.j.set(l.id, b)
                }
            }, this.J = e => {
                var {
                    survey: r,
                    language: t
                } = this.U(e), {
                    shadow: n,
                    isNewlyCreated: i
                } = Gr(r, this._posthog);
                i && z(yt(on, {
                    posthog: this._posthog,
                    survey: r,
                    surveyLanguage: t
                }, e.id), n)
            }, this.X = e => {
                this.Y(e);
                var r = this.B.get(e.id);
                r && (r.element.removeEventListener("click", r.listener), r.element.removeAttribute(Yt), this.B.delete(e.id), kr.info("Removed click listener for survey " + e.id))
            }, this.K = (e, r) => {
                var t = Gt.querySelector(r),
                    n = this.B.get(e.id);
                if (t) {
                    if (this.J(e), n) {
                        if (t === n.element) return;
                        kr.info("Selector element changed for survey " + e.id + ". Re-attaching listener."), this.X(e)
                    }
                    if (!t.hasAttribute(Yt)) {
                        var i = r => {
                            var t, n;
                            r.stopPropagation();
                            var i = (null == (t = e.appearance) ? void 0 : t.position) === we.NextToTrigger ? Kt(r.currentTarget, parseInt((null == (n = e.appearance) ? void 0 : n.maxWidth) || Ur.maxWidth)) : {};
                            $t.dispatchEvent(new CustomEvent(Wt, {
                                detail: {
                                    surveyId: e.id,
                                    position: i
                                }
                            }))
                        };
                        pr(t, "click", i), t.setAttribute(Yt, "true"), this.B.set(e.id, {
                            element: t,
                            listener: i,
                            survey: e
                        }), kr.info("Attached click listener for feedback button survey " + e.id)
                    }
                } else n && this.X(e)
            }, this.renderPopover = e => {
                var {
                    survey: r,
                    language: t
                } = this.U(e), {
                    shadow: n
                } = Gr(r, this._posthog);
                z(yt(tn, {
                    posthog: this._posthog,
                    survey: r,
                    removeSurveyFromFocus: this.$,
                    surveyLanguage: t
                }), n)
            }, this.renderSurvey = (e, r, t) => {
                var n, {
                        survey: i,
                        language: o
                    } = this.U(e),
                    a = !1;
                null != (n = this._posthog.config) && null != (n = n.surveys) && n.prefillFromUrl && (a = this.ee(i, o)), z(yt(tn, {
                    posthog: this._posthog,
                    survey: i,
                    removeSurveyFromFocus: this.$,
                    isPopup: !1,
                    properties: t,
                    isSurveyCompleted: a,
                    surveyLanguage: o
                }), r)
            }, this.getActiveMatchingSurveys = function(e, r) {
                var n;
                void 0 === r && (r = !1), null == (n = t._posthog) || null == (n = n.surveys) || n.getSurveys((r => {
                    var n = r.filter((e => t.G(e)));
                    e(n)
                }), r)
            }, this.callSurveysAndEvaluateDisplayLogic = function(e) {
                void 0 === e && (e = !1), t.getActiveMatchingSurveys((e => {
                    var r = e.filter((e => e.type === ke.Popover || e.type === ke.Widget)),
                        n = new Set(r.map((e => e.id)));
                    for (var i of Array.from(t.j.keys())) n.has(i) || t.cancelSurvey(i);
                    var o = t.te(r),
                        a = new Set;
                    o.forEach((e => {
                        if (e.type === ke.Widget) {
                            var r, n, i, o;
                            if ((null == (r = e.appearance) ? void 0 : r.widgetType) === be.Tab) return void t.J(e);
                            (null == (n = e.appearance) ? void 0 : n.widgetType) === be.Selector && null != (i = e.appearance) && i.widgetSelector && (a.add(e.id), t.K(e, null == (o = e.appearance) ? void 0 : o.widgetSelector))
                        }
                        Ee(t.re) && e.type === ke.Popover && t.handlePopoverSurvey(e)
                    })), t.B.forEach((e => {
                        var {
                            survey: r
                        } = e;
                        a.has(r.id) || t.X(r)
                    }))
                }), e)
            }, this.Z = e => {
                Ee(this.re) || kr.error("Survey " + this.re + " already in focus. Cannot add survey " + e.id + "."), this.re = e.id
            }, this.$ = e => {
                this.re !== e.id && kr.error("Survey " + e.id + " is not in focus. Cannot remove survey " + e.id + "."), this.V(e.id), this.re = null, this.Y(e)
            }, this._posthog = r, this.re = null
        }
        V(e) {
            var r = this.j.get(e);
            r && (clearTimeout(r), this.j.delete(e))
        }
        cancelSurvey(e) {
            this.j.has(e) && (kr.info("Cancelled pending survey " + e), this.V(e), this.re === e && (this.re = null))
        }
        te(e) {
            return e.sort(((e, r) => {
                var t, n, i = dt(e),
                    o = dt(r);
                if (i && !o) return -1;
                if (!i && o) return 1;
                var a = e.schedule === qe,
                    s = r.schedule === qe;
                return a && !s ? 1 : !a && s ? -1 : ((null == (t = e.appearance) ? void 0 : t.surveyPopupDelaySeconds) || 0) - ((null == (n = r.appearance) ? void 0 : n.surveyPopupDelaySeconds) || 0)
            }))
        }
        U(e) {
            return Ot(e, this._posthog)
        }
        ee(e, r) {
            if (this.H.has(e.id)) return !1;
            var {
                params: t
            } = function(e) {
                var r = {},
                    t = !1,
                    n = e.replace(/^\?/, "");
                if (!n) return {
                    params: r,
                    autoSubmit: t
                };
                var i = n.split("&");
                for (var o of i) {
                    var [a, s] = o.split("=");
                    if (a && !Ne(s)) {
                        var u = decodeURIComponent(a),
                            l = decodeURIComponent(s);
                        if ("auto_submit" !== u || "true" !== l) {
                            var c = u.match(/^q(\d+)$/);
                            if (c) {
                                var d = parseInt(c[1], 10);
                                r[d] || (r[d] = []), r[d].push(l)
                            }
                        } else t = !0
                    }
                }
                return {
                    params: r,
                    autoSubmit: t
                }
            }($t.location.search);
            if (0 === Object.keys(t).length) return !1;
            kr.info("[Survey Prefill] Detected URL prefill parameters");
            var n = this.ne(e, t, r);
            if (!n) return !1;
            var {
                responses: i,
                submissionId: o,
                isSurveyCompleted: a,
                skippedResponses: s
            } = n;
            return (Object.keys(s).length > 0 && e.enable_partial_responses || a) && Wr({
                responses: a ? i : s,
                survey: e,
                surveySubmissionId: o,
                posthog: this._posthog,
                isSurveyCompleted: a,
                surveyLanguage: r
            }), this.H.add(e.id), a
        }
        W(e, r, t, n) {
            var i = {};
            for (var [o, a] of Object.entries(r)) i[parseInt(o)] = Me(a) ? a.map(String) : [String(a)];
            kr.info("[Survey] Processing initial responses");
            var s = this.ne(e, i, n);
            if (!s) return !1;
            var {
                responses: u,
                submissionId: l,
                isSurveyCompleted: c
            } = s;
            return Wr({
                responses: u,
                survey: e,
                surveySubmissionId: l,
                posthog: this._posthog,
                isSurveyCompleted: c,
                properties: t,
                surveyLanguage: n
            }), c
        }
        ne(e, r, t) {
            try {
                var n = function(e, r) {
                    var t = {};
                    return e.questions.forEach(((e, n) => {
                        if (r[n] && e.id) {
                            var i = r[n],
                                o = fr(e.id);
                            try {
                                switch (e.type) {
                                    case Se.SingleChoice:
                                        if (!e.choices || 0 === e.choices.length) return void dr.warn("[Survey Prefill] Question " + n + " has no choices");
                                        var a = parseInt(i[0], 10);
                                        if (isNaN(a) || 0 > a || a >= e.choices.length) return void dr.warn("[Survey Prefill] Invalid choice index for q" + n + ": " + i[0]);
                                        t[o] = e.choices[a];
                                        break;
                                    case Se.MultipleChoice:
                                        if (!e.choices || 0 === e.choices.length) return void dr.warn("[Survey Prefill] Question " + n + " has no choices");
                                        var s = i.map((e => parseInt(e, 10))).filter((r => !isNaN(r) && r >= 0 && e.choices.length > r));
                                        if (0 === s.length) return void dr.warn("[Survey Prefill] No valid choices for q" + n);
                                        var u = [...new Set(s.map((r => e.choices[r])))];
                                        s.length > u.length && dr.warn("[Survey Prefill] Removed duplicate choices for q" + n), t[o] = u;
                                        break;
                                    case Se.Rating:
                                        var l = parseInt(i[0], 10),
                                            c = e.scale || 10;
                                        if (isNaN(l) || 0 > l || l > c) return void dr.warn("[Survey Prefill] Invalid rating for q" + n + ": " + i[0] + " (scale: 0-" + c + ")");
                                        t[o] = l;
                                        break;
                                    default:
                                        dr.info("[Survey Prefill] Question type " + e.type + " does not support prefill")
                                }
                            } catch (e) {
                                dr.error("[Survey Prefill] Error converting q" + n + ":", e)
                            }
                        }
                    })), t
                }(e, r);
                if (0 === Object.keys(n).length) return kr.warn("[Survey Prefill] No valid responses after conversion"), null;
                var i = Hr(),
                    o = Object.keys(r).map((e => parseInt(e, 10))),
                    {
                        startQuestionIndex: a,
                        skippedResponses: s
                    } = function(e, r, t) {
                        for (var n = 0, i = {}, o = e.questions.length + 1; e.questions.length > n && o > 0 && r.includes(n);) {
                            var a = e.questions[n];
                            if (!a || !("skipSubmitButton" in a) || !a.skipSubmitButton) break;
                            if (a.id) {
                                var s = fr(a.id);
                                Ne(t[s]) || (i[s] = t[s])
                            }
                            var u = Ut(e, n, a.id ? t[fr(a.id)] : null);
                            if (u === Ce.End) return {
                                startQuestionIndex: e.questions.length,
                                skippedResponses: i
                            };
                            n = u
                        }
                        return {
                            startQuestionIndex: n,
                            skippedResponses: i
                        }
                    }(e, o, n),
                    u = a >= e.questions.length;
                return lt(e, {
                    surveySubmissionId: i,
                    responses: n,
                    lastQuestionIndex: a,
                    surveyLanguage: t
                }), kr.info("[Survey Prefill] Stored prefilled responses in localStorage"), {
                    responses: n,
                    submissionId: i,
                    startQuestionIndex: a,
                    isSurveyCompleted: u,
                    skippedResponses: s
                }
            } catch (e) {
                return kr.error("[Survey Prefill] Error handling prefill:", e), null
            }
        }
        ie(e, r) {
            var t;
            if (void 0 === r && (r = void 0), !e) return !0;
            var n, i = !(null == (t = this._posthog.featureFlags) || !t.isFeatureEnabled(e, {
                    send_event: !e.startsWith("survey-targeting-")
                })),
                o = !0;
            return r && (o = (null == (n = this._posthog.featureFlags) ? void 0 : n.getFeatureFlag(e, {
                send_event: !1
            })) === r || "any" === r), i && o
        }
        oe(e) {
            return !e.conditions || at(e) && st(e) && function(e) {
                var r;
                return null == (r = e.conditions) || !r.selector || !(null == jr || !jr.querySelector(e.conditions.selector))
            }(e)
        }
        ae(e) {
            return tt(e) || this.ie(e.internal_targeting_flag_key) || dt(e)
        }
        checkSurveyEligibility(e) {
            var r, t, n = {
                eligible: !0,
                reason: void 0
            };
            if (! function(e) {
                    return !(!e.start_date || e.end_date)
                }(e)) return n.eligible = !1, n.reason = "Survey is not running. It was completed on " + e.end_date, n;
            if (!Tr.includes(e.type)) return n.eligible = !1, n.reason = "Surveys of type " + e.type + " are never eligible to be shown in the app", n;
            var i = null == (r = e.conditions) ? void 0 : r.linkedFlagVariant;
            return this.ie(e.linked_flag_key, i) ? this.ie(e.targeting_flag_key) ? this.ae(e) ? function(e, r) {
                if (!e || !r) return !0;
                var t = "string" == typeof r ? new Date(r) : r,
                    n = new Date,
                    i = Math.abs(n.getTime() - t.getTime());
                return Math.ceil(i / 864e5) > e
            }(null == (t = e.conditions) ? void 0 : t.seenSurveyWaitPeriodInDays, Zr.P("lastSeenSurveyDate")) ? (e => !!Zr.P(qr(e)) && !tt(e))(e) ? (n.eligible = !1, n.reason = "Survey has already been seen and it can't be activated again", n) : n : (n.eligible = !1, n.reason = "Survey wait period has not passed", n) : (n.eligible = !1, n.reason = "Survey internal targeting flag is not enabled and survey cannot activate repeatedly and survey is not in progress", n) : (n.eligible = !1, n.reason = "Survey targeting feature flag is not enabled", n) : (n.eligible = !1, n.reason = i ? "Survey linked feature flag is not enabled for variant " + i : "Survey linked feature flag is not enabled", n)
        }
        se(e) {
            var r;
            if (! function(e) {
                    var r;
                    return !(null == (r = e.conditions) || null == (r = r.events) || null == (r = r.values) || !r.length)
                }(e) && ! function(e) {
                    var r;
                    return !(null == (r = e.conditions) || null == (r = r.actions) || null == (r = r.values) || !r.length)
                }(e)) return !0;
            var t = null == (r = this._posthog.surveys) || null == (r = r._surveyEventReceiver) ? void 0 : r.getSurveys();
            return !(null == t || !t.includes(e.id))
        }
        ue(e) {
            var r;
            return null == (r = e.feature_flag_keys) || !r.length || e.feature_flag_keys.every((e => {
                var {
                    key: r,
                    value: t
                } = e;
                return !r || !t || this.ie(t)
            }))
        }
        G(e) {
            return this.checkSurveyEligibility(e).eligible && this.oe(e) && this.se(e) && this.ue(e)
        }
        Y(e) {
            try {
                var r = Gt.querySelector(pt(e, !0));
                null != r && r.shadowRoot && z(null, r.shadowRoot), null == r || r.remove()
            } catch (r) {
                kr.warn("Failed to remove survey " + e.id + " from DOM:", r)
            }
        }
        getTestAPI() {
            return {
                addSurveyToFocus: this.Z,
                removeSurveyFromFocus: this.$,
                surveyInFocus: this.re,
                surveyTimeouts: this.j,
                handleWidget: this.J,
                handlePopoverSurvey: this.handlePopoverSurvey,
                manageWidgetSelectorListener: this.K,
                sortSurveysByAppearanceDelay: this.te,
                checkFlags: this.ue.bind(this),
                isSurveyFeatureFlagEnabled: this.ie.bind(this)
            }
        }
    }

    function Xt(e, r) {
        if (Gt && $t) {
            var t, n = new Jt(e);
            if (e.config.disable_surveys_automatic_display) return kr.info("Surveys automatic display is disabled. Skipping call surveys and evaluate display logic."), n;
            if (!1 === r) return kr.info("There are no surveys to load or Surveys is disabled in the project settings."), n;
            n.callSurveysAndEvaluateDisplayLogic(!0);
            var i = () => {
                Ne(t) && (t = setInterval((() => {
                    n.callSurveysAndEvaluateDisplayLogic(!1)
                }), 1e3))
            };
            return i(), pr(Gt, "visibilitychange", (() => {
                Gt.hidden ? Ne(t) || (clearInterval(t), t = void 0) : (n.callSurveysAndEvaluateDisplayLogic(!1), i())
            })), n
        }
    }

    function en(e) {
        var {
            survey: r,
            removeSurveyFromFocus: t = (() => {}),
            setSurveyVisible: n,
            isPreviewMode: i = !1
        } = e;
        ue((() => {
            var e;
            if (!i && null != (e = r.conditions) && e.url) {
                var o = () => {
                    var e, i = r.type === ke.Widget,
                        o = at(r),
                        a = (null == (e = r.appearance) ? void 0 : e.widgetType) === be.Tab && i;
                    if (!o) return kr.info("Hiding survey " + r.id + " because URL does not match"), n(!1), t(r);
                    a && (kr.info("Showing survey " + r.id + " because it is a feedback button tab and URL matches"), n(!0))
                };
                pr($t, "popstate", o), pr($t, "hashchange", o);
                var a = $t.history.pushState,
                    s = $t.history.replaceState;
                return $t.history.pushState = function() {
                    for (var e = arguments.length, r = new Array(e), t = 0; e > t; t++) r[t] = arguments[t];
                    a.apply(this, r), o()
                }, $t.history.replaceState = function() {
                    for (var e = arguments.length, r = new Array(e), t = 0; e > t; t++) r[t] = arguments[t];
                    s.apply(this, r), o()
                }, () => {
                    $t.removeEventListener("popstate", o), $t.removeEventListener("hashchange", o), $t.history.pushState = a, $t.history.replaceState = s
                }
            }
        }), [i, r, t, n])
    }

    function rn(e) {
        switch (void 0 === e && (e = xe.Right), e) {
            case xe.Top:
                return {
                    top: "0",
                    left: "50%",
                    transform: "translateX(-50%)"
                };
            case xe.Left:
                return {
                    top: "50%",
                    left: "0",
                    transform: "rotate(90deg) translateY(-100%)",
                    transformOrigin: "left top"
                };
            case xe.Bottom:
                return {
                    bottom: "0",
                    left: "50%",
                    transform: "translateX(-50%)"
                };
            default:
                return {
                    top: "50%",
                    right: "0",
                    transform: "rotate(-90deg) translateY(-100%)",
                    transformOrigin: "right top"
                }
        }
    }

    function tn(r) {
        var t, n, i, o, a, s, {
                survey: u,
                forceDisableHtml: l,
                posthog: c,
                style: d = {},
                previewPageIndex: v,
                removeSurveyFromFocus: p = (() => {}),
                isPopup: f = !0,
                onPreviewSubmit: h = (() => {}),
                onPreviewBack: y = (() => {}),
                onPopupSurveyDismissed: m = (() => {}),
                onCloseConfirmationMessage: g = (() => {}),
                properties: b,
                isSurveyCompleted: w,
                skipShownEvent: x,
                surveyLanguage: k
            } = r,
            S = le(null),
            C = Number.isInteger(v),
            q = null != (t = u.appearance) && t.surveyPopupDelaySeconds ? 1e3 * u.appearance.surveyPopupDelaySeconds : 0,
            {
                isPopupVisible: _,
                isSurveySent: T,
                hidePopupWithViewTransition: P
            } = function(r, t, n, i, o, a, s, u, l) {
                var [c, d] = se(i || 0 === n || r.type === ke.ExternalSurvey), [v, p] = se(!1), f = () => {
                    var e = () => {
                        a && o(r), d(!1)
                    };
                    Gt.startViewTransition ? Gt.startViewTransition((() => {
                        var e;
                        null == s || null == (e = s.current) || e.remove()
                    })).finished.then((() => {
                        setTimeout((() => {
                            e()
                        }), 100)
                    })) : e()
                }, h = e => {
                    e.detail.surveyId === r.id && f()
                };
                return ue((() => {
                    if (t) {
                        if (!i) {
                            var o = e => {
                                    var t, n;
                                    if (e.detail.surveyId === r.id) {
                                        if (null == (t = r.appearance) || !t.displayThankYouMessage) return f();
                                        p(!0), null != (n = r.appearance) && n.autoDisappear && setTimeout((() => {
                                            f()
                                        }), 5e3)
                                    }
                                },
                                a = () => {
                                    if (at(r)) {
                                        d(!0), $t.dispatchEvent(new Event("PHSurveyShown")), u || t.capture(_e.SHOWN, e({
                                            [Te.SURVEY_NAME]: r.name,
                                            [Te.SURVEY_ID]: r.id,
                                            [Te.SURVEY_ITERATION]: r.current_iteration,
                                            [Te.SURVEY_ITERATION_START_DATE]: r.current_iteration_start_date
                                        }, l && {
                                            [Te.SURVEY_LANGUAGE]: l
                                        }, {
                                            sessionRecordingUrl: null == t.get_session_replay_url ? void 0 : t.get_session_replay_url()
                                        }));
                                        try {
                                            localStorage.setItem("lastSeenSurveyDate", (new Date).toISOString())
                                        } catch (e) {}
                                    }
                                };
                            if (pr($t, "PHSurveyClosed", h), pr($t, "PHSurveySent", o), n > 0) {
                                var s = setTimeout(a, n);
                                return () => {
                                    clearTimeout(s), $t.removeEventListener("PHSurveyClosed", h), $t.removeEventListener("PHSurveySent", o)
                                }
                            }
                            return a(), () => {
                                $t.removeEventListener("PHSurveyClosed", h), $t.removeEventListener("PHSurveySent", o)
                            }
                        }
                    } else kr.error("usePopupVisibility hook called without a PostHog instance.")
                }), []), en({
                    survey: r,
                    removeSurveyFromFocus: o,
                    setSurveyVisible: d,
                    isPreviewMode: i
                }), {
                    isPopupVisible: c,
                    isSurveySent: v,
                    setIsPopupVisible: d,
                    hidePopupWithViewTransition: f
                }
            }(u, c, q, C, p, f, S, x, k),
            I = T || v === u.questions.length || !0 === w,
            M = ce((() => {
                var e = ct(u),
                    r = (null == e ? void 0 : e.surveySubmissionId) || Hr();
                return {
                    isPreviewMode: C,
                    previewPageIndex: v,
                    onPopupSurveyDismissed() {
                        k ? Kr(u, c, C, k) : Kr(u, c, C), m()
                    },
                    isPopup: f || !1,
                    surveySubmissionId: r,
                    onPreviewSubmit: h,
                    onPreviewBack: y,
                    posthog: c,
                    properties: b,
                    surveyLanguage: k
                }
            }), [C, v, f, c, u, m, h, y, b, k]);
        return _ ? yt(nt.Provider, {
            value: M,
            children: yt("div", {
                className: "ph-survey",
                style: e({}, ft(u.type, null == (n = u.appearance) ? void 0 : n.position, null == (i = u.appearance) ? void 0 : i.widgetType), d),
                ref: S,
                children: I ? yt(Lt, {
                    header: (null == (o = u.appearance) ? void 0 : o.thankYouMessageHeader) || "Thank you!",
                    description: (null == (a = u.appearance) ? void 0 : a.thankYouMessageDescription) || "",
                    forceDisableHtml: !!l,
                    contentType: null == (s = u.appearance) ? void 0 : s.thankYouMessageDescriptionContentType,
                    appearance: u.appearance || Ur,
                    onClose() {
                        P(), g()
                    }
                }) : yt(nn, {
                    survey: u,
                    forceDisableHtml: !!l,
                    posthog: c
                })
            })
        }) : null
    }

    function nn(r) {
        var t, n, {
                survey: i,
                forceDisableHtml: o,
                posthog: a
            } = r,
            [s, u] = se((() => {
                var e = ct(i);
                return null != e && e.responses && kr.info("Survey is already in progress, filling in initial responses"), (null == e ? void 0 : e.responses) || {}
            })),
            {
                previewPageIndex: l,
                onPopupSurveyDismissed: c,
                isPopup: d,
                onPreviewSubmit: v,
                onPreviewBack: p,
                surveySubmissionId: f,
                isPreviewMode: h,
                properties: y,
                surveyLanguage: m
            } = de(nt),
            [g, b] = se((() => {
                var e = ct(i);
                return l || (null == e ? void 0 : e.lastQuestionIndex) || 0
            })),
            [w, x] = se((() => {
                var e, r = ct(i);
                return null !== (e = null == r ? void 0 : r.visitedIndices) && void 0 !== e ? e : []
            })),
            k = ce((() => rt(i)), [i]);
        ue((() => {
            h && !Ne(l) && b(l)
        }), [l, h]);
        var S = !(null == (t = i.appearance) || !t.allowGoBack) && (h ? (null != l ? l : 0) > 0 : w.length > 0),
            C = k.at(g);
        return C ? yt("form", {
            className: "survey-form",
            name: "surveyForm",
            children: [d && !0 !== (null == (n = i.appearance) ? void 0 : n.hideCancelButton) && yt(It, {
                onClick() {
                    c()
                }
            }), yt("div", {
                className: "survey-box",
                "data-question-index": g,
                children: an({
                    question: C,
                    forceDisableHtml: o,
                    displayQuestionIndex: g,
                    appearance: i.appearance || Ur,
                    onSubmit: r => (r => {
                        var {
                            res: t,
                            displayQuestionIndex: n,
                            questionId: o
                        } = r;
                        if (a)
                            if (o) {
                                var l = fr(o),
                                    c = e({}, s, {
                                        [l]: t
                                    });
                                u(c);
                                var d = Ut(i, n, t),
                                    v = d === Ce.End,
                                    p = [...w, n];
                                if (v || (x(p), b(d), lt(i, {
                                        surveySubmissionId: f,
                                        responses: c,
                                        lastQuestionIndex: d,
                                        visitedIndices: p,
                                        surveyLanguage: m
                                    })), i.enable_partial_responses || v) {
                                    var h = new Set(p.map((e => {
                                            var r;
                                            return null == (r = k[e]) ? void 0 : r.id
                                        })).filter((e => !!e)).map((e => fr(e)))),
                                        g = Object.fromEntries(Object.entries(c).filter((e => {
                                            var [r] = e;
                                            return h.has(r)
                                        })));
                                    Wr({
                                        responses: g,
                                        survey: i,
                                        surveySubmissionId: f,
                                        isSurveyCompleted: v,
                                        posthog: a,
                                        properties: y,
                                        surveyLanguage: m
                                    })
                                }
                            } else kr.error("onNextButtonClick called without a questionId.");
                        else kr.error("onNextButtonClick called without a PostHog instance.")
                    })({
                        res: r,
                        displayQuestionIndex: g,
                        questionId: C.id
                    }),
                    onPreviewSubmit: v,
                    initialValue: C.id ? s[fr(C.id)] : void 0,
                    canGoBack: S,
                    onBack() {
                        if (h) p();
                        else if (0 !== w.length) {
                            var e = w[w.length - 1],
                                r = w.slice(0, -1);
                            x(r), b(e), lt(i, {
                                surveySubmissionId: f,
                                responses: s,
                                lastQuestionIndex: e,
                                visitedIndices: r,
                                surveyLanguage: m
                            })
                        }
                    }
                })
            })]
        }) : null
    }

    function on(e) {
        var r, t, n, i, o, a, s, {
                survey: u,
                forceDisableHtml: l,
                posthog: c,
                readOnly: d,
                surveyLanguage: v
            } = e,
            [p, f] = se(!0),
            [h, y] = se(!1),
            [m, g] = se({}),
            b = () => {
                y(!h)
            };
        if (ue((() => {
                var e;
                if (c) {
                    if (!d) {
                        "tab" === (null == (e = u.appearance) ? void 0 : e.widgetType) && g({
                            top: "50%",
                            bottom: "auto"
                        });
                        var r = e => {
                            var r, t = e;
                            (null == (r = t.detail) ? void 0 : r.surveyId) === u.id && (kr.info("Received show event for feedback button survey " + u.id), g(t.detail.position || {}), b())
                        };
                        return pr($t, Wt, r), () => {
                            $t.removeEventListener(Wt, r)
                        }
                    }
                } else kr.error("FeedbackWidget called without a PostHog instance.")
            }), [c, d, u.id, null == (r = u.appearance) ? void 0 : r.widgetType, null == (t = u.appearance) ? void 0 : t.widgetSelector, null == (n = u.appearance) ? void 0 : n.borderColor]), en({
                survey: u,
                setSurveyVisible: f
            }), !p) return null;
        var w = () => {
            u.schedule !== qe && f(!1), setTimeout((() => {
                y(!1)
            }), 200)
        };
        return yt(C, {
            children: ["tab" === (null == (i = u.appearance) ? void 0 : i.widgetType) && yt("button", {
                className: "ph-survey-widget-tab " + ((null == (o = u.appearance) ? void 0 : o.tabPosition) === xe.Top ? "widget-tab-top" : ""),
                onClick: b,
                disabled: d,
                style: rn(null == (a = u.appearance) ? void 0 : a.tabPosition),
                children: (null == (s = u.appearance) ? void 0 : s.widgetLabel) || ""
            }), h && yt(tn, {
                posthog: c,
                survey: u,
                forceDisableHtml: l,
                style: m,
                onPopupSurveyDismissed: w,
                onCloseConfirmationMessage: w,
                surveyLanguage: v
            })]
        })
    }
    var an = r => {
        var {
            question: t,
            forceDisableHtml: n,
            displayQuestionIndex: i,
            appearance: o,
            onSubmit: a,
            onPreviewSubmit: s,
            initialValue: u,
            canGoBack: l,
            onBack: c
        } = r, d = {
            forceDisableHtml: n,
            appearance: o,
            onPreviewSubmit(e) {
                s(e)
            },
            onSubmit(e) {
                a(e)
            },
            initialValue: u,
            displayQuestionIndex: i,
            canGoBack: l,
            onBack: c
        };
        switch (t.type) {
            case Se.Open:
                return k(Ht, e({}, d, {
                    question: t,
                    key: t.id
                }));
            case Se.Link:
                return k(Et, e({}, d, {
                    question: t,
                    key: t.id
                }));
            case Se.Rating:
                return k(Vt, e({}, d, {
                    question: t,
                    key: t.id
                }));
            case Se.SingleChoice:
            case Se.MultipleChoice:
                return k(Dt, e({}, d, {
                    question: t,
                    key: t.id
                }));
            default:
                return kr.error("Unsupported question type: " + t.type), null
        }
    };
    lr.__PosthogExtensions__ = lr.__PosthogExtensions__ || {}, lr.__PosthogExtensions__.generateSurveys = Xt, lr.extendPostHogWithSurveys = Xt
}();
//# sourceMappingURL=surveys.js.map