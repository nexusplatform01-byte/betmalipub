webpackJsonp([3], {
    mtZG: function(e, t) {
        e.exports = {
            str: {
                Withdraw: "Withdraw",
                Deposit: "Deposit",
                "Confirm to Withdraw": "Confirm to Withdraw",
                "Transaction Fee": "Transaction Fee",
                Confirm: "Confirm",
                Pay: "Pay",
                "Choose an amount": "Choose an Amount",
                "Please enter the deposit amount": "Enter the amount",
                "Choose your withdrawal method and amount": "Choose your withdrawal method and amount",
                "Please enter the withdraw amount": "Please enter the withdraw amount",
                Home: "Home",
                "customer service": "24/7 customer service",
                "live chat": "Live Chat",
                Failed: "Failed"
            },
            content: {
                tips1: "Please note that there will be a withdrawal fee for this transaction.",
                tips2: "This withdrawal enjoys KSH {num} free of charge limit, the excess part is subject to a transaction fee.",
                tips3: "The minimum withdrawal amount is  KSH 100",
                tips4: "The maximum withdrawal amount is KSH 150,000",
                tips5: "Use one of the payment methods below to pay.",
                tips6: "Something went wrong. Please try again or pay with M-PESA Paybill",
                STR_Note1: "Note: You can only log in with your new password after recieving a message that the change was successful.",
                guide1: "Use Paybill company number 504050 and enter your registered Bangbet phone number as the reference number.",
                guide2: "You can also deposit by dialing",
                guide4: "Select: Pay Bill",
                guide5: "company number: 504050",
                guide6: "reference number: Your registered Bangbet phone number",
                vodacomGuide3: "or via Vadacom App.",
                mixxGuide3: "or via Mixx App.",
                airtelGuide1: "Use Paybill Select Bangbet and enter your registered Bangbet phone number as the reference number.",
                airtelGuide3: "or via Airtel App.",
                airtelGuide4: "Select: Betting",
                airtelGuide5: "Select option40: Bangbet",
                halotelGuide3: "or via Halotel App."
            },
            img: {
                IMG_HOME_ICON_URL: "../../assets/images/footer/Home1.jpg",
                IMG_AGE_ICON_URL: "../../assets/images/kelicense.png"
            },
            error: {
                Home: "Home"
            },
            deposit: {
                "Deposit Amount": "Deposit Amount",
                "Please enter an amount": "Please enter an amount",
                "Deposit failed": "Deposit failed?",
                Help: "Help",
                "To Account": "To Account",
                "Current Payment Method": "Current Payment Method",
                firstDepositTip: "200% First Deposit Bonus"
            },
            withdraw: {
                Tips: "Tips",
                Withdrawable: "Withdrawable",
                "Withdraw to: Mobile Money": "Withdraw to: Mobile Money",
                "Withdraw to: Mpesa": "Withdraw to: Mpesa",
                "Withdraw to: Airtel": "Withdraw to: Airtel",
                "Switch to M-PESA": "Switch to M-PESA",
                "Switch to Airtel": "Switch to Airtel",
                "Withdraw To": "Withdraw To",
                Amount: "Amount",
                "Insufficient balance": "Insufficient balance.",
                withDrawConfirmContent: "Please note that there will be a withdrawal fee for this transaction fee.",
                "The minimum withdrawal amount": "The minimum withdrawal amount is {moneyType} {num}",
                "The maximum withdrawal amount": "The maximum withdrawal amount is {moneyType} {num}"
            },
            result: {
                "Bet Now": "Bet Now",
                Ok: "Ok",
                Back: "Back",
                view_transaction: "View Transaction",
                transaction_progress: "Transaction in progress",
                deposit_success: "Was successfully deposited!",
                withdraw_waiting: "Your withdraw request has been submitted,it is now waiting for confirmation  you can check the Transactions in a short while.",
                withdraw_success: "Was successfully withdraw!",
                withdraw_success_tips: "The withdrawal has been successfully applied and is expected to credit within 3 working days."
            }
        }
    }
});
//# sourceMappingURL=3.169e9e9e6f62094c2976.js.map