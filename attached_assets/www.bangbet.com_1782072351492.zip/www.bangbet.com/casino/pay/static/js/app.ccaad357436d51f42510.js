webpackJsonp([26], {
    "+BTi": function(t, e) {},
    0: function(t, e, n) {
        n("j1ja"), t.exports = n("NHnr")
    },
    "6gYy": function(t, e) {},
    "8dse": function(t, e, n) {
        "use strict";
        n.d(e, "a", function() {
            return d
        });
        var a, o = n("Xxa5"),
            i = n.n(o),
            r = n("Dd8w"),
            s = n.n(r),
            u = n("exGp"),
            c = n.n(u),
            p = n("JA8L"),
            l = n("IcnI"),
            m = n("VKKs"),
            d = (a = c()(i.a.mark(function t() {
                var e, n, a, o, r, u, c, d, h, f, y, g, w;
                return i.a.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return e = p.m, n = !1, a = l.a.state.user, o = {
                                country: a.country
                            }, r = new URLSearchParams(window.top.location.search), u = r.get("url"), c = m.a.getLocal("deposit_incentive_popup_res"), d = m.a.getLocal("deposit_incentive_popup_state"), u && (h = decodeURIComponent(u), /\/promo\/RechargeBonus\/activity/.test(h) && (e = p.l, n = !0, c && (o.configId = c.configId), d && (o.levelId = d.levelId), o.pageSource = "")), t.next = 11, e(o);
                        case 11:
                            return f = t.sent, (y = f.data).levelId && window.googleEvent && window.googleEvent("depositgift", "depositgift_deposit_page_view", 0, {
                                package_id: y.levelId || "",
                                entry_source: n ? "landing" : "popup"
                            }), g = y.bannerImage || "", w = y.hasIncentive && !n && g, t.abrupt("return", s()({}, y, {
                                bannerImage: g,
                                isShowBanner: w,
                                isActivity: n
                            }));
                        case 17:
                        case "end":
                            return t.stop()
                    }
                }, t, this)
            })), function() {
                return a.apply(this, arguments)
            })
    },
    E8HH: function(t, e, n) {
        "use strict";
        var a = {
            defaultTimeout: 15e3,
            sports: {
                0: "ke",
                1: "ug",
                2: "ng",
                4: "gh",
                5: "tz"
            },
            version: "1.0.0",
            isLocal: function() {
                for (var t = window.location.host, e = ["localhost", "0.0.0", "127.0", "192."], n = 0; n < e.length; n++)
                    if (-1 != t.indexOf(e[n])) return !0;
                return !1
            },
            getApiKey: function() {
                if (!window.apiKey) {
                    var t = [{
                        key: "pre",
                        data: ["pre-"]
                    }, {
                        key: "bangbet",
                        data: ["bangbet."]
                    }, {
                        key: "bangbess",
                        data: ["bangbess."]
                    }, {
                        key: "betsure",
                        data: ["bangbet."]
                    }, {
                        key: "gbank",
                        data: [".hw."]
                    }, {
                        key: "test1",
                        data: ["test1."]
                    }, {
                        key: "test2",
                        data: ["test2."]
                    }, {
                        key: "test3",
                        data: ["test3."]
                    }, {
                        key: "test4",
                        data: ["test4."]
                    }, {
                        key: "dev",
                        data: [".dev."]
                    }, {
                        key: "sit",
                        data: [".sit."]
                    }];
                    if (this.isLocal() && (window.apiKey = "dev"), !window.apiKey) {
                        var e = window.location.host;
                        for (var n in t) {
                            for (var a = t[n].data, o = 0; o < a.length; o++)
                                if (-1 != e.indexOf(a[o])) {
                                    window.apiKey = t[n].key;
                                    break
                                }
                            if (window.apiKey) break
                        }!window.apiKey && (window.apiKey = "bangbet")
                    }
                }
                return window.apiKey
            },
            betApi: function() {
                var t = {
                        pre: "https://pre-bet-api.bangbet.com",
                        bangbet: "https://bet-api.bangbet.com",
                        bangbess: "https://bet-api.bangbet.com",
                        betsure: "https://bet-api.bangbet.com",
                        gbank: "https://bet-api.hw.luckygames.team",
                        test1: "https://bet-api.test1.luckygames.team",
                        test2: "https://bet-api.test2.luckygames.team",
                        test3: "https://bet-api.test3.luckygames.team",
                        test4: "https://bet-api.test4.luckygames.team",
                        dev: "https://bet-api.dev.luckygames.team",
                        sit: "https://sit-bet-api.hw.luckygames.team"
                    },
                    e = t[this.getApiKey()];
                return !e && (e = t.bangbet), e
            },
            casinoApi: function() {
                var t = {
                        pre: "https://pre-casino-api.bangbet.com",
                        bangbet: "https://casino-api.bangbet.com",
                        bangbess: "https://casino-api.bangbet.com",
                        betsure: "https://casino-api.bangbet.com",
                        gbank: "https://casino-api.hw.luckygames.team",
                        test1: "https://casino-api.test1.luckygames.team",
                        test2: "https://casino-api.test2.luckygames.team",
                        test3: "https://casino-api.test3.luckygames.team",
                        test4: "https://casino-api.test4.luckygames.team",
                        dev: "https://casino-api.dev.luckygames.team",
                        sit: "https://sit-casino-api.hw.luckygames.team"
                    },
                    e = t[this.getApiKey()];
                return !e && (e = t.bangbet), e
            },
            miniUrl: function() {
                var t = {
                        pre: "https://pre-minigame-apic.bangbet.com",
                        bangbet: "https://minigame-apic.bangbet.com",
                        bangbess: "https://minigame-apic.bangbet.com",
                        betsure: "https://minigame-apic.bangbet.com",
                        gbank: "https://minigame-api.hw.luckygames.team",
                        test1: "https://minigame-api.test1.luckygames.team",
                        test2: "https://minigame-api.test2.luckygames.team",
                        test3: "https://minigame-api.test3.luckygames.team",
                        test4: "https://minigame-api.test4.luckygames.team",
                        dev: "https://minigame-api.dev.luckygames.team",
                        sit: "https://sit-minigame-api.hw.luckygames.team"
                    },
                    e = t[this.getApiKey()];
                return !e && (e = t.bangbet), e
            },
            miniSocket: function() {
                var t = {
                        pre: "wss://pre-socket.bangbet.com",
                        bangbet: "wss://socket.bangbet.com",
                        bangbess: "wss://socket.bangbet.com",
                        betsure: "wss://socket.bangbet.com",
                        gbank: "wss://casino-socket.hw.luckygames.team",
                        test1: "wss://casino-socket.test1.luckygames.team",
                        test2: "wss://casino-socket.test2.luckygames.team",
                        test3: "wss://casino-socket.test3.luckygames.team",
                        test4: "wss://casino-socket.test4.luckygames.team",
                        dev: "wss://casino-socket.hw.luckygames.team",
                        sit: "wss://sit-socket.hw.luckygames.team"
                    },
                    e = t[this.getApiKey()];
                return !e && (e = t.bangbet), e
            },
            defaultCountry: "ke",
            countryList: [{
                key: "ke",
                code: "254",
                name: "Kenya",
                img: "ke.jpg",
                isShow: !0,
                alpha: "K",
                isPhoneNick: !0
            }, {
                key: "ug",
                code: "256",
                name: "Uganda",
                img: "ug.jpg",
                isShow: !0,
                alpha: "U",
                isPhoneNick: !0
            }, {
                key: "ng",
                code: "234",
                name: "Nigeria",
                img: "ng.png",
                isShow: !0,
                alpha: "N",
                isPhoneNick: !0
            }, {
                key: "in",
                code: "91",
                name: "India",
                img: "in.jpg",
                isShow: !1,
                alpha: "I",
                isPhoneNick: !1
            }, {
                key: "gh",
                code: "233",
                name: "Ghana",
                img: "gh.jpg",
                isShow: !0,
                isDefaultDemo: !1,
                isPhoneNick: !0
            }, {
                key: "tz",
                code: "255",
                name: "Tanzania",
                img: "gh.jpg",
                isShow: !0,
                isDefaultDemo: !1,
                isPhoneNick: !0
            }]
        };
        e.a = a
    },
    IcnI: function(t, e, n) {
        "use strict";
        var a = n("bOdI"),
            o = n.n(a),
            i = n("oAV5"),
            r = n("p0QZ"),
            s = {
                setUser: function(t, e) {
                    t.user = Object(i.i)(t.user, e, !0), Object(r.b)()
                },
                setParams: function(t, e) {
                    !t.user && (t.user = {}), e.token && (t.user.token = e.token), e.secretKey && (t.user.secretKey = e.secretKey), e.country && (t.user.country = e.country), e.balance && (t.user.balance = e.balance), e.platform && (t.platform = e.platform), 0 != e.amount && e.amount && (t.depositMoney = e.amount), e.type && (t.type = e.type), t.uriParams = e
                },
                setDepositMoney: function(t, e) {
                    t.depositMoney = e
                },
                SET_LIMIT: function(t, e) {
                    t.min = e.min, t.max = e.max
                },
                SET_CARD_LIST: function(t, e) {
                    t.cardList = e
                },
                SET_TAB_LIST: function(t, e) {
                    t.tabList = e
                },
                SET_AMOUNT_LIST: function(t, e) {
                    t.amountList = e
                },
                SET_BACKEVENT_STATUS: function(t, e) {
                    t.backEeventStatus = e
                },
                setDepositGiftStatus: function(t, e) {
                    t.depositGiftStatus = e
                },
                setDepositGiftRate: function(t, e) {
                    t.depositGiftRate = e
                },
                setDepositGiftList: function(t, e) {
                    t.depositGiftList = e
                },
                SET_DEPOSIT_DATA: function(t, e) {
                    t.depositResult = e
                },
                SET_WITHDRAW_DATA: function(t, e) {
                    t.withdrawResult = e
                },
                setFirstBonusObj: function(t, e) {
                    t.firstBonus = e
                }
            },
            u = {},
            c = n("E8HH"),
            p = {
                userInfo: function(t) {
                    return t.user
                },
                hasDepositIncentive: function(t) {
                    console.log("state.user", t);
                    var e = t.user || {},
                        n = e.depositIncentiveEligible,
                        a = e.depositIncentiveWhitelist;
                    return !(!n && !a)
                },
                authData: function(t) {
                    return t.user && t.user.token && t.user.secretKey ? {
                        token: t.user.token,
                        secretKey: t.user.secretKey
                    } : null
                },
                getPlatfrom: function(t) {
                    return Object(i.g)() ? 13 : t.platform
                },
                country: function(t) {
                    var e = t.user.country,
                        n = !1;
                    for (var a in c.a.countryList) c.a.countryList[a].key == e && (n = !0);
                    return n || (e = c.a.defaultCountry), e
                },
                getDepositMoney: function(t) {
                    return t.depositMoney
                },
                getUriParams: function(t) {
                    return t.uriParams
                },
                cardList: function(t) {
                    return t.cardList
                },
                tabList: function(t) {
                    return t.tabList
                },
                amountList: function(t) {
                    return t.amountList
                },
                backEeventStatus: function(t) {
                    return t.backEeventStatus
                },
                depositGiftStatus: function(t) {
                    return t.depositGiftStatus
                },
                depositGiftList: function(t) {
                    return t.depositGiftList
                },
                depositGiftRate: function(t) {
                    return t.depositGiftRate
                },
                max: function(t) {
                    return t.max
                },
                min: function(t) {
                    return t.min
                },
                depositResult: function(t) {
                    return t.depositResult
                },
                withdrawResult: function(t) {
                    return t.withdrawResult
                }
            },
            l = n("424j"),
            m = n("VKKs");
        Vue.use(Vuex);
        e.a = new Vuex.Store({
            state: function() {
                var t;
                return t = {
                    loadedLanguages: [],
                    depositMoney: 0,
                    platform: 3,
                    uriParams: {},
                    user: m.a.getLocal("login-token") || {
                        country: "ke"
                    },
                    cardList: [],
                    bankList: [],
                    tabList: [],
                    amountList: [],
                    backEeventStatus: !1,
                    lang: "sw"
                }, o()(t, "loadedLanguages", []), o()(t, "max", 999999999), o()(t, "min", 0), o()(t, "depositResult", null), o()(t, "withdrawResult", null), o()(t, "depositGiftStatus", !1), o()(t, "depositGiftList", []), o()(t, "depositGiftRate", 0), o()(t, "firstBonus", {
                    min: 0,
                    max: 9999999,
                    rate: 0,
                    status: !1,
                    registerActivityConfList: []
                }), t
            },
            mutations: s,
            actions: u,
            getters: p,
            modules: {},
            strict: !1,
            plugins: [Object(l.a)({
                key: "bangpayPersisted",
                storage: window.localStorage,
                reducer: function(t) {
                    return {
                        user: t.user,
                        platform: t.platform,
                        uriParams: t.uriParams,
                        amountList: t.amountList
                    }
                }
            })]
        })
    },
    JA8L: function(t, e, n) {
        "use strict";
        var a = n("Dd8w"),
            o = n.n(a),
            i = n("mvHQ"),
            r = n.n(i),
            s = n("mtWM"),
            u = n.n(s),
            c = n("mw3O"),
            p = n("E8HH"),
            l = {
                200: "服务器成功返回请求的数据。",
                201: "新建或修改数据成功。",
                202: "一个请求已经进入后台排队（异步任务）。",
                204: "删除数据成功。",
                400: "发出的请求有错误，服务器没有进行新建或修改数据的操作。",
                401: "用户没有权限（令牌、用户名、密码错误）。",
                403: "用户得到授权，但是访问是被禁止的。",
                404: "发出的请求针对的是不存在的记录，服务器没有进行操作。",
                406: "请求的格式不可得。",
                408: "请求失败了",
                410: "请求的资源被永久删除，且不会再得到的。",
                422: "当创建一个对象时，发生一个验证错误。",
                500: "服务器发生错误，请检查服务器。",
                502: "网关错误。",
                503: "服务不可用，服务器暂时过载或维护。",
                504: "网关超时。"
            },
            m = function(t) {
                return -1 != t.indexOf("http://") || -1 != t.indexOf("https://") ? t : t = p.a.betApi() + t
            },
            d = function(t) {
                if (t.status >= 200 && t.status < 300) {
                    t.data && (9 == t.data.result || 104 == t.data.result || 105 == t.data.result || t.data.result);
                    return t
                }
                var e = l[t.status] || t.statusText,
                    n = new Error(e);
                throw n.name = t.status, n.response = t, n
            };

        function h(t) {
            return g({
                method: "post",
                data: "string" != typeof t.params ? r()(t.params) : t.params,
                headers: t.headers || {
                    "Content-Type": "application/json; charset=utf-8"
                },
                url: m(t.url),
                timeout: t.timeout || p.a.defaultTimeout
            })
        }

        function f(t) {
            var e = {
                method: "post",
                data: Object(c.stringify)(t.params),
                headers: t.headers || {
                    Accept: "application/json",
                    "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"
                },
                url: m(t.url),
                timeout: t.timeout || p.a.defaultTimeout
            };
            return t.responseType && (e.responseType = t.responseType), g(e)
        }

        function y(t) {
            var e = {
                method: "get",
                headers: t.headers || {
                    Accept: "application/json"
                },
                params: t.params,
                url: m(t.url),
                timeout: t.timeout
            };
            return t.responseType && (e.responseType = t.responseType), g(e)
        }

        function g(t) {
            !window.tryCounter && (window.tryCounter = {});
            var e = o()({}, t),
                n = o()({}, {}, e);
            return "post" === n.method || "put" === n.method || n.method, u.a.request(n).then(d).then(function(e) {
                return window.tryCounter[t.url] && delete window.tryCounter[t.url], e.data
            }).then(function(e) {
                return window.tryCounter[t.url] && delete window.tryCounter[t.url], a = (n = e).info, o = n.arrs, Array.isArray(o) && "string" == typeof a && (o.forEach(function(t) {
                    a = a.replace("%s", t)
                }), n.info = a), n;
                var n, a, o
            }).catch(function(e) {
                if (console.log("request error = ", e), e.response ? (console.log("error.response.data = ", e.response.data), console.log("error.response.status = ", e.response.status), console.log("error.response.headers = ", e.response.headers)) : e.request ? console.log("error.request = ", e.request) : console.log("error.message = ", e.message), console.log("error.config = ", e.config), !window.tryCounter[t.url] && (window.tryCounter[t.url] = 0), window.tryCounter[t.url]++, window.tryCounter[t.url] < 3) return g(t)
            })
        }
        var w = n("fZjL"),
            b = n.n(w),
            k = n("pFYg"),
            v = n.n(k),
            A = n("IcnI"),
            T = n("NC6I"),
            S = n.n(T);
        n("VKKs");

        function C(t, e) {
            var n = "",
                a = "",
                o = A.a.getters.authData;
            o && o.token && (n = o.token, a = o.secretKey);
            var i = t.toUpperCase(),
                s = "",
                u = "";
            "POSTJSON" == i ? s = e ? r()(e) : "" : u = e ? function t(e, n, a) {
                null == e && (e = "");
                var o = [],
                    i = void 0 === e ? "undefined" : v()(e);
                if ("string" == i || "number" == i || "boolean" == i) o.push(n + "=" + e);
                else
                    for (var r in e) {
                        var s = null == n ? r : n + (e instanceof Array ? "[" + r + "]" : "." + r);
                        o.push(t(e[r], s, a))
                    }
                return o.join("&")
            }(function(t) {
                for (var e = b()(t).sort(), n = {}, a = 0; a < e.length; a++) n[e[a]] = t[e[a]];
                return n
            }(e)) : "";
            var c = S()(s).toString(),
                p = (new Date).getTime().toString(),
                l = S()(n + a + p + u + c).toString(),
                m = {};
            switch (i) {
                case "GET":
                    m = {
                        Accept: "application/json",
                        token: n,
                        time: p,
                        r: l
                    };
                    break;
                case "POSTFORM":
                    m = {
                        Accept: "application/json",
                        "Content-Type": "application/x-www-form-urlencoded; charset=utf-8",
                        token: n,
                        time: p,
                        r: l
                    };
                    break;
                case "POSTJSON":
                    m = {
                        "Content-Type": "application/json; charset=utf-8",
                        token: n,
                        time: p,
                        r: l
                    }
            }
            return m
        }
        e.t = function(t) {
            return y({
                url: I + "/api/payments/depositResult",
                params: o()({}, t),
                headers: C("get", t)
            })
        }, e.A = function(t) {
            return y({
                url: I + "/api/common/info",
                headers: C("get", t),
                params: o()({}, t)
            })
        }, e.M = function() {
            return y({
                url: I + "/api/payments/depositResultNew",
                headers: C("get", {})
            })
        }, e.P = function() {
            return h({
                url: I + "/api/payments/withdraw/status",
                params: {},
                headers: C("postJson", {})
            })
        }, e.r = function(t) {
            return y({
                url: I + "/api/payments/common/jumpUrls",
                params: o()({}, t),
                headers: C("get", {
                    params: t
                })
            })
        }, e.y = function(t) {
            return y({
                url: P + "/api/bet/system/depositPage/homeMenu",
                params: o()({}, t),
                headers: C("get", {
                    params: t
                })
            })
        }, e.L = function(t) {
            return y({
                url: I + "/api/partner/user/getOneTouchGameUrl",
                params: o()({}, t),
                headers: C("get", t)
            })
        }, e._25 = function(t) {
            return y({
                url: I + "/api/payments/common/payRange",
                params: o()({}, t),
                headers: C("get", t)
            })
        }, e.q = function(t) {
            return f({
                url: "/api/bet/user/userInfo",
                params: o()({}, t),
                headers: C("postForm", t)
            })
        }, e.c = function(t) {
            return h({
                url: I + "/api/payments/mpesa/onlinePay",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.i = function(t) {
            return h({
                url: I + "/api/center/checkNinInfo",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._29 = function(t) {
            return h({
                url: I + "/api/center/user/updateNin",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._26 = function(t) {
            return h({
                url: I + "/api/payments/mpesa/deposit/confirm",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.b = function(t) {
            return h({
                url: I + "/api/payments/hubtel/deposit",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.T = function(t) {
            return h({
                url: I + "/api/payments/payList/deposit/gh",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._32 = function(t) {
            return h({
                url: I + "/api/payments/airtelbackend/deposit",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._33 = function(t) {
            return h({
                url: I + "/api/payments/airtelbackend/withdraw",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._4 = function(t) {
            return h({
                url: I + "/api/payments/paystack/create/order",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._2 = function(t) {
            return h({
                url: I + "/api/payments/palm/v2/deposit/h5",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.Z = function(t) {
            return h({
                url: I + "/api/payments/palm/v2/deposit/bankTransfer",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._3 = function(t) {
            return h({
                url: I + "/api/payments/deposit/ng/list",
                headers: C("postJson", t),
                params: o()({}, t)
            })
        }, e._34 = function(t) {
            return h({
                url: I + "/api/payments/deposit/Ug",
                headers: C("postJson", t),
                params: o()({}, t)
            })
        }, e._24 = function() {
            return y({
                url: I + "/api/center/nin/switch?country=ug"
            })
        }, e.p = function(t) {
            return h({
                url: I + "/api/payments/flutter/create/order",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.n = function(t) {
            return h({
                url: I + "/api/payments/depositIntroduce",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.X = function(t) {
            return y({
                url: I + "/api/payments/depositConfig/listByCountry",
                params: o()({}, t),
                headers: C("get", t)
            })
        }, e.o = function(t) {
            return h({
                url: I + "/api/payments/airtelbackend/paymentStatus",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._11 = function(t) {
            return h({
                url: I + "/api/payments/opay/deposit",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._10 = function(t) {
            return h({
                url: I + "/api/payments/opay/bankDeposit",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._1 = function(t) {
            return y({
                url: I + "/api/payments/paystack/delUserAuth",
                params: o()({}, t),
                headers: C("get", t)
            })
        }, e._6 = function(t) {
            return h({
                url: I + "/api/payments/paystack/userDepositTokenList",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._21 = function(t) {
            return h({
                url: I + "/api/payments/preWithdraw",
                headers: C("postJson", t)
            })
        }, e.g = function(t) {
            return h({
                url: I + "/api/payments/paystack/cardDeposit",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.j = function(t) {
            return h({
                url: I + "/api/payments/paystack/submit",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.O = function() {
            return y({
                url: I + "/api/payments/paystack/deposit/ussds",
                headers: C("postForm")
            })
        }, e.N = function(t) {
            return h({
                url: I + "/api/payments/paystack/newUssd",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._9 = function(t) {
            return h({
                url: I + "/api/payments/paystack/depositUseAuth",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.V = function(t) {
            return h({
                url: I + "/api/payments/defaultWithdrawtype",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.a = function(t) {
            return y({
                url: I + "/api/payments/checkWithdrawAmount",
                params: o()({}, t),
                headers: C("get", t)
            })
        }, e.d = function(t) {
            return h({
                url: I + "/api/payments/mpesa/withdraw",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.e = function(t) {
            return h({
                url: I + "/api/payments/airtel/withdraw",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._7 = function(t) {
            return y({
                url: I + "/api/payments/freeWithdrawInfo",
                params: o()({}, t),
                headers: C("get", t)
            })
        }, e.U = function(t) {
            return h({
                url: I + "/api/payments/hubtel/withdraw",
                params: t,
                headers: C("postJson", t)
            })
        }, e._20 = function(t) {
            return h({
                url: I + "/api/payments/paystack/bankAccountName",
                headers: C("postJson", t),
                params: o()({}, t)
            })
        }, e._22 = function(t) {
            return h({
                url: I + "/api/payments/paystack/newValidateBankAccount",
                headers: C("postJson", t),
                params: o()({}, t)
            })
        }, e._23 = function(t) {
            return h({
                url: I + "/api/payments/paystack/validateBankAccountName",
                headers: C("postJson", t),
                params: o()({}, t)
            })
        }, e._13 = function(t) {
            return h({
                url: I + "/api/payments/opay/withdraw/check",
                params: t,
                headers: C("postJson", t)
            })
        }, e._15 = function(t) {
            return h({
                url: I + "/api/payments/palm/check/history",
                params: t,
                headers: C("postJson", t)
            })
        }, e._14 = function(t) {
            return h({
                url: I + "/api/payments/palm/withdraw",
                params: t,
                headers: C("postJson", t)
            })
        }, e._12 = function(t) {
            return h({
                url: I + "/api/payments/opay/withdraw",
                params: t,
                headers: C("postJson", t)
            })
        }, e._17 = function(t) {
            return h({
                url: I + "/api/payments/paystack/banks",
                headers: C("postJson", t)
            })
        }, e.G = function(t) {
            return h({
                url: I + "/api/payments/sms/code",
                params: o()({}, t)
            })
        }, e.F = function(t) {
            return h({
                url: I + "/api/payments/sms/code/voice",
                params: o()({}, t)
            })
        }, e.f = function(t) {
            return h({
                url: I + "/api/payments/sms/voice/call",
                params: o()({}, t)
            })
        }, e.k = function(t) {
            return h({
                url: I + "/api/center/checkCode",
                params: o()({}, t)
            })
        }, e._0 = function(t) {
            return h({
                url: I + "/api/payments/paystack/validateBankAccount",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._19 = function(t) {
            return h({
                url: I + "/api/payments/paystack/userRecipient",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._5 = function(t) {
            return h({
                url: I + "/api/payments/paystack/withdraw",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._28 = function(t) {
            return h({
                url: I + "/api/center/user/updateUserInfo",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._37 = function(t) {
            return h({
                url: I + "/api/payments/information",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._16 = function(t) {
            return h({
                url: I + "/api/payments/ng/informationnew",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._36 = function(t) {
            return y({
                url: I + "/api/payments/isNew",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._18 = function(t) {
            return y({
                url: I + "/api/payments/paystack/delUserRecipient",
                params: o()({}, t),
                headers: C("get", t)
            })
        }, e._27 = function(t) {
            return h({
                url: "/api/bet/bang/actionRecord",
                params: o()({}, t)
            })
        }, e.x = function(t) {
            return y({
                url: I + "/api/payments/hubtel/withdrawTax",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.R = function(t) {
            return h({
                url: I + "/api/payments/paystack/withdrawmaxamount",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._8 = function(t) {
            return h({
                url: I + "/api/payments/monnify/deposit",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.w = function(t) {
            return y({
                url: I + "/api/center/bonus/getUserRechargeActivityPara",
                params: t,
                headers: C("get", t)
            })
        }, e.u = function(t) {
            return y({
                url: I + "/api/payments/common/getDepositTips",
                params: t,
                headers: C("get", t)
            })
        }, e.Y = function() {
            return y({
                url: I + "/api/payments/deposit/ng/activity",
                headers: C("get")
            })
        }, e.H = function() {
            return h({
                url: I + "/api/payments/recentPayType",
                headers: C("postJson")
            })
        }, e.D = function(t) {
            return h({
                url: I + "/api/payments/ng/isNeedBvn",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.J = function() {
            return h({
                url: I + "/api/payments/payList/deposit/ug",
                headers: C("postJson")
            })
        }, e.K = function() {
            return h({
                url: I + "/api/payments/payList/withdraw/ug",
                headers: C("postJson")
            })
        }, e._35 = function(t) {
            return h({
                url: I + "/api/payments/withdraw/ug",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.s = function(t) {
            return y({
                url: "/api/bet/activityCoupon/getUserDepositAward",
                params: t,
                headers: C("get", t)
            })
        }, e.z = function(t) {
            return h({
                url: I + "/api/payments/pay/method?country=" + t.country + "&type=" + t.type,
                params: t,
                headers: C("postJson", t)
            })
        }, e.I = function() {
            return h({
                url: I + "/api/payments/payList/deposit/tz",
                headers: C("postJson")
            })
        }, e._30 = function(t) {
            return h({
                url: I + "/api/payments/fasthub/depositDebit",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e._31 = function(t) {
            return h({
                url: I + "/api/payments/fasthub/withdraw",
                params: o()({}, t),
                headers: C("postJson", t),
                timeout: 6e4
            })
        }, e.W = function(t) {
            return h({
                url: I + "/api/payments/deposit/subsidyConfig",
                params: o()({}, t),
                headers: C("postJson", t)
            })
        }, e.E = function() {
            return y({
                url: I + "/api/center/orders/history",
                headers: C("get", {})
            })
        }, e.C = function(t) {
            return y({
                url: I + "/api/payments/depositConfig/listSpecByCountry",
                params: t,
                headers: C("get", t)
            })
        }, e.B = function(t) {
            return y({
                url: "/api/bet/depositActivity/listDepositBonus",
                params: t,
                headers: C("get", t)
            })
        }, e.h = function(t) {
            return y({
                url: I + "/api/payments/depositConfig/checkTax",
                params: t,
                headers: C("get", t)
            })
        }, e.S = function(t) {
            return h({
                url: I + "/api/payments/mpesa/onlinePay/minimpesa",
                params: t,
                headers: C("get", t)
            })
        }, e.v = function(t) {
            return y({
                url: I + "/api/payments/tax/rule/ke/deposit",
                params: t,
                headers: C("get", t)
            })
        }, e.Q = function(t) {
            return y({
                url: I + "/api/payments/tax/rule/ke/withdraw",
                params: t,
                headers: C("get", t)
            })
        }, e.m = function(t) {
            return f({
                url: P + "/api/bet/activity/depositIncentive/entry",
                params: t,
                headers: C("postForm", t)
            })
        }, e.l = function(t) {
            return f({
                url: P + "/api/bet/activity/depositIncentive/benefits",
                params: t,
                headers: C("postForm", t)
            })
        };
        var I = p.a.casinoApi(),
            P = p.a.betApi()
    },
    L1rD: function(t, e) {},
    LAJP: function(t, e, n) {
        "use strict";
        e.k = p, e.h = function(t) {
            var e = {
                cmd: r.a.PARENT_CMD.SUCCESS
            };
            p(t, e)
        }, e.l = function(t) {
            var e = {
                cmd: r.a.PARENT_CMD.LIVECHAT
            };
            window.bangbetInterface && window.bangbetInterface.showAIHelp && !window.isBangbetCasinoDomain ? window.bangbetInterface.showAIHelp() : p(t, e)
        }, e.i = function(t) {
            var e = {
                cmd: r.a.PARENT_CMD.PRELOAD
            };
            p(t, e)
        }, e.e = function() {
            var t = "";
            window.bangbetInterface && window.bangbetInterface.showWhatsApp ? window.bangbetInterface.showWhatsApp() : u && u.callHandler ? m(t = "https://wa.me/" + l()) : (t = "https://wa.me/" + l(), window.open(t, "_blank"))
        }, e.g = m, e.a = function(t) {
            var e = {
                cmd: r.a.PARENT_CMD.CANCEL
            };
            p(t, e)
        }, e.d = function(t, e) {
            var n = function() {
                    var t = window.location.href.split("?"),
                        e = t.length > 1 ? t[t.length - 1] : "",
                        n = {};
                    if (d(e, n), window.top.localStorage) {
                        var a = window.top.localStorage.getItem("toBangPayUri");
                        a && -1 != a.indexOf("&") && d(e = a, n)
                    }
                    return n
                }(),
                a = c();
            if (a) {
                window.self !== window.top || delete n.type, n = Object(i.i)(n, function(t) {
                    var e = {};
                    if (t.getComprehensiveQuickPaymentInfo) {
                        var n = t.getComprehensiveQuickPaymentInfo(),
                            a = t.getCountry();
                        n && -1 != n.indexOf("{") && ((n = JSON.parse(n)).platfrom && (e.platfrom = n.platfrom), a && (e.country = a), n.secret && (e.secretKey = n.secret), n.token && (e.token = n.token))
                    }
                    return e
                }(a), !0);
                var o = window.location.hash.split("#")[1] || "";
                o && /withdraw/i.test(o) ? n.type = "withdraw" : n.type || (n.type = "deposit")
            }
            t.$store.commit("setParams", n);
            var r = {
                platform: 3,
                isLogin: !0
            };
            if (n.platform && (r.platform = n.platform), !n.country) {
                var u = t.$store.getters.userInfo;
                u.country && (n.country = u.country)
            }
            n.isPreTesting || setTimeout(function() {
                Object(s.q)(r).then(function(n) {
                    1 == n.result ? (t.$store.commit("setUser", n.data), e(n.data.country)) : e(!1)
                }).catch(function(t) {
                    e(!1)
                })
            }, 50);
            return n
        }, e.f = function() {
            if (window.localStorage) {
                var t = window.localStorage.getItem("fingerPrint");
                if (!t) {
                    var e = window.location.protocol + "//" + window.location.host;
                    h(e + "/static/fp.min.js?v=1.1", !0, function() {
                        FingerprintJS.load().then(function(t) {
                            t.get().then(function(t) {
                                t.visitorId ? window.localStorage.setItem("fingerPrint", t.visitorId) : window.localStorage.setItem("fingerPrint", function() {
                                    var t = null;
                                    if (window.localStorage && (t = window.localStorage.getItem("unique-udid")), !t) {
                                        var e = function() {
                                            return (65536 * (1 + Math.random()) | 0).toString(16).substring(1)
                                        };
                                        t = e() + e() + "-" + e() + "-" + e() + "-" + e() + "-" + e() + e() + e(), window.localStorage && window.localStorage.setItem("unique-udid", t)
                                    }
                                    return t
                                }())
                            })
                        })
                    })
                }
            }
        }, e.j = function(t, e) {
            if (!e) return;
            if (!t || !t.$store || !t.$store.state) return;
            var n = window.location.protocol + "//" + window.location.host;
            "/" != window.location.pathname && (n += "/" + window.location.pathname);
            var a = "";
            if (window.top && window.top.window) {
                var o = window.top.window;
                o.navigator && o.navigator.userAgent && (a = o.navigator.userAgent), n = o.location.protocol + "//" + o.location.host, "/" != o.location.pathname && (n += "/" + o.location.pathname)
            }
            var i = "",
                r = t.$store.getters.getUriParams;
            r.cn && (i = r.cn);
            var u = t.$store.getters.country,
                c = {
                    clientId: (p = null, window.localStorage && (p = window.localStorage.getItem("fingerPrint")), !p && (p = "0"), p),
                    userId: 0,
                    userName: "",
                    country: u,
                    channel: i,
                    category: "",
                    act: "",
                    val: 0,
                    step: 0,
                    fromType: "h5",
                    uri: n,
                    status: 0,
                    error_code: "",
                    error_info: "",
                    ua: a,
                    cts: (new Date).getTime(),
                    isClient: 1,
                    platform: t.$store.getters.getPlatfrom
                };
            var p;
            for (var l in e) - 1 != l.indexOf("paramStr") || "error_code" == l ? c[l] = e[l] + "" : c[l] = e[l];
            var m = t.$store.state.user;
            m.userId && (c.userId = m.userId, c.userName = m.username);
            Object(s._27)(c)
        }, e.c = f, e.b = function(t) {
            var e = new Date;
            e.setTime(e.getTime() - 1);
            var n = f(t);
            null != n && (document.cookie = t + "=" + n + ";expires=" + e.toGMTString())
        };
        var a = n("mvHQ"),
            o = n.n(a),
            i = n("oAV5"),
            r = n("Zpiv"),
            s = n("JA8L"),
            u = window.flutter_inappwebview;

        function c() {
            return window.bangbetInterface
        }

        function p(t, e) {
            var n = c(),
                a = t.$store.getters.getUriParams,
                o = a.orig;
            if (window.isBangbetCasinoDomain) return o && (o = decodeURIComponent(o)), !o && (o = Object(i.e)()), void setTimeout(function() {
                window.parent.postMessage(e, o)
            }, 150);
            if (n)
                if (e.cmd == r.a.PARENT_CMD.SUCCESS) {
                    if (!a.amount) return;
                    !e.data && (e.data = {}), e.data.amount = a.amount, n.setComprehensiveQuickPaymentResult && n.setComprehensiveQuickPaymentResult(e)
                } else e.cmd == r.a.PARENT_CMD.CANCEL ? n.closeUi && setTimeout(function() {
                    n.closeUi()
                }, 150) : e.cmd == r.a.PARENT_CMD.LIVECHAT ? n.showAIHelp && n.showAIHelp() : e.cmd == r.a.PARENT_CMD.WHATSAPP ? n.showWhatsApp && n.showWhatsApp() : "paystack" == e.cmd && (o && (o = decodeURIComponent(o)), !o && (o = Object(i.e)()), setTimeout(function() {
                    window.parent.postMessage(e, o)
                }, 150));
            else o && (o = decodeURIComponent(o)), !o && (o = Object(i.e)()), setTimeout(function() {
                window.parent.postMessage(e, o)
            }, 150)
        }

        function l() {
            var t = JSON.parse(window.localStorage.getItem("license.config")).contactInformation;
            if (t) {
                var e = "";
                return t.forEach(function(t) {
                    3 == t.type && (e = t.information[0].value)
                }), e
            }
            return ""
        }

        function m(t) {
            if (!u || !u.callHandler) return !1;
            var e = {
                    type: "openStartUrl",
                    url: t
                },
                n = o()(e);
            return u.callHandler("BangbetBridge", [n])
        }

        function d(t, e) {
            for (var n = t.split("&"), a = 0; a < n.length; a++) {
                var o = n[a].split("="),
                    r = Object(i.l)(o[0]);
                if (o.length >= 2)
                    if (-1 !== ["userToken", "secretKey"].indexOf(r)) {
                        if (!o[1] || "null" == o[1] || "" == Object(i.l)(o[1])) continue;
                        try {
                            e[r] = decodeURIComponent(Object(i.l)(o[1]))
                        } catch (t) {
                            e[r] = Object(i.l)(o[1])
                        }
                    } else e[r] = Object(i.l)(o[1]);
                else !e.cn && (e.cn = r)
            }
            return e
        }

        function h(t, e, n) {
            var a = !1,
                o = document.getElementsByTagName("script");
            !o && (o = []);
            for (var i = 0; i < o.length; i++)
                if (o[i].src == t) {
                    a = !0;
                    break
                }
            if (a) n && n();
            else {
                var r = document.createElement("script");
                r.async = e, r.src = t, r.charset = "UTF-8", r.setAttribute("crossorigin", "*"), n && (r.onload = n), o && o[0] ? o[0].parentNode.insertBefore(r, o[0]) : document.getElementsByTagName("head")[0].appendChild(r)
            }
        }

        function f(t) {
            var e, n = new RegExp("(^| )" + t + "=([^;]*)(;|$)");
            return (e = document.cookie.match(n)) ? unescape(e[2]) : null
        }
    },
    NHnr: function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var a = {};
        n.d(a, "formatCurrency", function() {
            return Y
        }), n.d(a, "thousandthPormat", function() {
            return q
        }), n.d(a, "formatThousand", function() {
            return Z
        });
        var o = n("fZjL"),
            i = n.n(o),
            r = (n("j1ja"), n("Xxa5")),
            s = n.n(r),
            u = n("exGp"),
            c = n.n(u),
            p = n("LAJP"),
            l = n("Zpiv"),
            m = n("Dd8w"),
            d = n.n(m),
            h = n("SJI6"),
            f = n("JA8L"),
            y = n("oAV5"),
            g = n("8dse"),
            w = n("VKKs"),
            b = {
                name: "Header",
                props: {
                    title: {
                        type: String,
                        default: ""
                    },
                    isBack: {
                        type: Boolean,
                        default: !1
                    }
                },
                data: function() {
                    return {
                        isShowFree: !1,
                        depositIncentiveInfo: {}
                    }
                },
                computed: d()({}, Object(h.mapGetters)(["country", "hasDepositIncentive"]), {
                    activityType: function() {
                        return Object(y.d)()
                    },
                    showReturn: function() {
                        return console.log("this.activityType", this.activityType), !!this.activityType
                    },
                    showRoter: function() {
                        if (console.log("this.$route.name", this.$route.name), "result" === this.$route.name) return !0
                    },
                    transHeader: function() {
                        if ("Withdraw" == this.title || "Deposit" == this.title) {
                            var t = this.$t("str." + this.title);
                            return t == "str." + this.title ? this.title : t
                        }
                        return this.title
                    },
                    depositResult: function() {
                        return w.a.getSession("depositResult") || null
                    },
                    isDepositSuccess: function() {
                        return 1 == this.depositResult.result
                    }
                }),
                watch: {},
                beforeDestroy: function() {},
                mounted: function() {
                    localStorage.getItem("login-token") && window && window.self !== window.top && this.getStatus(), this.depositIncentive()
                },
                methods: {
                    goBack: function() {
                        this.$emit("onClose")
                    },
                    goClose: function() {
                        if (window.googleEvent && window.googleEvent("paymentui", "Deposit_Page_Close", 0), localStorage.getItem("isLanding")) {
                            localStorage.removeItem("isLanding");
                            var t = window.location.origin;
                            window.location.href = t
                        } else this.showRoter && this.showReturn ? Object(y.h)() : this.$emit("onClose")
                    },
                    getStatus: function() {
                        var t = this;
                        return c()(s.a.mark(function e() {
                            var n, a, o, i;
                            return s.a.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return n = "Withdraw" == t.title ? Object(f.Q)() : Object(f.v)(), e.next = 3, n;
                                    case 3:
                                        a = e.sent, o = a.data, 1 == a.result && (i = "Withdraw" == t.title ? o.payTaxVo.freeTaxWithDrawStatus : o.payTaxVo.freeTaxStatus, t.isShowFree = "0" != i);
                                    case 7:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, t)
                        }))()
                    },
                    depositIncentive: function() {
                        var t = this;
                        return c()(s.a.mark(function e() {
                            var n;
                            return s.a.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, Object(g.a)();
                                    case 2:
                                        n = e.sent;
                                        try {
                                            n && (console.log("res", n), t.depositIncentiveInfo = n || {})
                                        } catch (t) {}
                                    case 4:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, t)
                        }))()
                    }
                }
            },
            k = {
                render: function() {
                    var t = this,
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("div", {
                        staticClass: "header",
                        class: {
                            "header--return": t.showReturn
                        },
                        on: {
                            touchmove: function(t) {
                                t.preventDefault()
                            }
                        }
                    }, [n("div", {
                        staticClass: "title"
                    }, [t.isBack ? n("div", {
                        staticClass: "title-back",
                        on: {
                            click: function(e) {
                                return e.stopPropagation(), t.goBack.apply(null, arguments)
                            }
                        }
                    }, [n("i", {
                        staticClass: "iconfont icon-Icon_Back_40 back-icon"
                    })]) : t._e(), t._v(" "), t.showRoter || !t.showReturn || t.isBack ? t._e() : n("div", {
                        staticClass: "title-back",
                        on: {
                            click: function(e) {
                                return e.stopPropagation(), t.goBack.apply(null, arguments)
                            }
                        }
                    }, [n("i", {
                        staticClass: "iconfont icon-Icon_Back_40 back-icon"
                    })]), t._v(" "), n("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: "payResult" != t.$route.name,
                            expression: "$route.name != 'payResult'"
                        }],
                        staticClass: "title-text"
                    }, [t._v("\n          " + t._s(t.transHeader) + "\n          "), "ke" == t.country && t.isShowFree ? n("div", {
                        staticClass: "tax-free"
                    }, [t._v(t._s(t.title) + " Tax-Free!")]) : t._e()])]), t._v(" "), !t.showReturn || t.showRoter ? n("div", {
                        staticClass: "close",
                        on: {
                            click: function(e) {
                                return e.stopPropagation(), t.goClose.apply(null, arguments)
                            }
                        }
                    }, [n("i", {
                        staticClass: "iconfont icon-Icon_Close_40 close-icon"
                    })]) : t._e()])
                },
                staticRenderFns: []
            };
        var v = n("VU/8")(b, k, !1, function(t) {
                n("L1rD")
            }, "data-v-23b270df", null).exports,
            A = n("//Fk"),
            T = n.n(A),
            S = n("TXmL"),
            C = n("IcnI");
        Vue.use(S.a);
        var I = new S.a({
            locale: C.a.state.lang,
            silentTranslationWarn: !0
        });

        function P(t) {
            return console.log("----------------------------\x3e", t), I.locale = t, t
        }

        function B(t) {
            C.a.state.country;
            var e = "" + t;
            return C.a.state.loadedLanguages.includes(e) ? (P(e), T.a.resolve(e)) : n("lgBR")("./" + e).then(function(t) {
                return I.setLocaleMessage(e, t), C.a.state.loadedLanguages.push(e), P(e)
            })
        }
        var N = I,
            _ = {
                common: ["common-height-fa", "common-height-ch"],
                middle: ["middle-height-fa", "middle-height-ch"]
            },
            D = {
                name: "App",
                components: {
                    PayHeader: v
                },
                provide: function() {
                    return {
                        ngResetBodyHeight: this.ngResetBodyHeight,
                        goTransactions: this.goTransactions,
                        showMask: this.showMask,
                        shutMask: this.shutMask,
                        onClose: this.onClose
                    }
                },
                data: function() {
                    return {
                        titleName: "Deposit",
                        tempTitle: "Deposit",
                        isTitleBack: !1,
                        heightClassFa: "common-height-fa",
                        heightClassCh: "common-height-ch",
                        cartoonClass: "animated fadeInUp",
                        isMask: !0,
                        maskText: "Loading",
                        anotherClass: "",
                        notAppAnotherClass: ""
                    }
                },
                created: function() {
                    var t = this,
                        e = Object(p.c)("toast"),
                        n = Object(p.d)(this, function(e) {
                            e || t.$router.push({
                                path: "/"
                            })
                        });
                    e && 2 == e && (this.$toast.show({
                        text: "Deposit to Place Bet",
                        time: "2000",
                        color: "#0D9737"
                    }), Object(p.b)("toast")), n.isPreTesting || (!n.type && (n.type = this.$store.state.type), !n.country && (n.country = this.$store.getters.country), n.country && (this.getBonusStatus(n.country), this.getDepositGiftStatus(n.country), "withdraw" == n.type ? this.$router.push({
                        path: "/" + n.country + "Withdraw",
                        query: {
                            rand: Math.random()
                        }
                    }) : this.$router.replace({
                        path: "/" + n.country,
                        query: {
                            rand: Math.random()
                        }
                    })));
                    var a = this;
                    window.selfReportAction = function(t) {
                        a.$nextTick(function() {
                            Object(p.j)(a, t)
                        })
                    }, window.updateGiftInfo = function(e) {
                        t.getDepositGiftStatus(n.country)
                    }
                },
                mounted: function() {
                    var t = this;
                    Object(p.i)(this), window.top.setFbevents && window.top.setFbevents("payment", 0, this.userInfo.userId), setTimeout(function() {
                        Object(p.f)()
                    }, 5e3), setTimeout(function() {
                        var t = window.localStorage.getItem("lang");
                        B(t || "en")
                    }, 0), this.$root.$on("onClose", function() {
                        t.onClose()
                    });
                    var e = new URLSearchParams(window.location.hash),
                        n = new URLSearchParams(window.top.location.hash),
                        a = new URLSearchParams(window.location.search),
                        o = new URLSearchParams(window.top.location.search);
                    !!(e.get("halfScreen") || n.get("halfScreen") || a.get("halfScreen") || o.get("halfScreen")) && (this.anotherClass = "anotherClass", window.bangbetInterface || window.top.bangbetInterface || (this.notAppAnotherClass = "notAppAnotherClass"))
                },
                computed: {
                    userInfo: function() {
                        return this.$store.getters.userInfo
                    },
                    isScrollful: function() {
                        return ["withdrawResult", "depositResult", "ugWithdraw", "UgDeposit"].indexOf(this.$route.name) > -1
                    }
                },
                watch: {
                    $route: function(t, e) {
                        this.showMask(), this.tempTitle = t.meta.name, this.titleName = t.meta.name, this.isTitleBack = !0, t.meta && 0 == t.meta.layoutLv && (this.isTitleBack = !1);
                        var n = "common";
                        t.meta && t.meta.heightType && (n = t.meta.heightType), !_[n] && (n = "common"), this.resetBodyHeight(n)
                    }
                },
                methods: {
                    getBonusStatus: function(t) {
                        var e = this;
                        return c()(s.a.mark(function t() {
                            var n, a;
                            return s.a.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return t.next = 2, Object(f.w)({
                                            type: 1
                                        });
                                    case 2:
                                        n = t.sent, a = n.data, 1 == n.result && a && e.$store.commit("setFirstBonusObj", {
                                            rate: a.proportion,
                                            min: a.minAmt,
                                            max: a.maxAmt,
                                            status: 0 == a.status,
                                            rules: a.rules,
                                            registerActivityConfList: a.registerActivityConfList
                                        });
                                    case 6:
                                    case "end":
                                        return t.stop()
                                }
                            }, t, e)
                        }))()
                    },
                    getDepositGiftStatus: function(t) {
                        var e = this;
                        return c()(s.a.mark(function n() {
                            var a, o;
                            return s.a.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                    case 0:
                                        return n.next = 2, Object(f.s)({
                                            country: t
                                        });
                                    case 2:
                                        a = n.sent, o = a.data, 1 == a.result && o && (e.$store.commit("setDepositGiftStatus", o.status), e.$store.commit("setDepositGiftRate", o.bonusRatio), e.$store.commit("setDepositGiftList", o.awardCouponVOs));
                                    case 6:
                                    case "end":
                                        return n.stop()
                                }
                            }, n, e)
                        }))()
                    },
                    disableAction: function(t) {
                        t && t.stopPropagation()
                    },
                    showMask: function(t) {
                        !t && (t = "Loading"), this.maskText = t, this.isMask = !0
                    },
                    shutMask: function() {
                        this.isMask = !1
                    },
                    ngResetBodyHeight: function(t) {
                        var e = t ? "middle" : "common";
                        this.resetBodyHeight(e)
                    },
                    resetBodyHeight: function(t) {
                        this.heightClassFa = _[t][0], this.heightClassCh = _[t][1]
                    },
                    onClose: function() {
                        var t = this;
                        this.cartoonClass = "animated fadeOutDown", this.$myQueue.setDelayer(null, function() {
                            Object(p.k)(t, {
                                cmd: l.a.PARENT_CMD.CANCEL
                            })
                        }, null, 200)
                    },
                    goTransactions: function() {
                        var t = window.isBangbetCasinoDomain ? window.location.origin + "/games/#" : window.location.origin;
                        window.isCasinoDomain ? window.top.location.href = t + "/Transactions" : (t = t.indexOf("localhost") > -1 ? "https://www.hw.luckygames.team" : t, window.top.location.href = t + "/me/transactions?fromPage=user")
                    }
                }
            },
            E = {
                render: function() {
                    var t = this,
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("div", {
                        class: [t.cartoonClass, t.anotherClass, t.notAppAnotherClass],
                        attrs: {
                            id: "app"
                        },
                        on: {
                            click: function(e) {
                                return e.preventDefault(), t.disableAction()
                            }
                        }
                    }, [n("div", {
                        staticClass: "preventMask",
                        on: {
                            touchmove: function(t) {
                                t.preventDefault()
                            },
                            click: function(e) {
                                return t.onClose()
                            }
                        }
                    }), t._v(" "), n("div", {
                        staticClass: "container scrollful",
                        class: t.heightClassFa
                    }, [n("PayHeader", {
                        attrs: {
                            title: t.titleName,
                            isBack: t.isTitleBack
                        },
                        on: {
                            onClose: t.onClose
                        }
                    }), t._v(" "), n("div", {
                        staticClass: "content",
                        class: t.heightClassCh,
                        attrs: {
                            id: "payResult"
                        }
                    }, [n("router-view")], 1)], 1), t._v(" "), n("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.isMask,
                            expression: "isMask"
                        }],
                        staticClass: "app-mask",
                        on: {
                            click: function(e) {
                                return e.stopPropagation(), t.shutMask()
                            }
                        }
                    }, [t._m(0), t._v(" "), n("div", [t._v(t._s(t.maskText))])])])
                },
                staticRenderFns: [function() {
                    var t = this.$createElement,
                        e = this._self._c || t;
                    return e("div", [e("img", {
                        staticClass: "loading-img",
                        attrs: {
                            src: n("PYFA"),
                            alt: ""
                        }
                    })])
                }]
            };
        var R, L = n("VU/8")(D, E, !1, function(t) {
                n("6gYy")
            }, null, null).exports,
            J = n("bOdI"),
            M = n.n(J);
        Vue.use(VueRouter);
        var O = new VueRouter({
            routes: [{
                path: "/",
                name: "Deposit",
                component: function() {
                    return n.e(24).then(n.bind(null, "v8Ct"))
                },
                meta: {
                    layoutLv: 0,
                    heightType: "common",
                    name: ""
                }
            }, {
                path: "/ke",
                name: "keDeposit",
                component: function() {
                    return Promise.all([n.e(0), n.e(7)]).then(n.bind(null, "Y+RD"))
                },
                meta: {
                    layoutLv: 0,
                    heightType: "common",
                    name: "Deposit"
                }
            }, {
                path: "/payResult",
                name: "payResult",
                component: function() {
                    return Promise.all([n.e(0), n.e(18)]).then(n.bind(null, "eYyE"))
                },
                meta: {
                    name: "Deposit"
                }
            }, (R = {
                path: "/GhDeposit"
            }, M()(R, "path", "/gh"), M()(R, "name", "GhDeposit"), M()(R, "component", function() {
                return Promise.all([n.e(0), n.e(20)]).then(n.bind(null, "Hyvr"))
            }), M()(R, "meta", {
                layoutLv: 0,
                heightType: "common",
                name: "Deposit"
            }), R), {
                path: "/result",
                name: "result",
                component: function() {
                    return Promise.all([n.e(0), n.e(9)]).then(n.bind(null, "mY9u"))
                },
                meta: {
                    layoutLv: 0,
                    heightType: "common",
                    name: "Deposit"
                }
            }, {
                path: "/ug",
                name: "UgDeposit",
                component: function() {
                    return Promise.all([n.e(0), n.e(21)]).then(n.bind(null, "8BLi"))
                },
                meta: {
                    layoutLv: 0,
                    heightType: "common",
                    name: "Deposit"
                }
            }, {
                path: "/ng",
                name: "Deposit",
                component: function() {
                    return Promise.all([n.e(0), n.e(4)]).then(n.bind(null, "MUEF"))
                },
                meta: {
                    layoutLv: 0,
                    heightType: "common",
                    name: "Deposit"
                }
            }, {
                path: "/changeMethods",
                name: "changeModal",
                component: function() {
                    return n.e(22).then(n.bind(null, "0iM3"))
                },
                meta: {
                    layoutLv: 1,
                    heightType: "common",
                    name: "Deposit"
                }
            }, {
                path: "/keWithdraw",
                name: "keWithdraw",
                component: function() {
                    return Promise.all([n.e(0), n.e(10)]).then(n.bind(null, "kSwE"))
                },
                meta: {
                    layoutLv: 0,
                    heightType: "common",
                    name: "Withdraw"
                }
            }, {
                path: "/ngWithdraw",
                name: "ngWithdraw",
                component: function() {
                    return Promise.all([n.e(0), n.e(8)]).then(n.bind(null, "0Y24"))
                },
                meta: {
                    layoutLv: 0,
                    heightType: "common",
                    name: "Withdraw"
                }
            }, {
                path: "/ngAddAccount",
                name: "ngAddAccount",
                component: function() {
                    return Promise.all([n.e(0), n.e(13)]).then(n.bind(null, "COUb"))
                },
                meta: {
                    layoutLv: 1,
                    heightType: "common",
                    name: "Bank"
                }
            }, {
                path: "/ngChooseAccount",
                name: "ngChooseAccount",
                component: function() {
                    return Promise.all([n.e(0), n.e(23)]).then(n.bind(null, "0wbv"))
                },
                meta: {
                    layoutLv: 1,
                    heightType: "common",
                    name: "Bank"
                }
            }, {
                path: "/nameVerify",
                name: "nameVerify",
                component: function() {
                    return Promise.all([n.e(0), n.e(19)]).then(n.bind(null, "9PF/"))
                },
                meta: {
                    layoutLv: 1,
                    heightType: "common",
                    name: "Name Verification"
                }
            }, {
                path: "/birthVerify",
                name: "birthVerify",
                component: function() {
                    return Promise.all([n.e(0), n.e(14)]).then(n.bind(null, "Ago+"))
                },
                meta: {
                    layoutLv: 0,
                    heightType: "common",
                    name: "Date of Birth Verification"
                }
            }, {
                path: "/ngKYC",
                name: "ngKYC",
                component: function() {
                    return n.e(0).then(n.bind(null, "KFtR"))
                },
                meta: {
                    layoutLv: 2,
                    heightType: "common",
                    name: "KYC"
                }
            }, {
                path: "/infomation",
                name: "infomation",
                component: function() {
                    return Promise.all([n.e(0), n.e(12)]).then(n.bind(null, "I6Ij"))
                },
                meta: {
                    layoutLv: 1,
                    heightType: "common",
                    name: "Information"
                }
            }, {
                path: "/ugWithdraw",
                name: "ugWithdraw",
                component: function() {
                    return Promise.all([n.e(0), n.e(11)]).then(n.bind(null, "AI2/"))
                },
                meta: {
                    layoutLv: 0,
                    heightType: "common",
                    name: "Withdraw"
                }
            }, {
                path: "/ghWithdraw",
                name: "ghWithdraw",
                component: function() {
                    return Promise.all([n.e(0), n.e(15)]).then(n.bind(null, "wdU0"))
                },
                meta: {
                    layoutLv: 0,
                    heightType: "common",
                    name: "Withdraw"
                }
            }, {
                path: "/depositResult",
                name: "depositResult",
                component: function() {
                    return Promise.all([n.e(0), n.e(6)]).then(n.bind(null, "cuTh"))
                },
                meta: {
                    layoutLv: 0,
                    name: "Deposit"
                }
            }, {
                path: "/withdrawResult",
                name: "withdrawResult",
                component: function() {
                    return Promise.all([n.e(0), n.e(5)]).then(n.bind(null, "Y/dv"))
                },
                meta: {
                    layoutLv: 0,
                    name: "Withdraw"
                }
            }, {
                path: "/tz",
                name: "tzDeposit",
                component: function() {
                    return Promise.all([n.e(0), n.e(17)]).then(n.bind(null, "nANX"))
                },
                meta: {
                    layoutLv: 0,
                    heightType: "common",
                    name: "Deposit"
                }
            }, {
                path: "/tzWithdraw",
                name: "tzWithdraw",
                component: function() {
                    return Promise.all([n.e(0), n.e(16)]).then(n.bind(null, "AzUp"))
                },
                meta: {
                    layoutLv: 0,
                    heightType: "common",
                    name: "Withdraw"
                }
            }]
        });

        function x() {
            this._queue = [], this._handler = null, this._delayers = []
        }
        x.prototype.push = function(t, e, n, a) {
            !t && (t = this);
            var o = {
                that: t,
                fn: e,
                params: n,
                sec: a
            };
            this._queue.push(o), this._start()
        }, x.prototype.unshift = function(t, e, n, a) {
            !t && (t = this);
            var o = {
                that: t,
                fn: e,
                params: n,
                sec: a
            };
            this._queue.unshift(o), this._start()
        }, x.prototype.clear = function() {
            for (this._handler && clearTimeout(this._handler), this._handler = null; this._queue.length > 0;) this._queue.shift();
            for (; this._delayers.length > 0;) {
                var t = this._delayers.shift();
                t.handler && (clearTimeout(t.handler), t.handler = null), t = null
            }
        }, x.prototype._start = function() {
            this._handler || this._action()
        }, x.prototype._action = function() {
            var t = this;
            if (this._handler && clearTimeout(this._handler), this._handler = null, this._queue.length > 0) {
                var e = this._queue.shift();
                this._handler = setTimeout(function() {
                    e.fn.apply(e.that, e.params), t._action()
                }, e.sec)
            }
        }, x.prototype.setDelayer = function(t, e, n, a) {
            !t && (t = this);
            var o = {
                that: t,
                fn: e,
                params: n,
                sec: a
            };
            o.handler = setTimeout(function() {
                o.fn.apply(o.that, o.params)
            }, o.sec), this._delayers.push(o)
        };
        var U = n("woOf"),
            F = n.n(U),
            W = n("pFYg"),
            K = n.n(W),
            V = {
                data: function() {
                    return {}
                },
                props: {
                    show: {
                        default: !1
                    },
                    text: {
                        default: "loading"
                    },
                    position: {
                        default: "center"
                    },
                    isShowMask: {
                        default: !1
                    },
                    time: {
                        default: 1500
                    },
                    transition: {
                        default: !0
                    },
                    color: {
                        default: "#0D9737"
                    },
                    isDarkModule: Boolean
                },
                computed: {
                    translate: function() {
                        return this.transition ? "top" === this.position ? "translate-top" : "middle" === this.position ? "translate-middle" : "bottom" === this.position ? "translate-bottom" : void 0 : ""
                    },
                    fadeIn: function() {
                        return this.transition ? "fadeIn" : ""
                    }
                }
            },
            j = {
                render: function() {
                    var t = this,
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("transition", {
                        attrs: {
                            name: t.fadeIn
                        }
                    }, [n("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.show,
                            expression: "show"
                        }],
                        staticClass: "alertBox"
                    }, [n("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.isShowMask,
                            expression: "isShowMask"
                        }],
                        staticClass: "alert-mask"
                    }), t._v(" "), n("transition", {
                        attrs: {
                            name: t.translate
                        }
                    }, [n("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.show,
                            expression: "show"
                        }],
                        staticClass: "box",
                        class: [t.position, {
                            "dark-bg": t.isDarkModule
                        }]
                    }, [n("p", [t._v(t._s(t.text))])])])], 1)])
                },
                staticRenderFns: []
            };
        var H = n("VU/8")(V, j, !1, function(t) {
                n("dsYw")
            }, null, null).exports,
            G = {
                install: function(t, e) {
                    if (!document.getElementsByClassName("alertBox").length) {
                        var n = new(t.extend(H)),
                            a = n.$mount().$el;
                        document.body.appendChild(a), t.prototype.$toast = {
                            show: function(t) {
                                "string" == typeof t ? n.text = t : "object" === (void 0 === t ? "undefined" : K()(t)) && F()(n, t), n.show = !0, setTimeout(function() {
                                    n.show = !1
                                }, n.time)
                            },
                            hide: function() {
                                n.show = !1
                            }
                        }
                    }
                }
            },
            Q = G,
            z = n("AWss");

        function Y(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2;
            return t ? z(t, {
                symbol: ""
            }, {
                precision: e
            }).format(!1) : "0.00"
        }

        function q(t) {
            return (t || 0).toString().replace(/^-?\d+/g, function(t) {
                return t.replace(/(?=(?!\b)(\d{3})+$)/g, ",")
            })
        }

        function Z(t) {
            return t ? z(t, {
                symbol: ""
            }, {
                precision: 0
            }).format(!1) : "0.00"
        }
        var X = n("wvfG"),
            $ = n.n(X),
            tt = n("hKoQ"),
            et = n.n(tt),
            nt = (n("tvR6"), n("Yq4J"), n("+BTi"), n("qubY")),
            at = n.n(nt),
            ot = {
                install: function(t) {
                    t.use(at.a)
                }
            },
            it = (n("aFVK"), n("pyoj"), n("UfKn"), n("zqlM"), n("oqQY")),
            rt = n.n(it),
            st = n("p0QZ"),
            ut = n("7QTg"),
            ct = n.n(ut);
        et.a.polyfill(), i()(a).forEach(function(t) {
            return Vue.filter(t, a[t])
        }), Vue.use(ot), Vue.prototype.$eventFacebook = st.a, Vue.config.productionTip = !1;
        var pt = n("AWss");
        Vue.prototype.$currency = pt, Vue.prototype.$moment = rt.a, Vue.prototype.$myQueue = new x, Vue.prototype.$eventBus = new Vue, Vue.use(Q), Vue.use(ct.a), Vue.use($.a), new Vue({
            el: "#app",
            router: O,
            store: C.a,
            i18n: N,
            render: function(t) {
                return t(L)
            }
        })
    },
    PYFA: function(t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAASlElEQVR4Xu2dfdA3VV3Gr+uPbFLUsKzAV0oxQeM1BFILNcEyjUTUICckERMfBwOstOSpaDREUQQCxRhTMAkwsMwAwTQQ8JVAfAgKFYR4Mca3UZvmar64t97e3L/7d3b37O7Z3evM3PP88fuel+/nnOvZPXvO+R7CyQRMYCEBmo0JmMBiAhaIR4cJbEDAAvHwMAELxGPABJoR8BOkGTfnmgkBC2QmHW03mxGwQJpxc66ZELBAZtLRdrMZAQukGTfnmgkBC2QmHW03mxGwQJpxGyyXpF8BsA2AbatGfAXAbSQvG6xRE67YAhlB50p6OoBDADwLwEMWNPlmAP8A4J0krx2BW6NoogWS0E2SfhTAwwE8AsDK/9hfT8ja2kTSmwD8QY2CvgngrSRfWyOPTRcQsEAWgJG0G4CDAcQrzc7rmN0I4CMALiT5wS5GmKT3A3h+w7KvIvmkhnmdrSJggawzFCSdBuCwGqPkQgB/RfLjNfIsNJW0NYCv5iiLpPu4BUjDWwNP0qXVU6Mu1u8A2K/tZLl6cl2wahJetx1r7c8heWDbQuaa3wJZ1fOS7gDw0JaDYVuStzUtQ9J5APZvmn9Bvr/0nKQZUQuk4ibpZAC/3wzjD+WKOclzmpQjaW8A/9Yk75I8MXHf01+36pO1QABUawvxapUrvZrkW+oWJulEAK+qmy/R/mSSRyTa2qwiYIF8TyCxftDof/0FI+mW+PJF8u46I03SfwF4dJ08NWxvJRmfqp1qEJi9QCTFoPlyDWappoeQPDPVuIOn2HpV79P2I0KqP1Oxs0CkwwGc2kGHnkvygNRyJb0IwFmp9g3tfpvk2Q3zzjKbBZJvcr52AF1H8gmpo0pSrJbHqnmX6SiSJ3RZwdTKtkDyzz9WxsjXSD44dcCMRSCSYlfBdgB+GsDPALgdwH8D2ELy86n+jsXOAilHIMW+YknaD0C072nVnrRF4/s6ABcBOGMqn5QtkHJesWLPV85Pza0n6ZJ2APAaAC+u+T/+ZDZMWiCFTNJjAJb0mbcSR3z+fkxNcaw2v5zkL7XIP3hWC6SQz7yVQIpYKJQUgzrLxksA3yD5wMFHesMGzF4g1cAsZaFw8K0mkuK0Yhy+ul/DMbVetitJ7pmxvN6KGpVAJD0ewP+RvCEnoQ4W6RptNanEOuhmRUkfAPDcnHyrska5q7hogUjaq5og/gKA+Nuqgh2n+T4FIL6anE/ykrYdWsJmxUogcVBrkO3uPSxWjm6hsliBSDo0zlcnDvy3kHx1ou1CsxK2u1ciGeTAlKRPAOjyFOLoXrWKFIikfwXwlJoD/gaSj6uZ5z7mQx+YWt2gPo/cSorNmjEX6zrtS/Jfuq4kV/nFCUTS56rXqSY+fozkU5tkXDMwBz1yu6YtvQRtaCnGOsjfRPLoOhmGtC1KIJKOAnB8SyC/R/KMlmXEmsTgQRtWfOg67I+k+GIVR4b7SKNaGylGIJJib8+VAB6VoZf2JnlFhnLuLWLIsD9rfegicJykCGf0pVy8lpRzE8k2i489NfN71ZQkkAiM9q5M3v81yZdnKmvyxUjaHcDVPTk6qoXDkgQSZzLibEaONKrHeA6H25RhgSymV5JAtgDYvk1Hr8o7qv+lMvncuBi/YhUuEEmPBPDFxj28fsYdSF6fucxJFudJevkC6eJc+ONJfmGSI7oDpyTF6v1vdFD02iJPJHlkD/VkqaKkV6w26x9rYdxDMlajnRIJSDoIwHsSzduY7U8y9nuNIpUkkDcDyPU/y0dIxpUBTokEJMW1CvGfVJehgSIc0hNJ3pPYrMHNShJIRDGPaOY50gkkY9HRqQaBTAu1G9V4NMmuA1PU8Hi5aTECiaZKirCbcSaiTYprCWKh8M42hcwxbzVZjwXWXTvw/9MA9iL53Q7K7qzI0gSS41y2g6O1GC6Scj7JV7dkxzFGPSlKINVTJLa4x1b3JukkkpuaZHSeHxCQFIEa3pCRySjFEf4XJ5BKJE2CqJ1KMkd09ozjYrxFVRsk3wfgJ1t4EQfaDhzjk2PF5yIFUonkFwHEl60nL+mgWAz8E5LntuhIZ12HgKSIDBlb0xuF/QHw5yS/XReupAcAiJBDd5KM8/GDpWIFUokkQP1WdT4kjtzuFGfSq+O28UkyxPEhkv8zGMEZVFwFjntJwn2JXwPwbgCn1QkcV0VrjPnnL1f3Qa6OcB8xtiJi48UAPgrgCpJRTy+paIH0QsCVJBOQFLdvxSQ+Tm7G8YT4i7Cj8XcNgLNJfiu1QEnPru6CrLOCH7cMv6MSYeObvFLbaIGkkrJdVgIZTjCGUDaTPD1rw9YUZoF0Sddlr0ugxbn/9co7luTmrlBbIF2RdbmLxKEO0GwieVIH5Zb5mbcLR13m8ARaBuRY5kB8Tj5nmVHd3/0EqUvM9o0ISKobKaZJPbuTjICC2ZIFkg2lC1pEoIoQ88keCJ1O8mU567FActJ0WYvmHX08PVbqzvoUyS4QSXGuPGJKxfVcEcbnGpLf8NiZJ4HqnEmshvd1BcLxJI/JRTubQCRFwLdYRFob1+p/q5AyET/373M13OWMg0CPJxVXgNxMMu5QzJJaC0RSbAH5OwA/n9Cit5N8ZYKdTSZCIPOaRyqVbEceWgmk4c2sF5Ds4v6JVHi265GApGsB7NhjlVFVtk++jQXS8tKZF5DMdby2Z/aurg6BTFdK1KkybF9B8pS6mdazbyQQSTHhuhxAbIdumvYg2Ve4y6ZtdL6WBCR1sXK+rFWxR+vYZUYpvzcVyO9U25pT6lhk8w6Sh7UpwHnLJzDXJ0h8sWobNeSzJHcpv4vdwjYEZjkHkRRXBOe4//pBJOO+QaeJEpjlV6yM75XZPsdNdHyN3q1ZroNkvOxx6zFF2Rv9aB3AgVmupEt6G4C2C37Xk4yD+U4TJ9DTTt4VisPvxZIUX59iA1qbdBbJCJjsNHECs9vNW0WhiKua22xAO4jkWRMfG3avItDTUyTr0yOa3mgdJDK2jL73OpLHefTMh4CkBwP4LIDVIX1yAjiUZK47Lr/frsYCqUQSu3OfV9PLW0jGrapOMyMg6YlVeKDcnmc/KLXSwFYCqUTyCgBvT/T4apJ7JNrabIIEJP0sgI8B2DaTe+eSPCBTWfcpprVAKpHElvdYXX/mBg09juTrunLE5Y6HQPW6dUaDt4/VTkZcrDgcdWKXnmcRyEoDq68VcZpw5URh3PcR752fIxnR95xM4PsEHFnRg8EEEghURyfiNGr8RXjT9dKF1cG8iMX81YRis5hkfYJkaZELmTUBST9eiSSEEnF+46awO0jG0e3ekwXSO3JXOCYCFsiYestt7Z2ABdI7clc4JgIWyJh6a+ZtrdZQIuDHc6qr4X6i+jfmKncDuAvAJwCcT/KyHLgskBwUXUanBCTF4bwIBhfCSE03VMfC42LXxjdSWSCpuG3XOwFJPwYggi+0iZQY1/SFSE5t4oAF0oSa83ROoApI+FYAcXdhjvQBkvvXLcgCqUvM9p0TkBRPjdd3UNE9JLeuU64FUoeWbTsnIOmlALq8d/Bikr+a6ogFkkrKdp0TkPQUAJcA+JGOK3sjyT9MqcMCSaFkm14ISDofwG/2UhnwPJLnLavLAllGyL/3QqB6esQx7r7SZST3WVaZBbKMkH/vhYCkdwI4tJfKflDJS0lGvQuTBdJzj7i6+xKogqF/EUCtL0wZWJ5HcsMj4xZIBsouoh0BSbE+sXQ+0K6WdXPfRXLR+ZN7MyQLpFrVjKju8aUh/iKsfex3idtLLyf5mQ4ccJEzICDpfQBeMJCru240dpMEkrCqGZvF4nxwljsZBgLlagciICn+c915oOoPIXnmorqXCqTmquaHSe43kKOudqQEJN0C4GEDNX/DW3E3FIikfQH8c82GH0zyvTXz2HzGBCR9t4fFwUWE/4nkr9d+gkh6EICrADyuQd/tSTLuSHcygaUEJN0DICIvDpH+luSLmwgkJk0xeWqSTiEZAeWcTGApAUk3AYiAckOkDcPgLnzFkvRaAH/RsMVJq5QNy3a2iRGQFG8bQ0XcPIDkuU2eIG0+vd1J8qcm1o92pyMCkuLcx6aOil9W7M+R/E8LZBkm/z4YgSpw3KUDNOBGko/dqF6/Yg3QK67yvgQkbQGwfc9s/obkS5oKxJP0nntrztVJivluzHv7TL9G8kNNBeLPvH121czrkhRPjwh0HoEa+kjvJXnwsoq8ULiMkH/vjYCkiDxyeE8VJq3VeatJT73hatIISIrNr3F9RpfpQJLnpFSwVCBRiDcrpqC0TS4Ckr4J4P65yltTzoabE9fWmSSQSiTxbujt7h31mov9YQKSLgLwjMxcNtfdcZ4skMwNdXEmsJSApDcAeM1SwzSDI5tc12aBpMG11UAEJL2wCj26S8MmxM7yCD3aaPOsBdKQurP1R0BSzEeOBvDU6jTrsrhZEY/341WU9w3XOZZ5YYEsI+TfiyIgKcQR0d7jGMbKX1x9ECvxX4gj4CQjAESWZIFkwehCpkrAAplqz9qvLAQskCwYXchUCVggU+1Z+5WFgAWSBaMLmSoBC2SqPWu/shCwQLJgdCFTJWCBTLVn7VcWAhZIFowuZKoELJCp9qz9ykLAAsmC0YVMlYAFMtWetV9ZCFggWTC6kKkSsECm2rP2KwsBCyQLRhcyVQKdCCRCSZKM69mcTGDUBLIJRNLvAojLGJ8O4AEA7gTwQQDvJ1n3Ep5RQ3Xjp0OgtUAkxamuM6pTXovIvBvAn5GMeyCcTGA0BHII5DsA7pfg8QUkn5tgZxMTKIZAK4FIOg7AH9fwZhPJk2rY29QEBiXQViDXAtixhgfXkNyphr1NTWBQAo0FImkHANc1aP1WJCO0pJMJFE+gjUCOiIBcDTzcg+TVDfI5iwn0TqCNQJ4G4JIGLX4kyS83yOcsJtA7gTYCiQBetwJ4aI1W30xyuxr2NjWBQQk0Fki0WtIpAF5ew4PjSR5Tw96mJjAogbYCiUXCKwBsneDFrSQfnmBnExMohkArgVRPkdcDODbBo51IXpNgZxMTKIZAa4FUItkLQNxSGhP3telcAAeT/HYxXrshRROQtA3J20poZBaBrDhSrY3EwmH8XQXg8yRvLsFRt2EcBCTFa3h85fwUyd2HbnVWgQztjOsfPwFJjwZwKYD44rnP0B5ZIEP3gOsvmoAFUnT3uHFDE7BAhu4B1180AQuk6O5x44YmYIEM3QOuv2gCFkjR3ePGDU3AAhm6B1x/0QQskKK7x40bmoAFMnQPuP6iCVggRXePGzc0AQtk6B5w/UUTsECK7h43bmgCFsjQPeD6iyZggRTdPW7c0ASKF4ikfQHEgaxdAVwf50xIxiEsJxPonEDRApF0GoDD1qEQ0VT+lOS7OifkCmZNoFiBSPokgN2W9E4czbx91j1o5zslUKRAJMVTI54ey9JJJDctM/LvJtCUQKkCOQvAixKcup3kNgl2NjGBRgRKFcjdAB6S6NFuJD+daGszE6hFoFSBfAbAzomebFtKiJjE9tpsRARKFcipAA5P4HgdySck2NnEBBoRKFUgsfaRcvHnESRPbuS5MzUmUF3YGnGr/r1xISPJWKRAgp2kCHL9xo04kiy2/SPp/9rNlHQlgD2qjJP/ilj0AIv71qvPvduv6cnTSb6sdu86QysCkuKK74tXFXIjyce2KrTwzEULpHqSPLBaMIxFwy1VSMoi4rYW3rfZmyfpmQA+vKrgyc8BixdI9l52ga0ISHoPgIMAfB3ACSQ3tyqw8MwWSOEdVGLzJD2MZOyHm3yyQCbfxXawDQELpA095508AQtk8l1sB9sQsEDa0HPeyROwQDboYknPB/BHAOKy0jsAxMrxkSRvmvzIsIP3ErBAFgwESUcBOH7Bz48i+SWPoekTsEDW6WNJsSgZJxoXpX8k+ewhhoekxwCIxdMtJL81RBvmVKcFsr5AjgTw5iUDYbs+LyithPE2AM+q2hWXo76K5AVzGrB9+2qBrC+QuEQy9oFtlPYheVlfHSbpbAAvXFNfbL15Msm7+mrH3OqxQEbwBJH0CACL5jyHkDxzbgO3L38tkGZzkEtIPqOvTpK0C4BFx4qPIbnoY0JfTZxsPRbIgq7d4CvWVwDsT/KqvkaFpPsD+A8A265T534kV++w7atZs6jHAtmgmyU9CcArq4nxNQA+GudThjgDX52NibnR6rSZ5LGzGKkDOWmBDAS+SbWSdgCwN4CtAMRZjIualOM86QQskHRWtpwhAQtkhp1ul9MJWCDprGw5QwIWyAw73S6nE7BA0lnZcoYELJAZdrpdTidggaSzsuUMCVggM+x0u5xOwAJJZ2XLGRKwQGbY6XY5nYAFks7KljMkYIHMsNPtcjqB/wfbgkMUKyX8hwAAAABJRU5ErkJggg=="
    },
    SJI6: function(t, e) {
        t.exports = Vuex
    },
    UfKn: function(t, e) {},
    VKKs: function(t, e, n) {
        "use strict";
        var a = n("mvHQ"),
            o = n.n(a),
            i = n("Zrlr"),
            r = n.n(i),
            s = n("wxAW"),
            u = n.n(s),
            c = function() {
                function t() {
                    r()(this, t)
                }
                return u()(t, null, [{
                    key: "setLocal",
                    value: function(t, e) {
                        window.localStorage.setItem(t, o()(e))
                    }
                }, {
                    key: "getLocal",
                    value: function(t) {
                        var e = window.localStorage.getItem(t);
                        return "undefined" == e || "null" == e ? "" : JSON.parse(e)
                    }
                }, {
                    key: "setSession",
                    value: function(t, e) {
                        window.sessionStorage.setItem(t, o()(e))
                    }
                }, {
                    key: "getSession",
                    value: function(t) {
                        var e = window.sessionStorage.getItem(t);
                        return "undefined" == e || "null" == e ? "" : JSON.parse(e)
                    }
                }, {
                    key: "clearOneLocal",
                    value: function(t) {
                        window.localStorage.removeItem(t)
                    }
                }, {
                    key: "clearOneSession",
                    value: function(t) {
                        window.sessionStorage.removeItem(t)
                    }
                }, {
                    key: "clearAllLocal",
                    value: function() {
                        window.localStorage.clear()
                    }
                }, {
                    key: "clearAllSession",
                    value: function() {
                        window.sessionStorage.clear()
                    }
                }]), t
            }();
        e.a = c
    },
    Yq4J: function(t, e) {},
    Zpiv: function(t, e, n) {
        "use strict";
        e.a = {
            CHIPTYPE: {
                ug: "USH",
                ke: "KSH",
                ng: "NGN",
                gh: "GHS",
                tz: "TZS"
            },
            EVENT_BUS: {
                BACK: "BACK_EVENT"
            },
            PARENT_CMD: {
                SUCCESS: "success",
                CANCEL: "cancel",
                ERROR: "error",
                FAILED: "failed",
                LIVECHAT: "livechat",
                PRELOAD: "preload",
                WHATSAPP: "whatsapp"
            },
            WhatsAppPhone: {
                ke: "2540711019120",
                ug: "2560708112111",
                gh: "2330201687746",
                ng: "23409069333333",
                tz: "255750178887"
            },
            liveHelp: {
                ke: "https://embed.tawk.to/592c03184374a471e7c50484/default",
                ug: "https://embed.tawk.to/5ab371fbd7591465c708ccd2/default",
                ng: "https://embed.tawk.to/5e8d9f0335bcbb0c9aaf02cf/default",
                in: "https://embed.tawk.to/592c03184374a471e7c50484/default",
                gh: "https://embed.tawk.to/5fd186cb920fc91564cf36ee/default",
                tz: "https://embed.tawk.to/5fd186cb920fc91564cf36ee/default"
            },
            All_PAYMODE: [{
                tabName: "Card",
                componentName: "BackCard",
                method: "backend",
                type: "card",
                selectName: "Pay with ATM Card",
                selectTitle: "Card",
                ico: "icon-Icon_Card_nor_48"
            }, {
                tabName: "Card",
                componentName: "PaystackCard",
                method: "js",
                type: "card",
                selectName: "Pay with ATM Card",
                selectTitle: "Card",
                ico: "icon-Icon_Card_nor_48"
            }, {
                tabName: "Card",
                componentName: "CartCont",
                method: "inline",
                type: "card",
                selectName: "Pay with ATM Card",
                selectTitle: "Card",
                ico: "icon-Icon_Card_nor_48"
            }, {
                tabName: "Card",
                componentName: "CartCont",
                method: "standard",
                type: "card",
                selectName: "Pay with ATM Card",
                selectTitle: "Card",
                ico: "icon-Icon_Card_nor_48"
            }, {
                tabName: "Bank Acc.",
                componentName: "Bank",
                method: "backend",
                type: "bank",
                selectName: "Pay with Bank Account",
                selectTitle: "Bank Account",
                ico: "icon-Icon_Bankacc_nor_48"
            }, {
                tabName: "Bank Acc.",
                componentName: "Bank",
                method: "inline",
                type: "bank",
                selectName: "Pay with Bank Account",
                selectTitle: "Bank Account",
                ico: "icon-Icon_Bankacc_nor_48"
            }, {
                tabName: "Bank Acc.",
                componentName: "Bank",
                method: "standard",
                type: "bank",
                selectName: "Pay with Bank Account",
                selectTitle: "Bank Account",
                ico: "icon-Icon_Bankacc_nor_48"
            }, {
                tabName: "USSD",
                componentName: "USSD",
                method: "backend",
                type: "ussd",
                selectName: "Pay by dailing USSD Code",
                selectTitle: "USSD Code",
                ico: "icon-Icon_Ussd_nor_481"
            }, {
                tabName: "USSD",
                componentName: "USSD",
                method: "inline",
                type: "ussd",
                selectName: "Pay by dailing USSD Code",
                selectTitle: "USSD Code",
                ico: "icon-Icon_Ussd_nor_481"
            }, {
                tabName: "USSD",
                componentName: "USSD",
                method: "standard",
                type: "ussd",
                selectName: "Pay by dailing USSD Code",
                selectTitle: "USSD Code",
                ico: "icon-Icon_Ussd_nor_481"
            }, {
                tabName: "OPay Web",
                componentName: "OPayAppCont",
                method: "h5",
                type: "opay",
                selectName: "Pay via OPay Web",
                selectTitle: "OPay Web",
                ico: "icon-Icon_Opayonline_nor_48"
            }, {
                tabName: "OPay",
                componentName: "OPayApp",
                method: "app",
                type: "opay",
                selectName: "Pay via OPay App",
                selectTitle: "OPay App",
                ico: "icon-Icon_Opayonline_nor_48"
            }, {
                tabName: "PalmPay",
                componentName: "PalmPay",
                method: "h5",
                type: "palm",
                selectName: "Pay via PalmPay",
                selectTitle: "PalmPay",
                ico: "icon-Icon_Palmpay_nor_48"
            }, {
                tabName: "QR",
                componentName: "QR",
                method: "backend",
                type: "qr",
                selectName: "Pay by scanning QR Code",
                selectTitle: "QR Code",
                ico: "icon-Icon_Qr_nor"
            }, {
                tabName: "ATM Deposit",
                componentName: "ATMDeposite",
                method: "h5",
                type: "atm",
                selectName: "Pay via ATM Deposit",
                selectTitle: "ATM Deposit",
                ico: "icon-Icon_Atmdep_nor_48"
            }, {
                tabName: "Flutter wave",
                componentName: "Futter",
                method: "inline",
                type: "flutterwave",
                selectName: "Pay via Flutterwave",
                selectTitle: "Flutterwave",
                ico: "icon-Icon_Flutterwave_nor_48"
            }, {
                tabName: "Bank Transfer",
                componentName: "BankTransfer",
                method: "h5",
                type: "bank transfer",
                selectName: "Pay via Bank Transfer",
                selectTitle: "Bank Transfer",
                ico: "icon-Icon_BankTransfer_nor_48"
            }, {
                tabName: "PalmPay Bank Transfer",
                componentName: "BankTransfer",
                method: "h5",
                type: "PalmPay Banktransfer",
                selectName: "Pay via Bank Transfer",
                selectTitle: "Bank Transfer",
                ico: "icon-Icon_Palmpay_nor_48"
            }, {
                tabName: "Opay Bank Transfer",
                componentName: "BankTransfer",
                method: "h5",
                type: "Opay Banktransfer",
                selectName: "Pay via Bank Transfer",
                selectTitle: "Bank Transfer",
                ico: "icon-Icon_Opayonline_nor_48"
            }, {
                tabName: "Instant Transfer",
                componentName: "InstantTransfer",
                method: "h5",
                type: "instant transfer",
                selectName: "Pay via Instant Transfer",
                selectTitle: "Instant Transfer",
                ico: "icon-Icon_InstantTransfer_nor_48"
            }, {
                tabName: "Paga",
                componentName: "Paga",
                method: "app",
                type: "paga",
                selectName: "Pay via Paga",
                selectTitle: "Paga",
                ico: "icon-Icon_Paga_nor48_48"
            }, {
                tabName: "Quick teller",
                componentName: "Quickteller",
                method: "h5",
                type: "quicktell",
                selectName: "Pay via Quickteller",
                selectTitle: "Quickteller",
                ico: "icon-Icon_Quickteller_nor_48"
            }, {
                tabName: "Monnify",
                componentName: "Monnify",
                method: "h5",
                type: "monnify",
                selectName: "Pay via Monnifyer",
                selectTitle: "Monnifyer",
                ico: "icon-Icon_Monnify_nor_48"
            }],
            AMOUNT_LIST: {
                ke: [{
                    amount: 48,
                    discount: 0
                }, {
                    amount: 98,
                    discount: 0
                }, {
                    amount: 477,
                    discount: 0
                }, {
                    amount: 977,
                    discount: 0
                }, {
                    amount: 15e4,
                    discount: 0
                }],
                ng: [{
                    amount: 100,
                    discount: 0
                }, {
                    amount: 200,
                    discount: 0
                }, {
                    amount: 500,
                    discount: 0
                }, {
                    amount: 1e3,
                    discount: 0
                }, {
                    amount: 5e3,
                    discount: 0
                }],
                ug: [{
                    amount: 2e3,
                    discount: 0
                }, {
                    amount: 4e3,
                    discount: 0
                }, {
                    amount: 8e3,
                    discount: 0
                }, {
                    amount: 1e4,
                    discount: 0
                }, {
                    amount: 5e4,
                    discount: 0
                }],
                gh: [{
                    amount: 1,
                    discount: 0
                }, {
                    amount: 5,
                    discount: 0
                }, {
                    amount: 20,
                    discount: 0
                }, {
                    amount: 50,
                    discount: 0
                }, {
                    amount: 100,
                    discount: 0
                }],
                tz: [{
                    amount: 500,
                    discount: 0
                }, {
                    amount: 1e3,
                    discount: 0
                }, {
                    amount: 2e3,
                    discount: 0
                }, {
                    amount: 5e3,
                    discount: 0
                }, {
                    amount: 1e4,
                    discount: 0
                }]
            },
            INTRODUCE_LIST: {
                ng: {
                    head: "Expand query common feedback",
                    list: [{
                        application: "h5",
                        content: "<p>1. The top-up amount must be used to bet first, otherwise a withdrawal fee shall be charged. All money won using our bonuses shall be free to withdraw.<br />2. The minimum deposit amount is NGN 100.<br />3. The maximum deposit amount is NGN 9,999,999.<br />4. Trying to use multiple cards/bank accounts for multiple deposits may cause error.<br />5. If you cannot receive the bank&rsquo;s OTP for a long time, please try again later.<br />6. If you failed to deposit, we suggest retrying with other payment methods, or contact our customer service.<br />7. For your fund security, only if the holder's name of your bank account and BVN match can you withdraw successfully.<br />8. Banks may charge Deposit fees and VAT.</p>",
                        country: "ng",
                        title: "Tips"
                    }, {
                        application: "h5",
                        content: "<p>Please read the failure prompt carefully, most users experience this issue as a result of insufficient bank card balance or entered an incorrect OTP. please try to pay again. In addition, we suggest that you use bank transfer for payment.</p></p>",
                        country: "ng",
                        title: "Payment with bank card failed"
                    }, {
                        application: "h5",
                        content: "<p>Please read the failure prompt carefully, most users experience this issue as a result of insufficient bank account balance or entered an incorrect OTP. please try to pay again. In addition, we suggest that you use bank transfer for payment.</p>",
                        country: "ng",
                        title: "Payment with bank accounts failed"
                    }]
                },
                gh: {
                    head: "Need to pay for help.",
                    list: [{
                        application: "h5",
                        content: "<p>1. Minimum per transaction is GHS 1.00.<br />2. Maximum per transaction is GHS 100,000.00.<br /> 3. Your balance can only be withdrawn to the mobile number that you registered with.<br />4. The top-up amount must be used to bet first, otherwise a withdrawal fee shall be charged. All money won using our bonuses shall be free to withdraw.</p>",
                        country: "gh",
                        title: "Tips"
                    }]
                },
                ke: {
                    head: "Other payment method and help.",
                    list: [{
                        application: "h5",
                        content: "<p>1: Go to M-PESA menu on your mobile phone<br />2: Select Lipa na M-PESA<br />3: Select Pay Bill<br />4: Enter 569699 as Business Number<br />5: Enter Bangbet as reference Number<br />6: Enter amount(NO COMMAS) e.g 100<br />7: Enter your M-PESA PIN and send<br />8: You will receive an SMS confirming the transaction</p>",
                        country: "ke",
                        title: "Pay with M-PESA Paybill 569699"
                    }, {
                        application: "h5",
                        content: "<p>1: Go to Airtel SIM tool kit menu on your mobile phone<br />2: Select Airtel money<br />3: Select Make Payments<br />4: Select Paybill choose Other<br />5: Enter Bangbet as the Business Name<br />6: Input the reference as Bangbet<br />7: Enter the amount and your PIN<br />8: You will receive an SMS confirming the transaction</p>",
                        country: "ke",
                        title: "Pay with Airtel Paybill"
                    }, {
                        application: "h5",
                        content: "<p>1. M-PESA:<br />Deposite 48 Refund 2<br />Deposite 98 Refund 2<br />Deposite 250&#65374;999 Refund 23<br />Deposite 1,000&#65374;2,499 Refund 34<br />Deposite 2,500&#65374;4,999 Refund 56<br />Deposite 5,000&#65374;9,999 Refund 85<br />Deposite 10,000&#65374;34,999 Refund 112<br />Deposite 35,000&#65374;49,999 Refund 202<br />Deposite 50,000+ Refund 210</p><p>2. Airtel:<br />Deposite 48 Refund 2<br />Deposite 98 Refund 2<br />Deposite 250&#65374;1,000 Refund 18<br />Deposite 1,001&#65374;2,500 Refund 27<br />Deposite 2,501&#65374;5,000 Refund 44<br />Deposite 5,001&#65374;10,000 Refund 65<br />Deposite 10,001&#65374;35,000 Refund 85<br />Deposite 35,001&#65374;50,000 Refund 150<br />Deposite 50,001+ Refund 160</p>",
                        country: "ke",
                        title: "Extra&Receive"
                    }, {
                        application: "h5",
                        content: "<p>M-PESA MANUAL RECONCILIATION</p><p>Please copy and paste the M-Pesa Transaction Code which was sent to your Mobile Phone via SMS to manually deposit your cash into your BangBet account, e.g MDI3WSXXXX</p><p>M-Pesa Manual Reconciliation is used in situations such as.</p><p>When one receives the M-Pesa SMS informing them that the transaction was successful, yet it failed due to the situations listed below:</p><p>1. Deposit is displayed as Failed.<br />2. Deposit is displayed as Pending.<br />3. Made deposit through our M-Pesa Paybill(569699), but the cash never reflected in the BangBet account.</p><p>You can fix all these issues by using this function by just pasting the M-pesa Transaction Code above and clicking CONFIRM. The Cash will instantly be added to your BangBet account.</p>",
                        country: "ke",
                        title: "Deposit Unsuccessful"
                    }, {
                        application: "h5",
                        content: "<p>1. Maximum Daily Transcation Value is KSH 300,000.00<br />2. Maximum per transaction is KSH 150,000.00<br />3. Deposit an amount between KSH 1~150,000 from your M-pesa account to your bangbet account. All safaricom M-pesa charges incurred on all qualifying deposits as indicated above will automatically be credited on top of your initial deposit.</p>",
                        country: "ke",
                        title: "Tips"
                    }]
                },
                ug: {
                    head: "Need to pay for help.",
                    list: [{
                        application: "h5",
                        content: "<p>1. Minimum per transaction is USH 600.<br />2. Maximum per transaction is USH 400,000.00.<br />3. Your balance can only be withdrawn to the mobile number that you registered with.<br />4. The top-up amount must be used to bet first, otherwise a withdrawal fee shall be charged. All money won using our bonuses shall be free to withdraw.</p>",
                        country: "ug",
                        title: "Tips"
                    }]
                },
                tz: {
                    head: "",
                    list: [{
                        title: "HOW TO DEPOSIT TO YOUR BANGBET ACCOUNT",
                        country: "tz",
                        content: "<p>Once you've finished signing up, deposit money into your Bangbet account. It's easy, just follow the steps below depending on the network you use:</p>",
                        application: "h5"
                    }, {
                        title: "VODACOM",
                        country: "tz",
                        content: "<p>Dial *150*00#<br />Choose number 4 (Pay the Bill).<br />Select 4 then enter the company number (504050)<br />Record the number (123)<br />Enter the amount (minimum of TZS 500)<br />Enter your PIN and then press 1 to confirm<br />You will receive a message confirming your transaction.</p>",
                        application: "h5"
                    }, {
                        title: "TIGO",
                        country: "tz",
                        content: "<p>Dial *150*01#<br />Choose number 4 (Pay the Bill)<br />Select 3 then enter the company number (504050)<br />Enter Reference Number (123)<br />Enter the amount (minimum of TZS 500)<br />Enter your PIN and press 1 to confirm<br />You will receive a message confirming your transaction.</p>",
                        application: "h5"
                    }, {
                        title: "HALOTEL",
                        country: "tz",
                        content: "<p>Dial *150*88#<br />Choose number 4 (Pay the Bill)<br />Select 3 then enter the company number (504050)<br />Enter Reference Number (123)<br />Enter the amount of money you need (minimum of TZS 500)<br />Enter the password and then press 1 to confirm<br />You will receive a message confirming your transaction.</p>",
                        application: "h5"
                    }, {
                        title: "AIRTEL",
                        country: "tz",
                        content: "<p>Dial *150*60#<br />Choose number 5 (Pay the Bill)<br />Choose number 6 (Gaming and Betting)<br />Choose number 1 (Betting)<br />Choose number 39 (BANGBET)<br />Enter Reference Number (123)<br />Enter the amount of money you need (minimum of TZS 500)<br />Enter the PIN then Submit<br />You will receive a message confirming your transaction.</p>",
                        application: "h5"
                    }]
                },
                "tz-sw": {
                    head: "",
                    list: [{
                        title: "JINSI YA KUWEKA PESA KWENYE AKAUNTI YAKO YA BANGBET",
                        country: "tz",
                        content: "<p>Baada ya kumaliza kujiandikisha, weka pesa kwenye akaunti yako ya Bangbet. Ni rahisi, fuata hatua zifuatazo kulingana na mtandao unaoutumia:</p>",
                        application: "h5"
                    }, {
                        title: "VODACOM",
                        country: "tz",
                        content: "<p>Piga *150*00#<br />Chagua namba 4 (Lipa Bili).<br />Chagua 4 kisha ingiza namba ya kampuni (504050)<br />Ingiza Namba ya Kumbukumbu (123)<br />Ingiza kiasi (kiwango cha chini cha TZS 500)<br />Ingiza PIN yako na kisha bonyeza 1 kuthibitisha<br />Utapokea ujumbe ukithibitisha muamala wako.</p>",
                        application: "h5"
                    }, {
                        title: "TIGO",
                        country: "tz",
                        content: "<p>Piga *150*01#<br />Chagua namba 4 (Lipa Bili)<br />Chagua 3 kisha ingiza namba ya kampuni (504050)<br />Ingiza Namba ya Kumbukumbu (123)<br />Ingiza kiasi (kiwango cha chini cha TZS 500)<br />Ingiza PIN yako na bonyeza 1 kuthibitisha<br />Utapokea ujumbe ukithibitisha muamala wako.</p>",
                        application: "h5"
                    }, {
                        title: "HALOTEL",
                        country: "tz",
                        content: "<p>Piga *150*88#<br />Chagua namba 4 (Lipa Bili)<br />Chagua 3 kisha ingiza namba ya kampuni (504050)<br />Ingiza Namba ya Kumbukumbu (123)<br />Ingiza kiasi cha pesa unachohitaji (kiwango cha chini cha TZS 500)<br />Ingiza nywila na kisha bonyeza 1 kuthibitisha<br />Utapokea ujumbe ukithibitisha muamala wako.</p>",
                        application: "h5"
                    }, {
                        title: "AIRTEL",
                        country: "tz",
                        content: "<p>Piga *150*60#<br />Chagua namba 5 (Lipa Bili)<br />Chagua namba 6 (Gaming and Betting)<br />Chagua namba 1 (Betting)<br />Chagua namba 39 (BANGBET)<br />Ingiza Namba ya Kumbukumbu (123)<br />Ingiza kiasi cha pesa unachohitaji (kiwango cha chini cha TZS 500)<br />Ingiza PIN kisha Wasilisha<br />Utapokea ujumbe ukithibitisha muamala wako.</p>",
                        application: "h5"
                    }]
                }
            },
            KE_TABLIST: [{
                tabName: "M-PESA",
                type: "mpesa",
                ico: "icon-Icon_MPESApaybill_48"
            }, {
                tabName: "Airtel",
                type: "airtel",
                ico: "icon-Icon_Pay_Airtel_48"
            }, {
                tabName: "Airtel",
                type: "oldairtel",
                ico: "icon-Icon_Pay_Airtel_48"
            }],
            UG_TABLIST: [{
                tabName: "MTN",
                type: "mtn",
                ico: "icon-Icon_Mtn_48"
            }, {
                tabName: "Airtel",
                type: "airtel",
                ico: "icon-Icon_Pay_Airtel_48"
            }, {
                tabName: "YoPay",
                type: "yopayment",
                ico: "icon-a-Icon_YoPayments_nor_48"
            }, {
                tabName: "MTN",
                type: "yoMtn",
                ico: "icon-Icon_Mtn_48"
            }, {
                tabName: "Airtel",
                type: "yoAirtel",
                ico: "icon-Icon_Pay_Airtel_48"
            }],
            GH_TABLIST: [{
                tabName: "MTN",
                type: "mtn",
                ico: "icon-Icon_Mtn_48"
            }, {
                tabName: "Tigo",
                type: "tigo",
                ico: "icon-Icon_Tigo_48"
            }, {
                tabName: "Vodafone",
                type: "vodafone",
                ico: "icon-Icon_Vodafone_48"
            }],
            NG_TABLIST: [{
                tabName: "Bank",
                type: "bank",
                ico: "icon-Icon_Bankacc_nor_48"
            }, {
                tabName: "OPay",
                type: "opay",
                ico: "icon-Icon_Opayonline_nor_48"
            }, {
                tabName: "PalmPay",
                type: "palmpay",
                ico: "icon-Icon_Palmpay_nor_48"
            }],
            WITHDRAW_TIPLIST: {
                ke: {
                    head: "Expand query common feedback",
                    list: [{
                        application: "h5",
                        content: "<p>1. The minimum withdraw is KSH 100.<br/> 2. The maximum withdraw is KSH 150,000.<br/> 3. Please note that Mpesa additional carrier fees of KSH 15 apply when processing withdrawal requests.</p>",
                        country: "ke",
                        title: "M-PESA Tips"
                    }, {
                        application: "h5",
                        content: "<p>1. The minimum withdraw is KSH 100.<br/> 2. The maximum withdraw is KSH 150,000.<br/> 3. 3. Three free withdrawals per day for amounts above KSH 500.<br/>4. Withdrawal service charge:<br/>Amount 100~1000, Service charge KSH 11<br/> Amount 1001~3000, Service charge KSH 23<br/> Amount 3001~7000, Service charge KSH 32</p>",
                        country: "ke",
                        title: "Airtel Tips"
                    }, {
                        application: "h5",
                        content: "<p>If your withdrawal order status is pending , we advise you to wait patiently, as it normally takes the mobile money within 24 hours to process the transaction.</p>",
                        country: "ke",
                        title: "Withdrawal status 'pending'"
                    }]
                },
                ug: {
                    head: "Expand query common feedback",
                    list: [{
                        application: "h5",
                        content: "<p>1. Minimum per transaction is USH 1000.<br/> 2. Maximum per transaction is USH 500,000<br/> 3. Your mobile money service may charge a withdraw fee of (UGX 300 Airtel) or (UGX 390 MTN)</p>",
                        country: "ug",
                        title: "Tips"
                    }, {
                        application: "h5",
                        content: "<p>If your withdrawal order status is pending , we advise you to wait patiently, as it normally takes the mobile money within 24 hours to process the transaction.",
                        country: "ug",
                        title: "Withdrawal status 'pending'"
                    }]
                },
                ng: {
                    head: "Expand query common feedback",
                    list: [{
                        application: "h5",
                        content: "<p>1. A single withdrawal amount must be from NGN100 and NGN100000. Please make sure that your balance and withdrawal amount are within the requirements.<br/> 2. Transfers ess than NGN 5,000 will now cost NGN 10. transfers between NGN 5,000 and NGN 50,000 will now cost NGN 25. transfers equal to or greater than NGN 50,000 will now cost NGN 50.</p>",
                        country: "ng",
                        title: "Withdrawal amount"
                    }, {
                        application: "h5",
                        content: "<p>Every amount recharged must be used to place bet before it can be withdrawn. If you wish to withdraw an amount that has not been used to place bet, a 1.5% commission will be charged for the withdrawal.</p>",
                        country: "ng",
                        title: "Withdrawal service charge"
                    }, {
                        application: "h5",
                        content: "<p>If your withdrawal order status is pending , we advise you to wait patiently, as it normally takes the Bank within 24 hours to process the transaction.</p>",
                        country: "ng",
                        title: "Withdrawal status 'pending'"
                    }, {
                        application: "h5",
                        content: "<p>According to Nigerian laws and regulations, you are required to submit KYC information before withdrawal. We only allow withdrawal to a bank account with a unique name. please note that your name cannot be changed after approval and we will make sure to keep your information confidential.</p>",
                        country: "ng",
                        title: "Compliance policy requirements"
                    }]
                },
                gh: {
                    head: "Expand query common feedback",
                    list: [{
                        application: "h5",
                        content: "<p>1. Minimum per transaction is GHS 1.00.<br/> 2. Maximum per transaction is GHS 30,000.00.<br/> 3. There are 3 free withdrawals each day of which 1% transaction fee will be charged for exceeding the limit.<br/>4. The top-up amount must be used to bet first, otherwise a withdrawal fee shall be charged. All money won using our bonuses shall be free to withdraw.</p>",
                        country: "gh",
                        title: "Tips"
                    }, {
                        application: "h5",
                        content: "<p>If your withdrawal order status is pending , we advise you to wait patiently, as it normally takes the mobile money within 24 hours to process the transaction.</p>",
                        country: "gh",
                        title: "Withdrawal status 'pending'"
                    }]
                },
                tz: {
                    head: "Panua hoja ya maoni ya kawaida",
                    list: [{
                        title: "Vidokezo",
                        application: "h5",
                        content: '<p>1. Kiwango cha chini kwa kila muamala ni TZS 1000.00<br>2. Kiwango cha juu kwa kila muamala ni TZS 5,000,000.<br>3. Kuna uondoaji 3 bila malipo kila siku ambapo 1% ya ada ya muamala itatozwa kwa kuzidi kikomo.<br>4. Kiasi cha nyongeza lazima kitumike kubashiri kwanza, vinginevyo ada ya kujitoa itatozwa. Pesa zote zilizoshinda kutumia bonasi zetu zitakuwa huru kutoa. Hali ya kutoa pesa "inaendelea"Hali ya uondoaji "inasubiri"  Ikiwa hali ya agizo lako la uondoaji inasubiri , tunakushauri usubiri kwa subira, kwani kwa kawaida huchukua pesa za simu ndani ya masaa 24 ili kushughulikia muamala. Huduma kwa mteja 24/7</p>',
                        country: "tz"
                    }]
                }
            }
        }
    },
    aFVK: function(t, e) {
        ! function(t, e) {
            var n = t.documentElement,
                a = (Math.min(e.devicePixelRatio, 3), "orientationchange" in window ? "orientationchange" : "resize"),
                o = t.createElement("meta");
            o.name = "viewport", o.content = "initial-scale=1,maximum-scale=2,user-scalable=0", n.firstElementChild.appendChild(o);
            var i = function() {
                var t = n.clientWidth;
                n.style.fontSize = t / 750 * 100 + "px"
            };
            if (!/iphone|nokia|sony|ericsson|mot|samsung|sgh|lg|philips|panasonic|alcatel|lenovo|cldc|midp|wap|android|iPod/i.test(navigator.userAgent.toLowerCase())) return t.body.style.width = "750px", t.body.style.margin = "0 auto", t.body.style.display = "flex", void(n.style.fontSize = "100px");
            t.addEventListener && (i(), e.addEventListener(a, i, !1))
        }(document, window)
    },
    dsYw: function(t, e) {},
    lRwf: function(t, e) {
        t.exports = Vue
    },
    lgBR: function(t, e, n) {
        var a = {
            "./en": ["mtZG", 3],
            "./en.json": ["mtZG", 3],
            "./sw": ["65rJ", 2],
            "./sw.json": ["65rJ", 2],
            "./tz-sw": ["OvN8", 1],
            "./tz-sw.json": ["OvN8", 1]
        };

        function o(t) {
            var e = a[t];
            return e ? n.e(e[1]).then(function() {
                return n(e[0])
            }) : Promise.reject(new Error("Cannot find module '" + t + "'."))
        }
        o.keys = function() {
            return Object.keys(a)
        }, o.id = "lgBR", t.exports = o
    },
    oAV5: function(t, e, n) {
        "use strict";
        e.l = function(t) {
            if (!t) return "";
            if ("null" === t || "undefined" === t) return "";
            return t.replace(/(^\s*)|(\s*$)/g, "")
        }, e.i = function t(e, n, a) {
            if (n instanceof Array)
                for (var o = 0, i = n.length; o < i; o++) t(e, n[o], a);
            for (var o in n) !a && o in e || (e[o] = n[o]);
            return e
        }, e.g = function() {
            return window.navigator.standalone || window.matchMedia("(display-mode: standalone)").matches
        }, e.e = function() {
            return window.location.protocol + "//" + window.location.host
        }, e.c = function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            if (null == t || void 0 == t || "" == t) return "";
            var n = 2;
            e && (n = 0);
            return isNaN(t) ? t : (parseFloat(t).toFixed(n) + "").replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, "$&,")
        }, e.k = function(t) {
            return "" != t ? (t || 0).toString().replace(/^-?\d+/g, function(t) {
                return t.replace(/(?=(?!\b)(\d{3})+$)/g, ",")
            }) : t
        }, e.m = function(t) {
            if (t && "undefined" != t && "null" != t) {
                var e = t;
                return e = (e = e.toString()).replace(/,/gi, "")
            }
            return t
        }, e.a = function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 500,
                n = null;
            return function() {
                var a = this,
                    o = arguments;
                n && clearTimeout(n), n = setTimeout(function() {
                    t.apply(a, o), n = null
                }, e)
            }
        }, e.j = function(t, e) {
            window.localStorage.setItem(t, r()(e))
        }, e.f = function(t) {
            var e = window.localStorage.getItem(t);
            return "undefined" == e || "null" == e ? "" : JSON.parse(e)
        }, e.b = function(t, e) {
            if (e < t[0].amount) return {};
            for (var n = 0; n < t.length - 1; n++)
                if (e >= t[n].amount && e < t[n + 1].amount) return t[n];
            return t[t.length - 1]
        }, e.d = function() {
            var t = [window.location.href];
            try {
                window.top !== window.self && t.push(window.top.location.href);
                var e = new URLSearchParams(window.top.location.search).get("url");
                e && t.push(decodeURIComponent(e))
            } catch (t) {}
            var n = !0,
                a = !1,
                i = void 0;
            try {
                for (var r, s = o()(t); !(n = (r = s.next()).done); n = !0) {
                    var u = r.value,
                        c = u.match(/activity([AB])/);
                    if (c) return "activity" + c[1]
                }
            } catch (t) {
                a = !0, i = t
            } finally {
                try {
                    !n && s.return && s.return()
                } finally {
                    if (a) throw i
                }
            }
            return ""
        }, e.h = function() {
            var t = new URL(window.top.location.href),
                e = t.searchParams,
                n = t.pathname.split("/")[1],
                a = t.origin + "/" + n + "/";
            if ("casino" === e.get("from")) return void(window.top.location.href = t.origin + "/" + n + "/games/home");
            window.top.location.href = a
        };
        var a = n("BO1k"),
            o = n.n(a),
            i = n("mvHQ"),
            r = n.n(i),
            s = n("pFYg");
        n.n(s), n("Zpiv")
    },
    p0QZ: function(t, e, n) {
        "use strict";
        n.d(e, "a", function() {
            return u
        }), n.d(e, "b", function() {
            return c
        });
        var a = n("bOdI"),
            o = n.n(a),
            i = n("IcnI"),
            r = {
                SWVVFBBET: "1339817950218888",
                SWZYFB: "957895621990242",
                CWVVFBT: "896271524983664",
                CWVVFBY: "1686940725126758",
                CWVVFBAB: "304385262000864",
                CWVVFBWI: "304385262000864",
                CWVVFBABWI: "304385262000864",
                CWVVFBDLHUNT: "918309925973067",
                CWVVFBGAT: "581867573797335",
                SWVVFBGATHER: "751363942822513",
                CWVVFBL: "233280419847943",
                WVVFBABTL: "896271524983664",
                CWVVFBAPK: "3056823454449841",
                CWVVFBAPKA: "3056823454449841",
                CWVVFBAPKB: "3056823454449841",
                CWVVFBZQA: "850729089872713",
                CWFBZQB: "850729089872713",
                CWFBAPKA: "3056823454449841",
                CWFBT: "896271524983664",
                CWFBY: "1686940725126758",
                CWFBL: "233280419847943",
                CWFBBBTL: "1051162502632065",
                CWFBBBWT: "765282452202953"
            };
        window.casino_bangpay_fbchannelLog = r;
        var s = o()({
                SWZYTBLANDPAGE: 1606353,
                SWZYTBHOMEPAGE: 1596241,
                CWTLTBH5: 1623073,
                CWTLTBHOMEPAGE: 1623073,
                CWYYTBH5: 1623073,
                CWYYTBHOMEPAGE: 1623073,
                CWYYTBNH5: 1623073
            }, "CWYYTBH5", 1623073),
            u = function(t, e) {
                try {
                    if (window.fbqId && fbq)
                        if ("InitiateCheckout" == t) {
                            fbq("track", "InitiateCheckout");
                            var n = i.a.getters.userInfo;
                            if (n && n.cts)
                                if (((new Date).getTime() - Number(n.cts)) / 1e3 / 3600 <= 24) {
                                    var a = n.userId + "";
                                    fbq("trackCustom", "TodayAddtoCart", {
                                        custom_parameter: a,
                                        value: 1,
                                        currency: "USD"
                                    })
                                }
                        } else "Purchase" == t && console.log("先把这里的注释掉");
                    else if (window.taboolafaId && window._tfa && "InitiateCheckout" == t) {
                        window._tfa.push({
                            notify: "event",
                            name: "add_payment_info",
                            id: window.taboolafaId
                        });
                        var o = i.a.getters.userInfo;
                        if (o && o.cts)((new Date).getTime() - Number(o.cts)) / 1e3 / 3600 <= 24 && window._tfa.push({
                            notify: "event",
                            name: "today_payment_info",
                            id: window.taboolafaId
                        })
                    }
                } catch (t) {
                    console.log(t)
                }
            };

        function c() {
            try {
                var t = i.a.getters.userInfo,
                    e = function(t) {
                        t && (t = t.toUpperCase());
                        var e = "";
                        for (var n in r) - 1 != t.indexOf(n) && (e = r[n]);
                        return e
                    }(t.channel);
                if (t && t.channel && e) window.fbqId = e,
                    function(t, e, n, a, o, i, r) {
                        if (t.fbq) return;
                        o = t.fbq = function() {
                            o.callMethod ? o.callMethod.apply(o, arguments) : o.queue.push(arguments)
                        }, t._fbq || (t._fbq = o);
                        o.push = o, o.loaded = !0, o.version = "2.0", o.queue = [], (i = e.createElement(n)).async = !0, i.src = a, (r = e.getElementsByTagName(n)[0]).parentNode.insertBefore(i, r), t.fbqId && t.fbq && (console.log("fbq加载完成"), t.fbq("init", t.fbqId))
                    }(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js");
                else if (t && t.channel) {
                    var n = function(t) {
                        t && (t = t.toUpperCase());
                        var e = "";
                        for (var n in s) - 1 != t.indexOf(n) && (e = s[n]);
                        return e
                    }(t.channel);
                    n && (window.taboolafaId = n, a = n, window._tfa = window._tfa || [], window._tfa.push({
                        notify: "event",
                        name: "page_view",
                        id: a
                    }), o = document.createElement("script"), u = document.getElementsByTagName("script")[0], c = "//cdn.taboola.com/libtrc/unip/" + a + "/tfa.js", p = "tb_tfa_script", document.getElementById(p) || (o.async = 1, o.src = c, o.id = p, u.parentNode.insertBefore(o, u)))
                }
            } catch (t) {
                console.log(t)
            }
            var a, o, u, c, p
        }
    },
    pyoj: function(t, e) {},
    tvR6: function(t, e) {},
    zqlM: function(t, e) {}
}, [0]);
//# sourceMappingURL=app.ccaad357436d51f42510.js.map