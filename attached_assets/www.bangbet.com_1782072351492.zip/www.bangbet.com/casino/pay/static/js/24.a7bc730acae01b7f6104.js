webpackJsonp([24], {
    Cs8e: function(e, t) {},
    v8Ct: function(e, t, o) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = {
                name: "",
                inject: ["showMask", "shutMask"],
                props: {},
                components: {},
                data: function() {
                    return {
                        isLoading: !1,
                        country: "ke"
                    }
                },
                mounted: function() {
                    this.shutMask()
                },
                computed: {},
                watch: {},
                created: function() {},
                methods: {
                    reload: function() {
                        var e = {},
                            t = this.$store.getters.userInfo;
                        t.token && (e.token = encodeURIComponent(t.token)), t.secretKey && (e.secretKey = encodeURIComponent(t.secretKey));
                        var o = this.$store.getters.getPlatfrom;
                        o && (e.platfrom = o);
                        var n = this.$store.getters.country;
                        n && (e.country = n);
                        var s = "";
                        for (var a in e) "" != s && (s += "&"), s += a + "=" + e[a];
                        var i = window.location.href.split("#")[0] + "#/?" + s;
                        window.location.href = i
                    }
                }
            },
            s = {
                render: function() {
                    var e = this,
                        t = e.$createElement,
                        o = e._self._c || t;
                    return o("div", {
                        staticClass: "wait-loading"
                    }, [o("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: !e.isLoading,
                            expression: "!isLoading"
                        }],
                        staticClass: "netError-icon"
                    }, [o("i", {
                        staticClass: "iconfont icon-Icon_No_Network_",
                        staticStyle: {
                            "font-size": "128px",
                            color: "#EAEDF0"
                        }
                    })]), e._v(" "), o("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: !e.isLoading,
                            expression: "!isLoading"
                        }],
                        staticClass: "netError-text"
                    }, [e._v("Data failed loading.Please reload")]), e._v(" "), o("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: !e.isLoading,
                            expression: "!isLoading"
                        }],
                        staticClass: "netError-btn-con"
                    }, [o("div", {
                        staticClass: "netError-btn",
                        on: {
                            click: function(t) {
                                return e.reload()
                            }
                        }
                    }, [e._v("Reload")])])])
                },
                staticRenderFns: []
            };
        var a = o("VU/8")(n, s, !1, function(e) {
            o("Cs8e")
        }, "data-v-0ccc9108", null);
        t.default = a.exports
    }
});
//# sourceMappingURL=24.a7bc730acae01b7f6104.js.map