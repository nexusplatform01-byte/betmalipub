/**站群相关判断 */
// casino相关正式服域名
;
(function() {
    var casinoDomain = ['bangcasino', 'banggame', 'bangcasino', 'bangxyz', 'casino.bangbet.co.ke', 'casino.bangbet.ng', 'casino.bangbet.com.gh', 'casino.betsure.ug', 'casino.bangbet.com', 'casino.bangbet.com.ng', 'casino.betsure.com', 'casino.bangbettz.co.tz', 'casino.bangbess.com']
    var casinoAllDomain = ['bangcasino', 'xa.hw', 'banggame', 'bangxyz', 'casino.bangbet.co.ke', 'casino.bangbet.ng', 'casino.bangbet.com.gh', 'casino.betsure.ug', 'casino.bangbet.com', 'casino.bangbet.com.ng', 'casino.betsure.com', 'casino.bangbettz.co.tz', 'casino.bangbess.com']
    //  bangbet域名下面的caisno
    var bangbetDomain = ['www.bangbet.com', 'www.betsure.com']
    var bangbetAllDomain = ['www.bangbet.com', 'www.betsure.com', 'www.hw.luckygames.team']
    // 判断是否是casino的正式服
    function is_casinoDomain() {
        var flag = false
        var link = window.location.origin
        for (let index = 0; index < casinoDomain.length; index++) {
            if (link.indexOf(casinoDomain[index]) != -1) {
                flag = true
            }
        }
        var bangbetCasinoLink = window.top ? window.top.location.href : window.location.href
        for (let index = 0; index < bangbetDomain.length; index++) {
            if (bangbetCasinoLink.indexOf(bangbetDomain[index]) != -1 && bangbetCasinoLink.indexOf('/games') != -1) {
                flag = true
            }
        }
        return flag
    }
    window.isCasinoDomain = is_casinoDomain()

    // 判断是否是bangbet域名下的caisno
    function is_bangbetCasinoDomain() {
        var flag = false
        var bangbetCasinoLink = window.top ? window.top.location.href : window.location.href
        for (let index = 0; index < bangbetAllDomain.length; index++) {
            // 游戏新增路径
            const casinoPaths = ['/games', '/en/casino', '/sw/casino'];
            const isCasinoPaths = casinoPaths.some(path => bangbetCasinoLink.includes(path))
            if (bangbetCasinoLink.indexOf(bangbetAllDomain[index]) != -1 && isCasinoPaths) {
                flag = true
            }
        }
        return flag
    }
    window.isBangbetCasinoDomain = is_bangbetCasinoDomain()
    // 判断是否是casino环境
    function is_casinoAllDomain() {
        var flag = false
        var link = window.location.origin
        for (let index = 0; index < casinoAllDomain.length; index++) {
            if (link.indexOf(casinoAllDomain[index]) != -1) {
                flag = true
            }
        }
        var bangbetCasinoLink = window.top ? window.top.location.href : window.location.href
        for (let index = 0; index < bangbetAllDomain.length; index++) {
            if (bangbetCasinoLink.indexOf(bangbetAllDomain[index]) != -1 && bangbetCasinoLink.indexOf('/games') != -1) {
                flag = true
            }
        }
        return flag
    }
    window.isCasinoAllDomain = is_casinoAllDomain()
    //code
})()